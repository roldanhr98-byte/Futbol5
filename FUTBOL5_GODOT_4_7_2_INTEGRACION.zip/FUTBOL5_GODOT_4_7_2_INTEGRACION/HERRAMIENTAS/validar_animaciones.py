"""Valida clips futbol5_clip_v1 (vuestras animaciones exportadas a JSON). No modifica nada.

Uso: python3 validar_animaciones.py CARPETA_O_ARCHIVO [...] [--informe informe.json]
Código de salida 1 si algún clip tiene ERRORES (los AVISOS no bloquean).
"""
import json, math, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import f5anim

NAME_RE = re.compile(r"^[A-Za-z0-9_\-]+$")


def iter_json(paths):
    for p in paths:
        if not os.path.exists(p):
            print(f"[ERROR] no existe: {p}")
            continue
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in sorted(files):
                    if f.lower().endswith(".json"):
                        yield os.path.join(root, f)
        else:
            yield p


def validate_clip(c):
    err, warn = [], []
    if c.get("format") != "futbol5_clip_v1":
        err.append("format debe ser 'futbol5_clip_v1'")
    name = c.get("name", "")
    if not name or not NAME_RE.match(name):
        err.append(f"name inválido: {name!r} (solo letras, números, _ y -)")
    if c.get("category") not in f5anim.CATEGORIES:
        err.append(f"category desconocida: {c.get('category')!r}")
    fps, frames = c.get("fps", 0), c.get("frames", 0)
    if not isinstance(fps, (int, float)) or fps <= 0:
        err.append("fps debe ser > 0")
    if not isinstance(frames, int) or frames < 1:
        err.append("frames debe ser un entero >= 1")
    sk = c.get("skeleton", {})
    bones = sk.get("bones", [])
    seen = set()
    for b in bones:
        n = b.get("name")
        if not n or n in seen:
            err.append(f"hueso repetido o sin nombre: {n!r}")
        par = b.get("parent", "")
        if par and par not in seen:
            err.append(f"hueso {n}: el padre {par!r} no existe o aparece después")
        seen.add(n)
    if not bones:
        err.append("skeleton.bones vacío")
    rb = c.get("root_bone")
    if rb not in seen:
        err.append(f"root_bone {rb!r} no está en el esqueleto")
    for bn, tr in c.get("tracks", {}).items():
        if bn not in seen:
            err.append(f"pista de hueso inexistente: {bn}")
            continue
        for kind, width in (("pos", 4), ("rot", 5)):
            last = -1
            for k in tr.get(kind, []):
                if len(k) != width:
                    err.append(f"{bn}.{kind}: clave con {len(k)} valores (se esperan {width}: frame + valores)"); break
                if not (0 <= k[0] <= frames):
                    err.append(f"{bn}.{kind}: frame {k[0]} fuera de [0,{frames}]"); break
                if k[0] <= last:
                    err.append(f"{bn}.{kind}: frames no crecientes ({k[0]})"); break
                last = k[0]
                if kind == "rot":
                    n = math.sqrt(sum(v*v for v in k[1:]))
                    if abs(n - 1) > 1e-3:
                        err.append(f"{bn}.rot frame {k[0]}: cuaternión no normalizado (|q|={n:.4f})"); break
                if any(not isinstance(v, (int, float)) or math.isnan(v) or math.isinf(v) for v in k[1:]):
                    err.append(f"{bn}.{kind} frame {k[0]}: valor no numérico"); break
    if rb in seen and not c.get("tracks", {}).get(rb, {}).get("pos"):
        warn.append("la raíz no tiene pista de posición: el clip no tendrá desplazamiento de raíz")
    meta = c.get("meta", {})
    if meta.get("foot", "") not in ("", "L", "R"):
        err.append("meta.foot debe ser 'L', 'R' o ''")
    contacts = [e for e in c.get("events", []) if e.get("type") == "contact"]
    for e in c.get("events", []):
        if not isinstance(e.get("frame"), (int, float)) or not (0 <= e["frame"] <= frames):
            err.append(f"evento {e.get('type')}: frame fuera de rango")
        if e.get("type") == "contact":
            if "ball_local" not in e and e.get("part") not in seen:
                err.append("evento contact sin ball_local y con 'part' que no es un hueso del esqueleto")
            if "ball_local" in e and len(e["ball_local"]) != 3:
                err.append("ball_local debe tener 3 valores")
    if c.get("category") in f5anim.CONTACT_CATEGORIES and not contacts:
        warn.append(f"categoría {c.get('category')} sin evento de contacto: el planificador no podrá usarlo para tocar el balón")
    if c.get("category") not in f5anim.CONTACT_CATEGORIES and contacts:
        warn.append("tiene evento de contacto pero su categoría no es de contacto")
    if c.get("category") in ("CONTROL", "KICK", "TACKLE") and not meta.get("foot"):
        warn.append("sin meta.foot: no se podrá aplicar la regla de pie hábil/espejo")
    for k in ("speed_class", "dir_deg"):
        if k not in meta:
            warn.append(f"sin meta.{k}: el convertidor lo calculará desde la raíz [N]")
    return err, warn


def main(argv):
    rep_path = None
    if "--informe" in argv:
        i = argv.index("--informe"); rep_path = argv[i+1]; argv = argv[:i] + argv[i+2:]
    report, nerr, n = [], 0, 0
    names = {}
    for path in iter_json(argv):
        n += 1
        try:
            c = f5anim.load_clip(path)
            err, warn = validate_clip(c)
            nm = c.get("name")
            if nm in names:
                err.append(f"nombre duplicado (también en {names[nm]})")
            names[nm] = path
        except Exception as ex:  # JSON roto
            err, warn = [f"no se puede leer: {ex}"], []
        if err:
            nerr += 1
        report.append({"file": path, "sha256": f5anim.sha256_file(path), "errors": err, "warnings": warn})
        tag = "ERROR" if err else ("AVISO" if warn else "OK")
        print(f"[{tag}] {path}")
        for e in err: print("    error:", e)
        for w in warn: print("    aviso:", w)
    print(f"\n{n} clips, {nerr} con errores")
    if rep_path:
        f5anim.write_json(rep_path, {"clips": report, "total": n, "with_errors": nerr})
    return 1 if nerr else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
