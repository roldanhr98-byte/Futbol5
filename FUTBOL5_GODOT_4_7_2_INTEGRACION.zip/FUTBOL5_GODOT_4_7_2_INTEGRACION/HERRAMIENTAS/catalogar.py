"""Cataloga clips futbol5_clip_v1 SIN modificarlos y escribe:
  SALIDA/catalogo_completo.csv y .json   una fila por clip (nombre exacto, archivo, sha256, categoría, sistema, frames,
                                          fps, duración, pie, contacto, frame de contacto, velocidad de raíz, giro, tags)
  SALIDA/categorias/<CAT>.csv             mismas filas, separadas por categoría
  SALIDA/sistemas/<sistema>.csv           separadas por sistema del juego
  SALIDA/espejos/pares_espejo.csv         pares izquierda/derecha detectados por nombre o por meta.mirror_of
  SALIDA/compatibilidad.csv               resultado del validador (OK / AVISO / ERROR) con el motivo
Uso: python3 catalogar.py CARPETA_CLIPS CARPETA_SALIDA
"""
import csv, math, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import f5anim
from validar_animaciones import validate_clip, iter_json
from convertir_a_godot import extract_root

COLS = ["nombre", "archivo", "sha256", "categoria", "sistema", "frames", "fps", "duracion_s", "pie", "contacto",
        "frame_contacto", "parte_contacto", "speed_class", "vel_raiz_ms", "giro_raiz_deg", "dir_deg", "tags", "estado"]


def side_key(name):
    k = re.sub(r"(^|_)(L|R|IZQ|DER|LEFT|RIGHT)(?=_|$)", r"\1#", name)
    return k if k != name else None


def write_csv(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLS); w.writeheader(); w.writerows(rows)


def main(src, out):
    rows, comp = [], []
    for path in iter_json([src]):
        c = f5anim.load_clip(path)
        err, warn = validate_clip(c)
        rel = os.path.relpath(path, src).replace(os.sep, "/")
        estado = "ERROR" if err else ("AVISO" if warn else "OK")
        comp.append({"archivo": rel, "estado": estado, "motivos": " | ".join(err + warn)})
        mt = c.get("meta", {})
        ct = [e for e in c.get("events", []) if e.get("type") == "contact"]
        try:
            times, pos, yaw = extract_root(c, 30) if not err else ([0], [(0, 0, 0)], [0])
        except Exception:
            times, pos, yaw = [0], [(0, 0, 0)], [0]
        dur = c.get("frames", 0) / c.get("fps", 60) if c.get("fps") else 0
        rows.append({"nombre": c.get("name"), "archivo": rel, "sha256": f5anim.sha256_file(path),
                     "categoria": c.get("category"), "sistema": mt.get("system", ""), "frames": c.get("frames"),
                     "fps": c.get("fps"), "duracion_s": round(dur, 4), "pie": mt.get("foot", ""),
                     "contacto": "si" if ct else "no", "frame_contacto": ct[0]["frame"] if ct else "",
                     "parte_contacto": ct[0].get("part", "") if ct else "", "speed_class": mt.get("speed_class", ""),
                     "vel_raiz_ms": round(math.hypot(pos[-1][0], pos[-1][2]) / dur, 3) if dur else 0,
                     "giro_raiz_deg": round(math.degrees(yaw[-1]), 2), "dir_deg": mt.get("dir_deg", ""),
                     "tags": ";".join(mt.get("tags", [])), "estado": estado})
    rows.sort(key=lambda r: (str(r["categoria"]), str(r["nombre"])))
    write_csv(os.path.join(out, "catalogo_completo.csv"), rows)
    f5anim.write_json(os.path.join(out, "catalogo_completo.json"), {"count": len(rows), "clips": rows})
    for key, sub in (("categoria", "categorias"), ("sistema", "sistemas")):
        groups = {}
        for r in rows:
            groups.setdefault(r[key] or "sin_dato", []).append(r)
        for g, rr in groups.items():
            write_csv(os.path.join(out, sub, f"{g}.csv"), rr)
    pairs, by_key = [], {}
    for r in rows:
        k = side_key(r["nombre"])
        if k:
            by_key.setdefault(k, []).append(r["nombre"])
    for k, names in sorted(by_key.items()):
        if len(names) >= 2:
            pairs.append({"patron": k, "clips": " / ".join(sorted(names))})
    os.makedirs(os.path.join(out, "espejos"), exist_ok=True)
    with open(os.path.join(out, "espejos", "pares_espejo.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["patron", "clips"]); w.writeheader(); w.writerows(pairs)
    with open(os.path.join(out, "compatibilidad.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["archivo", "estado", "motivos"]); w.writeheader(); w.writerows(comp)
    print(f"{len(rows)} clips catalogados, {len(pairs)} pares espejo por nombre, salida en {out}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
