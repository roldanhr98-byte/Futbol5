"""Biblioteca común de las herramientas de animación de Fútbol 5 (solo biblioteca estándar de Python 3.9+).

Formato de clip propio "futbol5_clip_v1" (ver ESQUEMAS/futbol5_clip_v1.schema.json):
  coordenadas de Godot: Y arriba; +Z = frente del personaje al inicio del clip; +X = izquierda del personaje; metros.
  rotaciones: cuaterniones (x, y, z, w) locales al padre.
"""
import hashlib, json, math, os

CATEGORIES = ["LOCO", "STAND", "TURN", "SIDESTEP", "CONTROL", "KICK", "KICKSETPIECE", "TACKLE", "TACKLESLIDE",
              "FALL", "GETUP", "STUMBLE", "GKSAVE", "GKTHROW", "GKKICK", "THROW", "NIS", "OTHER"]
CONTACT_CATEGORIES = {"CONTROL", "KICK", "KICKSETPIECE", "TACKLE", "TACKLESLIDE", "GKSAVE", "GKKICK", "GKTHROW", "THROW"}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_clip(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------------- cuaterniones ----------------
def q_mul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return (aw*bx + ax*bw + ay*bz - az*by, aw*by - ax*bz + ay*bw + az*bx,
            aw*bz + ax*by - ay*bx + az*bw, aw*bw - ax*bx - ay*by - az*bz)


def q_rot(q, v):
    x, y, z, w = q
    vx, vy, vz = v
    # v' = q v q*
    ix = w*vx + y*vz - z*vy; iy = w*vy + z*vx - x*vz; iz = w*vz + x*vy - y*vx; iw = -x*vx - y*vy - z*vz
    return (ix*w + iw*-x + iy*-z - iz*-y, iy*w + iw*-y + iz*-x - ix*-z, iz*w + iw*-z + ix*-y - iy*-x)


def q_norm(q):
    n = math.sqrt(sum(c*c for c in q)) or 1.0
    return tuple(c/n for c in q)


def q_slerp(a, b, t):
    d = sum(x*y for x, y in zip(a, b))
    if d < 0:
        b = tuple(-c for c in b); d = -d
    if d > 0.9995:
        return q_norm(tuple(x + (y - x)*t for x, y in zip(a, b)))
    th = math.acos(max(-1.0, min(1.0, d)))
    s = math.sin(th)
    return tuple((math.sin((1-t)*th)*x + math.sin(t*th)*y)/s for x, y in zip(a, b))


def q_yaw(q):
    """Giro alrededor de Y (rad) del eje +Z rotado."""
    fx, _, fz = q_rot(q, (0.0, 0.0, 1.0))
    return math.atan2(fx, fz)


def q_from_yaw(yaw):
    return (0.0, math.sin(yaw/2), 0.0, math.cos(yaw/2))


# ---------------- muestreo de pistas ----------------
def sample(keys, frame, kind):
    """keys: [[frame, ...valores]] ordenadas. kind: 'pos' (lineal) o 'rot' (slerp)."""
    if not keys:
        return None
    if frame <= keys[0][0]:
        return tuple(keys[0][1:])
    for a, b in zip(keys, keys[1:]):
        if frame <= b[0]:
            t = (frame - a[0]) / max(1e-9, b[0] - a[0])
            if kind == "rot":
                return q_slerp(tuple(a[1:]), tuple(b[1:]), t)
            return tuple(x + (y - x)*t for x, y in zip(a[1:], b[1:]))
    return tuple(keys[-1][1:])


def bone_order(clip):
    bones = clip["skeleton"]["bones"]
    names = [b["name"] for b in bones]
    parent = {b["name"]: b.get("parent", "") for b in bones}
    return names, parent


def global_pose(clip, frame):
    """Cinemática directa: {hueso: (posición global, rotación global)} en el frame dado (puede ser fraccionario)."""
    names, parent = bone_order(clip)
    tracks = clip.get("tracks", {})
    rest = {b["name"]: b for b in clip["skeleton"]["bones"]}
    out = {}
    for n in names:
        tr = tracks.get(n, {})
        lp = sample(tr.get("pos", []), frame, "pos") or tuple(rest[n].get("rest_pos", (0.0, 0.0, 0.0)))
        lr = sample(tr.get("rot", []), frame, "rot") or tuple(rest[n].get("rest_rot", (0.0, 0.0, 0.0, 1.0)))
        p = parent.get(n, "")
        if p and p in out:
            pp, pr = out[p]
            gp = tuple(a + b for a, b in zip(pp, q_rot(pr, lp)))
            gr = q_norm(q_mul(pr, lr))
        else:
            gp, gr = lp, q_norm(lr)
        out[n] = (gp, gr)
    return out


def write_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
