"""Genera clips SINTÉTICOS de prueba en formato futbol5_clip_v1 [N].

NO son animaciones de juego: son movimientos geométricos simples (esqueleto de 9 huesos) que sirven para probar el
validador, el convertidor, el catálogo y el planificador antes de tener vuestras animaciones. Todos llevan el prefijo
EJ_ y la etiqueta SINTETICO.

Uso: python3 generar_ejemplos_sinteticos.py CARPETA_SALIDA
"""
import math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import f5anim

SKELETON = {"id": "ejemplo_sintetico_9", "bones": [
    {"name": "root", "parent": "", "rest_pos": [0, 0, 0]},
    {"name": "hips", "parent": "root", "rest_pos": [0, 0.95, 0]},
    {"name": "spine", "parent": "hips", "rest_pos": [0, 0.25, 0]},
    {"name": "head", "parent": "spine", "rest_pos": [0, 0.45, 0]},
    {"name": "thigh_l", "parent": "hips", "rest_pos": [0.1, -0.05, 0]},
    {"name": "foot_l", "parent": "thigh_l", "rest_pos": [0, -0.85, 0.05]},
    {"name": "thigh_r", "parent": "hips", "rest_pos": [-0.1, -0.05, 0]},
    {"name": "foot_r", "parent": "thigh_r", "rest_pos": [0, -0.85, 0.05]},
    {"name": "hand_r", "parent": "spine", "rest_pos": [-0.25, 0.2, 0.1]},
]}


def rot_x(a):
    return [math.sin(a/2), 0.0, 0.0, math.cos(a/2)]


def clip(name, category, frames, root_speed, swing_deg, system, meta, events=None, yaw_total=0.0, hips_drop=0.0, fps=60):
    tracks = {"root": {"pos": [], "rot": []}, "hips": {"pos": []}, "thigh_l": {"rot": []}, "thigh_r": {"rot": []}}
    for f in range(frames + 1):
        t = f / fps
        u = f / frames
        yaw = yaw_total * u
        # raíz avanza en la dirección de su giro acumulado (integración simple)
        if f == 0:
            x = z = 0.0
        else:
            px, _, pz = tracks["root"]["pos"][-1][1:]
            step = root_speed / fps
            x = px + math.sin(yaw) * step
            z = pz + math.cos(yaw) * step
        tracks["root"]["pos"].append([f, round(x, 5), 0.0, round(z, 5)])
        tracks["root"]["rot"].append([f] + [round(c, 6) for c in f5anim.q_from_yaw(yaw)])
        tracks["hips"]["pos"].append([f, 0.0, round(0.95 - hips_drop*math.sin(math.pi*u), 5), 0.0])
        sw = math.radians(swing_deg) * math.sin(2*math.pi*t*1.6)
        tracks["thigh_l"]["rot"].append([f] + [round(c, 6) for c in rot_x(sw)])
        tracks["thigh_r"]["rot"].append([f] + [round(c, 6) for c in rot_x(-sw)])
    m = {"system": system, "speed_pct": 100, "speed_tol": 1.5, "dir_tol_deg": 45, "elev_range_deg": [-10, 30], "tags": ["SINTETICO"]}
    m.update(meta)
    return {"format": "futbol5_clip_v1", "name": name, "category": category, "fps": fps, "frames": frames,
            "skeleton": SKELETON, "root_bone": "root", "tracks": tracks, "events": events or [], "meta": m,
            "author_note": "Clip sintético generado por generar_ejemplos_sinteticos.py para pruebas [N]"}


def contact(frame, local, part):
    return [{"type": "contact", "frame": frame, "part": part, "ball_local": local}]


def main(out):
    clips = []
    for sp, nm in [(1.6, "CAMINAR"), (3.5, "TROTE"), (5.5, "CARRERA"), (7.5, "SPRINT")]:
        clips.append(clip(f"EJ_LOCO_{nm}", "LOCO", 60, sp, 10 + 4*sp, "locomocion", {"speed_class": sp, "loop": True}))
    clips.append(clip("EJ_STAND_REPOSO", "STAND", 60, 0.0, 0, "locomocion", {"speed_class": 0.0, "loop": True}))
    for deg in (90, -90, 180):
        clips.append(clip(f"EJ_TURN_{'IZQ' if deg > 0 else 'DER'}_{abs(deg)}", "TURN", 36, 1.2, 12, "giro",
                          {"speed_class": 2.0, "dir_deg": deg}, yaw_total=math.radians(deg)))
    clips.append(clip("EJ_STAND_FRENADA", "STAND", 30, 1.5, 8, "frenado", {"speed_class": 4.0, "tags": ["SINTETICO", "STOP"]}))
    # toques de control/conducción: evento a 12–18 frames, balón delante y al lado del pie
    for sp in (1.5, 3.5, 5.5, 7.0):
        for foot, side in (("R", -0.12), ("L", 0.12)):
            fr = 14 if sp < 5 else 11
            zc = sp * fr / 60.0 + 0.35
            clips.append(clip(f"EJ_CONTROL_TOQUE_{foot}_{str(sp).replace('.', '_')}", "CONTROL", 30, sp, 10 + 4*sp, "conduccion",
                              {"speed_class": sp, "foot": foot, "dir_deg": 0, "tags": ["SINTETICO", "DRIBBLE"]},
                              contact(fr, [side, 0.105, round(zc, 4)], "foot_" + foot.lower())))
    for foot, side in (("R", -0.15), ("L", 0.15)):
        clips.append(clip(f"EJ_CONTROL_RECEPCION_{foot}", "CONTROL", 40, 0.8, 8, "control",
                          {"speed_class": 0.5, "foot": foot, "dir_deg": 0, "tags": ["SINTETICO", "FIRST_TOUCH"]},
                          contact(16, [side, 0.105, 0.45], "foot_" + foot.lower())))
    for foot, side in (("R", -0.18), ("L", 0.18)):
        for sp in (0.0, 3.0, 5.5):
            fr = 18
            clips.append(clip(f"EJ_KICK_PASE_{foot}_{str(sp).replace('.', '_')}", "KICK", 50, sp, 25, "pase",
                              {"speed_class": sp, "foot": foot, "dir_deg": 0, "tags": ["SINTETICO"]},
                              contact(fr, [side, 0.105, round(sp*fr/60.0 + 0.45, 4)], "foot_" + foot.lower())))
        clips.append(clip(f"EJ_KICK_TIRO_{foot}", "KICK", 55, 2.0, 35, "tiro", {"speed_class": 2.5, "foot": foot, "dir_deg": 0, "tags": ["SINTETICO"]},
                          contact(22, [side, 0.105, round(2.0*22/60.0 + 0.5, 4)], "foot_" + foot.lower())))
        clips.append(clip(f"EJ_KICK_CENTRO_{foot}", "KICK", 55, 3.0, 30, "centro",
                          {"speed_class": 3.5, "foot": foot, "dir_deg": 30 if foot == "R" else -30, "tags": ["SINTETICO", "CROSS"]},
                          contact(20, [side, 0.105, round(3.0*20/60.0 + 0.45, 4)], "foot_" + foot.lower())))
    for side, nm in ((1.6, "IZQ"), (-1.6, "DER")):
        for h in (0.3, 1.2):
            clips.append(clip(f"EJ_GKSAVE_ESTIRADA_{nm}_{'BAJA' if h < 1 else 'MEDIA'}", "GKSAVE", 50, 0.0, 5, "portero",
                              {"speed_class": 0.0, "dir_deg": 0, "tags": ["SINTETICO", "CATCH"]},
                              contact(14, [side, h, 0.2], "hand_r")))
    clips.append(clip("EJ_GKSAVE_CENTRO", "GKSAVE", 40, 0.0, 3, "portero", {"speed_class": 0.0, "tags": ["SINTETICO", "CATCH"]},
                      contact(10, [0.0, 1.0, 0.3], "hand_r")))
    clips.append(clip("EJ_TACKLE_PIE_R", "TACKLE", 40, 2.0, 30, "entrada", {"speed_class": 2.5, "foot": "R"},
                      contact(16, [-0.15, 0.105, 0.95], "foot_r")))
    clips.append(clip("EJ_TACKLESLIDE_R", "TACKLESLIDE", 60, 4.0, 10, "entrada", {"speed_class": 5.0, "foot": "R"},
                      contact(24, [-0.2, 0.105, 1.9], "foot_r"), hips_drop=0.6))
    clips.append(clip("EJ_FALL_ADELANTE", "FALL", 50, 1.0, 5, "caida", {"speed_class": 3.0}, hips_drop=0.8))
    clips.append(clip("EJ_GETUP_ADELANTE", "GETUP", 70, 0.0, 5, "recuperacion", {"speed_class": 0.0}))
    for c in clips:
        f5anim.write_json(os.path.join(out, c["category"], c["name"] + ".json"), c)
    print(len(clips), "clips sintéticos en", out)


if __name__ == "__main__":
    main(sys.argv[1])
