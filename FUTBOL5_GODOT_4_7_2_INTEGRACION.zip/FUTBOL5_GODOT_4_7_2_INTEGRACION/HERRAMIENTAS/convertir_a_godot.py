"""Convierte clips futbol5_clip_v1 a recursos de Godot 4.7.2 (texto .tres, sin necesidad de abrir el editor).

Por clip genera:
  data/animations/imported/<CAT>/<nombre>.tres   Animation: pistas position_3d / rotation_3d de Skeleton3D:<hueso>,
                                                  con la raíz SIN desplazamiento horizontal ni giro (root motion fuera).
  data/animations/metadata/<CAT>/<nombre>.tres    AnimClipMeta: evento(s) de contacto, raíz muestreada, pie, rangos…
  data/catalog/catalogo.json                      índice que carga AnimCatalog.load_index()
Opcionalmente (--espejos) genera la versión espejo de cada clip asimétrico (sufijo _ESPEJO), como hace UCS con sus
registros espejo [UCS-C: los espejos de UCS comparten datos de pose y se reflejan en tiempo de ejecución].

Uso:
  python3 convertir_a_godot.py ENTRADA PROYECTO_GODOT [--espejos] [--skeleton-path Skeleton3D] [--root-hz 30]
                                [--limpiar] [--informe informe.json]
ENTRADA = carpeta con JSON (se recorre entera). Se conservan los nombres EXACTOS de los clips.
Los clips con errores de validación NO se convierten (se listan en el informe).
"""
import json, math, os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import f5anim
from validar_animaciones import validate_clip, iter_json

SWAP = [(r"_l$", "_r"), (r"_r$", "_l"), (r"_L$", "_R"), (r"_R$", "_L"), (r"\.l$", ".r"), (r"\.r$", ".l"),
        (r"\.L$", ".R"), (r"\.R$", ".L"), (r"Left", "Right"), (r"Right", "Left"), (r"left", "right"), (r"right", "left")]


def swap_side(name):
    for pat, rep in SWAP:
        if re.search(pat, name):
            return re.sub(pat, rep, name, count=1)
    return name


def fnum(v):
    s = f"{v:.6g}"
    return "0" if s in ("-0", "0") else s


def root_frame0(clip):
    tr = clip["tracks"].get(clip["root_bone"], {})
    p0 = f5anim.sample(tr.get("pos", []), 0, "pos") or (0.0, 0.0, 0.0)
    r0 = f5anim.sample(tr.get("rot", []), 0, "rot") or (0.0, 0.0, 0.0, 1.0)
    return p0, f5anim.q_yaw(r0)


def to_start_space(p, p0, yaw0):
    dx, dy, dz = p[0] - p0[0], p[1], p[2] - p0[2]
    c, s = math.cos(-yaw0), math.sin(-yaw0)
    return (c*dx + s*dz, dy, -s*dx + c*dz)


def extract_root(clip, hz):
    """Muestrea la raíz (posición horizontal y giro) en espacio de inicio del clip."""
    fps, frames = clip["fps"], clip["frames"]
    tr = clip["tracks"].get(clip["root_bone"], {})
    p0, yaw0 = root_frame0(clip)
    n = max(1, int(round(frames / fps * hz)))
    times, pos, yaw = [], [], []
    prev = 0.0
    for i in range(n + 1):
        f = frames * i / n
        p = f5anim.sample(tr.get("pos", []), f, "pos") or p0
        q = f5anim.sample(tr.get("rot", []), f, "rot") or (0.0, 0.0, 0.0, 1.0)
        sp = to_start_space(p, p0, yaw0)
        y = f5anim.q_yaw(q) - yaw0
        while y - prev > math.pi: y -= 2*math.pi      # desenrollar
        while y - prev < -math.pi: y += 2*math.pi
        prev = y
        times.append(f / fps); pos.append((sp[0], 0.0, sp[2])); yaw.append(y)
    return times, pos, yaw


def compute_ball_local(clip, ev):
    """Si el evento no trae ball_local, se toma la posición del hueso 'part' en el frame del evento,
    en espacio de inicio del clip, apoyada a la altura del radio del balón [N]."""
    pose = f5anim.global_pose(clip, ev["frame"])
    p0, yaw0 = root_frame0(clip)
    bp = to_start_space(pose[ev["part"]][0], p0, yaw0)
    return (bp[0], max(0.105, bp[1]), bp[2])


def mirror_clip(c):
    m = json.loads(json.dumps(c))
    m["name"] = c["name"] + "_ESPEJO"
    for b in m["skeleton"]["bones"]:
        b["name"] = swap_side(b["name"])
        if b.get("parent"):
            b["parent"] = swap_side(b["parent"])
        if "rest_pos" in b:
            b["rest_pos"][0] = -b["rest_pos"][0]
        if "rest_rot" in b:
            x, y, z, w = b["rest_rot"]; b["rest_rot"] = [x, -y, -z, w]
    # el orden de huesos debe seguir siendo padre-antes-que-hijo: se reordena por el original
    tracks = {}
    for bn, tr in c["tracks"].items():
        nt = {}
        if "pos" in tr:
            nt["pos"] = [[k[0], -k[1], k[2], k[3]] for k in tr["pos"]]
        if "rot" in tr:
            nt["rot"] = [[k[0], k[1], -k[2], -k[3], k[4]] for k in tr["rot"]]
        tracks[swap_side(bn)] = nt
    m["tracks"] = tracks
    m["root_bone"] = swap_side(c["root_bone"])
    for e in m.get("events", []):
        if "ball_local" in e:
            e["ball_local"][0] = -e["ball_local"][0]
        if "part" in e:
            e["part"] = swap_side(e["part"])
    mt = m.setdefault("meta", {})
    mt["foot"] = {"L": "R", "R": "L"}.get(mt.get("foot", ""), "")
    if "dir_deg" in mt:
        mt["dir_deg"] = -mt["dir_deg"]
    mt["mirrored"] = True
    mt["mirror_of"] = c["name"]
    return m


def is_symmetric(c):
    mt = c.get("meta", {})
    if mt.get("foot") or abs(mt.get("dir_deg", 0)) > 1e-6:
        return False
    for e in c.get("events", []):
        if abs(e.get("ball_local", [0])[0]) > 0.01:
            return False
    return True


def animation_tres(clip, skel_path, loop):
    fps, frames = clip["fps"], clip["frames"]
    rb = clip["root_bone"]
    p0, yaw0 = root_frame0(clip)
    out = ['[gd_resource type="Animation" format=3]', "", "[resource]", f"length = {fnum(frames / fps)}",
           f"step = {fnum(1.0 / fps)}"]
    if loop:
        out.append("loop_mode = 1")
    ti = 0
    rest = {b["name"]: b for b in clip["skeleton"]["bones"]}
    for b in clip["skeleton"]["bones"]:
        bn = b["name"]
        tr = clip["tracks"].get(bn, {})
        for kind, gtype in (("pos", "position_3d"), ("rot", "rotation_3d")):
            keys = tr.get(kind, [])
            if not keys:
                continue
            vals = []
            for k in keys:
                t = k[0] / fps
                v = list(k[1:])
                if bn == rb and kind == "pos":
                    # sin desplazamiento horizontal: queda la altura y el balanceo vertical
                    v = [0.0, v[1], 0.0]
                if bn == rb and kind == "rot":
                    q = f5anim.q_norm(tuple(v))
                    y = f5anim.q_yaw(q)
                    v = list(f5anim.q_norm(f5anim.q_mul(f5anim.q_from_yaw(-y), q)))
                vals += [t, 1.0] + v
            out += [f'tracks/{ti}/type = "{gtype}"', f"tracks/{ti}/imported = false", f"tracks/{ti}/enabled = true",
                    f'tracks/{ti}/path = NodePath("{skel_path}:{bn}")', f"tracks/{ti}/interp = 1",
                    f"tracks/{ti}/loop_wrap = true",
                    f"tracks/{ti}/keys = PackedFloat32Array({', '.join(fnum(x) for x in vals)})"]
            ti += 1
    return "\n".join(out) + "\n"


def gd_str(s):
    return json.dumps(s, ensure_ascii=False)


def meta_tres(clip, src_rel, src_sha, anim_res, hz, notes):
    mt = clip.get("meta", {})
    times, pos, yaw = extract_root(clip, hz)
    fps, frames = clip["fps"], clip["frames"]
    length = frames / fps
    speed_pct = float(mt.get("speed_pct", 100))
    dist = math.hypot(pos[-1][0], pos[-1][2])
    speed_class = mt.get("speed_class")
    if speed_class is None:
        speed_class = dist / (length / (speed_pct / 100.0)) if length > 0 else 0.0
        notes.append("speed_class calculada desde la raíz [N]")
    dir_deg = mt.get("dir_deg")
    if dir_deg is None:
        dir_deg = math.degrees(yaw[-1]) if clip["category"] in ("TURN", "SIDESTEP") else 0.0
        notes.append("dir_deg calculada [N]")
    evs = []
    for e in clip.get("events", []):
        d = {"type": e.get("type", "contact"), "frame": int(round(e["frame"]))}
        if e.get("part"):
            d["part"] = e["part"]
        if d["type"] == "contact":
            bl = e.get("ball_local")
            if bl is None:
                bl = compute_ball_local(clip, e)
                notes.append(f"ball_local del evento en frame {d['frame']} calculado desde el hueso {e['part']} [N]")
            d["ball_local"] = tuple(bl)
        evs.append(d)
    ev_txt = []
    for d in evs:
        items = []
        for k in sorted(d):
            v = d[k]
            if k == "ball_local":
                items.append(f'"ball_local": Vector3({fnum(v[0])}, {fnum(v[1])}, {fnum(v[2])})')
            elif isinstance(v, str):
                items.append(f'"{k}": {gd_str(v)}')
            else:
                items.append(f'"{k}": {v}')
        ev_txt.append("{\n" + ",\n".join(items) + "\n}")
    er = mt.get("elev_range_deg", [-10, 30])
    tags = mt.get("tags", [])
    if mt.get("loop"):
        tags = list(tags) + ["LOOP"]
    L = ['[gd_resource type="Resource" script_class="AnimClipMeta" format=3]', "",
         '[ext_resource type="Script" path="res://animation/anim_clip_meta.gd" id="1_meta"]', "", "[resource]",
         'script = ExtResource("1_meta")',
         f"clip_name = &{gd_str(clip['name'])}",
         f"source_file = {gd_str(src_rel)}",
         f"source_sha256 = {gd_str(src_sha)}",
         f"category = &{gd_str(clip['category'])}",
         f"system = &{gd_str(mt.get('system', 'otro'))}",
         f"mirrored = {'true' if mt.get('mirrored') else 'false'}",
         f"mirror_of = &{gd_str(mt.get('mirror_of', ''))}",
         f"fps = {fnum(float(fps))}", f"frames = {frames}", f"length_s = {fnum(length)}",
         f"speed_pct = {fnum(speed_pct)}",
         f"foot = &{gd_str(mt.get('foot', ''))}",
         f"tags = PackedStringArray({', '.join(gd_str(t) for t in tags)})",
         f"speed_class = {fnum(float(speed_class))}",
         f"speed_tol = {fnum(float(mt.get('speed_tol', 1.5)))}",
         f"dir_deg = {fnum(float(dir_deg))}",
         f"dir_tol_deg = {fnum(float(mt.get('dir_tol_deg', 45)))}",
         f"elev_range_deg = Vector2({fnum(er[0])}, {fnum(er[1])})",
         f"events = Array[Dictionary]([{', '.join(ev_txt)}])",
         f"root_times = PackedFloat32Array({', '.join(fnum(t) for t in times)})",
         f"root_pos = PackedVector3Array({', '.join(fnum(c) for p in pos for c in p)})",
         f"root_yaw = PackedFloat32Array({', '.join(fnum(y) for y in yaw)})",
         f"animation_path = {gd_str(anim_res)}",
         "compatible = true",
         f"notes = {gd_str('; '.join(notes))}"]
    return "\n".join(L) + "\n", {"speed_class": speed_class, "dir_deg": dir_deg, "events": len(evs),
                                  "root_dist_m": round(dist, 4), "root_yaw_deg": round(math.degrees(yaw[-1]), 2)}


def main(argv):
    args = list(argv)
    def opt(name, default=None, flag=False):
        if name in args:
            i = args.index(name)
            if flag:
                args.pop(i); return True
            v = args[i+1]; del args[i:i+2]; return v
        return default
    espejos = opt("--espejos", flag=True)
    limpiar = opt("--limpiar", flag=True)
    skel = opt("--skeleton-path", "Skeleton3D")
    hz = float(opt("--root-hz", "30"))
    rep_path = opt("--informe")
    src_dir, proj = args[0], args[1]
    imp = os.path.join(proj, "data", "animations", "imported")
    met = os.path.join(proj, "data", "animations", "metadata")
    if limpiar:
        for d in (imp, met):
            shutil.rmtree(d, ignore_errors=True)
    index, report = [], {"converted": [], "rejected": []}
    for path in iter_json([src_dir]):
        clip = f5anim.load_clip(path)
        err, warn = validate_clip(clip)
        if err:
            report["rejected"].append({"file": path, "errors": err}); continue
        src_rel = os.path.relpath(path, src_dir).replace(os.sep, "/")
        sha = f5anim.sha256_file(path)
        variants = [clip]
        if espejos and not is_symmetric(clip) and not clip.get("meta", {}).get("no_mirror"):
            variants.append(mirror_clip(clip))
        for c in variants:
            cat = c["category"]
            anim_res = f"res://data/animations/imported/{cat}/{c['name']}.tres"
            meta_res = f"res://data/animations/metadata/{cat}/{c['name']}.tres"
            notes = list(warn) if c is clip else [f"espejo generado de {clip['name']}"]
            txt_meta, info = meta_tres(c, src_rel, sha, anim_res, hz, notes)
            for res, txt in ((anim_res, animation_tres(c, skel, bool(c.get("meta", {}).get("loop")))), (meta_res, txt_meta)):
                fp = os.path.join(proj, res[len("res://"):])
                os.makedirs(os.path.dirname(fp), exist_ok=True)
                with open(fp, "w", encoding="utf-8") as f:
                    f.write(txt)
            index.append({"name": c["name"], "category": cat, "system": c.get("meta", {}).get("system", "otro"),
                          "mirrored": bool(c.get("meta", {}).get("mirrored")), "meta": meta_res, "animation": anim_res})
            report["converted"].append(dict(name=c["name"], file=src_rel, sha256=sha, **info))
    index.sort(key=lambda e: (e["category"], e["name"]))
    f5anim.write_json(os.path.join(proj, "data", "catalog", "catalogo.json"),
                      {"format": "futbol5_catalog_v1", "count": len(index), "clips": index})
    if rep_path:
        f5anim.write_json(rep_path, report)
    print(f"convertidos: {len(report['converted'])}  rechazados: {len(report['rejected'])}")
    for r in report["rejected"]:
        print("  RECHAZADO", r["file"], r["errors"][:3])
    return 1 if report["rejected"] else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
