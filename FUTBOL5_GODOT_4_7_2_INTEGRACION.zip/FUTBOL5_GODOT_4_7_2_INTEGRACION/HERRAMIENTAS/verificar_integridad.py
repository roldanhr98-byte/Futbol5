"""Inventario SHA-256 de una carpeta (formato compatible con `sha256sum -c`).
  python3 verificar_integridad.py generar CARPETA INVENTARIO.txt [--excluir RUTA_RELATIVA ...]
  python3 verificar_integridad.py verificar CARPETA INVENTARIO.txt
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import f5anim


def files(root, excl):
    for d, dirs, fs in os.walk(root):
        dirs[:] = [x for x in sorted(dirs) if x not in (".godot", "__pycache__")]
        for f in sorted(fs):
            rel = os.path.relpath(os.path.join(d, f), root).replace(os.sep, "/")
            if rel not in excl and not rel.endswith(".pyc"):
                yield rel


def main(argv):
    mode, root, inv = argv[0], argv[1], argv[2]
    excl = set(argv[argv.index("--excluir")+1:]) if "--excluir" in argv else set()
    if mode == "generar":
        excl.add(os.path.relpath(os.path.abspath(inv), os.path.abspath(root)).replace(os.sep, "/"))
        lines = [f"{f5anim.sha256_file(os.path.join(root, r))}  {r}" for r in files(root, excl)]
        with open(inv, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print(len(lines), "archivos inventariados en", inv); return 0
    bad = missing = 0
    n = 0
    listed = set()
    for line in open(inv, encoding="utf-8"):
        line = line.rstrip("\n")
        if not line or line.startswith("#"):
            continue
        h, rel = line.split("  ", 1); n += 1; listed.add(rel)
        p = os.path.join(root, rel)
        if not os.path.exists(p):
            missing += 1; print("FALTA", rel)
        elif f5anim.sha256_file(p) != h:
            bad += 1; print("DISTINTO", rel)
    extra = [r for r in files(root, excl) if r not in listed and os.path.abspath(os.path.join(root, r)) != os.path.abspath(inv)]
    for r in extra:
        print("NO INVENTARIADO", r)
    print(f"{n} verificados, {bad} distintos, {missing} faltan, {len(extra)} no inventariados")
    return 1 if bad or missing else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
