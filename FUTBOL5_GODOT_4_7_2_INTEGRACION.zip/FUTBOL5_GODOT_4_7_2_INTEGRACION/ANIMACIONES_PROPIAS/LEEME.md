# ANIMACIONES_PROPIAS
Poned aquí vuestras animaciones en formato `futbol5_clip_v1` (una carpeta por pack, p. ej. `MIS_CLIPS/`), exportadas con `GODOT_4_7_2/proyecto_futbol5/tools/exportar_clips_json.gd`. Pasos completos: `DOCUMENTACION/MANUAL_MAESTRO_OTRO_CLAUDE.md` §3. `EJEMPLOS_SINTETICOS/` son clips geométricos de prueba (no de juego).
