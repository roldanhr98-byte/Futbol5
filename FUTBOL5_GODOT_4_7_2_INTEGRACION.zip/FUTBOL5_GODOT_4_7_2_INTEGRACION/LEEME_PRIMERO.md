# FUTBOL5_GODOT_4_7_2_INTEGRACION — LÉEME PRIMERO

Paquete técnico para continuar el desarrollo de un juego de Fútbol 5 en **Godot 4.7.2**.

## Contenido

| Carpeta | Qué hay |
|---|---|
| `GODOT_4_7_2/proyecto_futbol5/` | Proyecto Godot: scripts de balón, física, predictor, portería, planificador y ejecutor de contacto, locomoción, conducción, recepción, golpeo, entradas, IA, portero, partido, depuración, exportador `.glb → JSON`, pruebas y configuración |
| `HERRAMIENTAS/` | Herramientas Python: `validar_animaciones.py`, `catalogar.py`, `convertir_a_godot.py`, `verificar_integridad.py`, `generar_ejemplos_sinteticos.py` y `f5anim.py` |
| `ANIMACIONES_PROPIAS/` | Carpeta de trabajo para clips en formato JSON `futbol5_clip_v1`. Incluye `EJEMPLOS_SINTETICOS/`, con 38 clips de prueba `EJ_*` |
| `CATALOGO/` | Catálogos CSV/JSON por categoría, sistema, espejos y compatibilidad |
| `METADATOS/ESQUEMAS/` | Esquema `futbol5_clip_v1.schema.json` |
| `REGLAS/` | Reglas de movimiento, conducción, golpeo, balón, IA y porteros |
| `PRUEBAS/` | Resultados de pruebas de Godot y de las herramientas |
| `OPTIMIZACION/` | Guía Android / Mali-G57 |
| `DOCUMENTACION/` | Manuales y documentos técnicos |
| `INVENTARIO_SHA256.txt` | Hashes para verificar la integridad de los archivos |

El paquete contiene 38 clips sintéticos de ejemplo. La carpeta de animaciones funciona como espacio de entrada para incorporar y procesar clips adicionales mediante el flujo descrito en `DOCUMENTACION/MANUAL_MAESTRO_OTRO_CLAUDE.md`.

## Empezar

1. Leer `DOCUMENTACION/MANUAL_MAESTRO_OTRO_CLAUDE.md` para conocer la arquitectura y el flujo de animaciones.
2. Ejecutar los comandos de verificación de la sección 1 del manual.
3. Consultar `DOCUMENTACION/PLAN_DE_IMPLEMENTACION.md` para las tareas de desarrollo.
4. Consultar `DOCUMENTACION/CALIBRACION_FISICA.md` para ajustar la jugabilidad.

## Verificar integridad

Desde la carpeta raíz del paquete:

```bash
sha256sum -c INVENTARIO_SHA256.txt
```

El inventario permite comprobar que los archivos coinciden con la versión empaquetada. Para regenerarlo después de modificaciones, utilizar `HERRAMIENTAS/verificar_integridad.py`.
