## Configuración centralizada de Fútbol 5 (unidades SI: metros, segundos, radianes salvo que se indique).
##
## Cada parámetro incluye su referencia técnica en el comentario:
##   [N]        decisión nueva de Fútbol 5 (valor inicial de calibración, NO procede de UCS)
##   [UCS-C]    valor por defecto leído en el código de UCS (puede ser distinto del valor que UCS recibe de su servidor)
##   [UCS-C/I]  valor de UCS cuya conversión a unidades SI depende de la escala inferida 1 u = 1/32768 yd a 60 Hz
## Las curvas de velocidad, la tabla de arrastre y los coeficientes de suelo de UCS NO se recuperaron: aquí son [N].
class_name FutbolConfig
extends Resource

@export_group("Simulación")
@export var tick_hz: int = 60                       ## [UCS-C] UCS simula a frames fijos; 60 Hz [I]
@export var predictor_frames: int = 240             ## [N] UCS usa 390 [UCS-C]; 240 (4 s) basta en Fútbol 5
@export var random_seed: int = 12345                ## [N] semilla del RNG determinista del partido

@export_group("Campo")
@export var pitch_length: float = 40.0              ## [N] fútbol 5/futsal
@export var pitch_width: float = 20.0               ## [N]
@export var goal_half_width: float = 1.5            ## [N] portería 3 × 2 m (UCS: 4 yd, fútbol 11)
@export var goal_height: float = 2.0                ## [N]
@export var post_radius: float = 0.04               ## [N] (UCS ≈ 0,044 m sobre el borde interior [UCS-C/I])
@export var goal_depth: float = 1.0                 ## [N] profundidad de la red
@export var goal_line_margin: float = 0.0           ## [N] el balón debe superar la línea entera (UCS lo exige [UCS-C])

@export_group("Balón")
@export var ball_radius: float = 0.105              ## [N] (UCS 0,115 m [UCS-C/I])
@export var ball_mass: float = 0.42                 ## [N]
@export var gravity: float = 9.81                   ## [N] (UCS 98 u/frame² ≈ 9,85 m/s² [UCS-C/I])
@export var air_drag_k: float = 0.012               ## [N] a = −k·|v|·v (1/m). UCS usa una tabla por velocidad (no recuperada [L])
@export var magnus_k: float = 0.0010                ## [N] a = k·(ω × v). UCS: producto vectorial efecto×velocidad [UCS-C estructura]
@export var spin_decay_air: float = 0.15            ## [N] fracción de efecto perdida por segundo en el aire
@export var restitution: float = 0.50               ## [N] rebote vertical (balón de futsal: bote bajo). UCS: valor en ejecución [P]
@export var bounce_min_speed: float = 0.6           ## [N] por debajo, el balón deja de botar y rueda
@export var bounce_spin_transfer: float = 0.35      ## [N] 0..1 convergencia velocidad/efecto hacia rodadura en cada bote. UCS: 25–50 % según la velocidad vertical [UCS-C estructura]
@export var roll_decel: float = 0.9                 ## [N] deceleración de rodadura (m/s²)
@export var roll_stop_speed: float = 0.05           ## [N]
@export var post_restitution: float = 0.55          ## [N]
@export var net_damping: float = 0.15               ## [N] velocidad que conserva el balón al tocar la red

@export_group("Jugador · locomoción")
@export var walk_speed: float = 1.6                 ## [N]
@export var jog_speed: float = 3.5                  ## [N]
@export var run_speed: float = 5.5                  ## [N]
@export var sprint_speed_attr50: float = 7.0        ## [N] valor con atributo 50
@export var sprint_speed_attr99: float = 8.5        ## [N] con atributo 99 (relación ≈ SpeedSprint1/SpeedSprint0 = 1,214 [UCS-C])
@export var accel: float = 6.0                      ## [N] m/s² (UCS: curvas ilegibles [L])
@export var decel: float = 9.0                      ## [N]
@export var turn_rate_deg: float = 360.0            ## [N] giro sin clip, grados/s
@export var turn_no_clip_deg: float = 30.0          ## [UCS-C] 0x555: por debajo no se usa clip de giro
@export var turn_clip_deg: float = 50.0             ## [UCS-C] 0x8e4: a partir de aquí se planifica un clip TURN
@export var turn_speed_loss_at_180: float = 0.5     ## [UCS-C estructura] la fracción de velocidad cae linealmente hasta ½ a 180°
@export var arrive_radius: float = 0.23             ## [UCS-C/I] 0x2000 = ¼ yd

@export_group("Contacto (planificador y ejecución)")
@export var plan_search_frames: int = 12            ## [N] frames de inicio que se prueban (UCS: n variable)
@export var playback_scale_min: float = 0.875       ## [UCS-C] 0x380/1024
@export var playback_scale_max: float = 1.2         ## [UCS-C] 0x4cc/1024
@export var approach_turn_deg_per_tick: float = 2.11 ## [UCS-C] 0x60 en 16384/vuelta
@export var tol_control: float = 0.057              ## [UCS-C/I] 0x800 = 1/16 yd (toque y control)
@export var tol_kick: float = 0.114                 ## [UCS-C/I] 0x1000 = 1/8 yd (golpeo)
@export var tol_height_factor_below: float = 3.0    ## [UCS-C] la altura admite −3·tol … +tol
@export var wrong_foot_cost: float = 0.30           ## [N] (UCS +0x90000 en sus unidades de coste)
## Paso máximo de corrección de raíz por frame y categoría, en metros [UCS-C/I] (tabla 0x13a480 × factor).
@export var max_correction_per_tick := {
	"CONTROL": 0.206, "KICK": 0.343, "KICKSETPIECE": 0.26, "TACKLE": 0.043,
	"TACKLESLIDE": 0.064, "GKSAVE": 0.114, "TURN": 0.0,
}

@export_group("Conducción")
@export var dribble_speed_scale_attr50: float = 0.80  ## [UCS-C] TechniqueDribbleSpeedScale0 820/1024
@export var dribble_speed_scale_attr99: float = 0.934 ## [UCS-C] 956/1024
@export var touch_ahead_min: float = 0.69           ## [UCS-C/I] 0x6000 (parado)
@export var touch_ahead_mid: float = 0.80           ## [UCS-C/I] 0x7000 (a la fracción de velocidad 0,3125)
@export var touch_ahead_max: float = 1.03           ## [UCS-C/I] 0x9000 (velocidad máxima)
@export var special_touch_pct_attr99: float = 50.0  ## [UCS-C] TechniqueSpecialControlPercent1
@export var touch_interval_min: float = 0.35        ## [N] s entre toques a velocidad máxima
@export var touch_interval_max: float = 0.70        ## [N] s entre toques caminando

@export_group("Golpeo")
@export var kick_speed_max_attr50: float = 30.8     ## [UCS-C/I] KickPower0 18382 u/frame
@export var kick_speed_max_attr99: float = 36.2     ## [UCS-C/I] KickPower1 21627 u/frame
@export var kick_speed_min: float = 6.7             ## [UCS-C/I] 0xfa5
@export var wrong_foot_power: float = 0.95          ## [UCS-C] 3891/4096
@export var back_kick_power_attr50: float = 0.875   ## [UCS-C] TechniqueRotPowerScaleBW0 896·4/4096
@export var back_kick_power_attr99: float = 0.9375  ## [UCS-C] …1 960·4/4096
@export var err_fw_deg_attr50: float = 4.1          ## [UCS-C/I] TechniqueKickErrorFW0 187 (16384/vuelta)
@export var err_fw_deg_attr99: float = 1.7          ## [UCS-C/I] …1 78
@export var err_bw_deg_attr50: float = 11.7         ## [UCS-C/I] TechniqueKickErrorBW0 533
@export var err_bw_deg_attr99: float = 5.9          ## [UCS-C/I] …1 270
@export var pass_time_short_frames: float = 50.0    ## [UCS-C] tiempo de vuelo a 5 yd
@export var pass_time_long_frames: float = 195.0    ## [UCS-C] tiempo de vuelo a 60 yd
@export var pass_ref_short_m: float = 4.57          ## [UCS-C/I] 5 yd
@export var pass_ref_long_m: float = 54.86          ## [UCS-C/I] 60 yd
@export var pass_time_scale: float = 0.8            ## [N] Fútbol 5 juega más rápido: escala el tiempo UCS
@export var lofted_height_threshold: float = 0.457  ## [UCS-C/I] destino > ½ yd ⇒ pase elevado
@export var cross_apex_height: float = 2.6          ## [N]
@export var shot_dist_no_power: float = -62.2       ## [UCS-C/I] ShotDistNoPower −68 yd (mapa distancia → potencia)
@export var shot_dist_max_power: float = 29.3       ## [UCS-C/I] ShotDistMaxPower 32 yd
@export var shot_speed_scale: float = 0.85          ## [N] Fútbol 5: tiros más cortos
@export var max_kick_distance: float = 54.86        ## [UCS-C/I] 60 yd
@export var curl_spin_attr50: float = 6.0           ## [N] rad/s (UCS TechniqueCurl0/1 = 500/8000, unidad desconocida [P])
@export var curl_spin_attr99: float = 14.0          ## [N]

@export_group("Defensa e IA")
@export var max_active_tackles: int = 1             ## [UCS-C]
@export var max_active_presses: int = 2             ## [UCS-C]
@export var marking_dist: float = 1.37              ## [UCS-C/I] MarkingDist 49152 = 1,5 yd
@export var react_frames_attr50: float = 21.0       ## [UCS-C] ResponsePlayerMoveOOP0
@export var react_frames_attr99: float = 1.0        ## [UCS-C] …1
@export var slide_range: float = 2.29               ## [UCS-C/I] StrengthSlideTackleRange 2,5 yd
@export var tackle_range_passive_50: float = 0.69   ## [UCS-C/I] 0,75 yd
@export var tackle_range_passive_99: float = 1.14   ## [UCS-C/I] 1,25 yd
@export var tackle_range_press_50: float = 1.37     ## [UCS-C/I] 1,5 yd
@export var tackle_range_press_99: float = 2.29     ## [UCS-C/I] 2,5 yd
@export var ai_think_hz: float = 10.0               ## [N] frecuencia de decisión de la IA
@export var possession_limit_s: float = 20.0        ## [UCS-C] PossessionTimerLimit 1200 frames

@export_group("Portero")
@export var gk_react_frames_attr50: float = 15.0    ## [UCS-C] ResponseGKSave0
@export var gk_react_frames_attr99: float = 4.0     ## [UCS-C] ResponseGKSave1
@export var gk_reach_min_50: float = 1.25           ## [UCS-C/I] TechniqueGKMinSaveDist0 1,37 yd
@export var gk_reach_min_99: float = 1.65           ## [UCS-C/I] …1 1,8 yd
@export var gk_reach_max_50: float = 2.29           ## [UCS-C/I] TechniqueGKMaxSaveDist0 2,5 yd
@export var gk_reach_max_99: float = 2.74           ## [UCS-C/I] …1 3 yd
@export var gk_line_offset: float = 0.9             ## [N] distancia a la línea en la bisectriz
@export var gk_sweep_dist: float = 6.0              ## [N] distancia a la que sale a por balones sueltos


## Interpolación por atributo de UCS (fn 0x470704) [UCS-C]: P0 con atributo 50, P1 con 99, lineal entre medias.
static func lerp_attr(attr: int, p0: float, p1: float) -> float:
	var a := clampi(attr, 50, 99)
	return p0 + (p1 - p0) * float(a - 50) / 49.0


func dt() -> float:
	return 1.0 / float(tick_hz)


## Tiempo de vuelo de un pase según distancia (UCS: interpolación lineal sobre la distancia al cuadrado [UCS-C]).
func pass_flight_frames(dist: float) -> float:
	var d0 := pass_ref_short_m * pass_ref_short_m
	var d1 := pass_ref_long_m * pass_ref_long_m
	var t := clampf((dist * dist - d0) / (d1 - d0), 0.0, 1.0)
	return lerpf(pass_time_short_frames, pass_time_long_frames, t) * pass_time_scale


## Distancia del siguiente toque según la fracción de velocidad 0..1 (UCS fn 0x47fd5c, dos tramos lineales [UCS-C]).
func touch_ahead(speed_frac: float) -> float:
	var f := clampf(speed_frac, 0.0, 1.0)
	var knee := 0x1400 / float(0x4000)
	if f <= knee:
		return lerpf(touch_ahead_min, touch_ahead_mid, f / knee)
	return lerpf(touch_ahead_mid, touch_ahead_max, (f - knee) / (1.0 - knee))
