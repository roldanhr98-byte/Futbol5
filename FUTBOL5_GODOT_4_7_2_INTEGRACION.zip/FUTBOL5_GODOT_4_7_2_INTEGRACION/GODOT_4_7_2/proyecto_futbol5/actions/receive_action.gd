## Recepción / control orientado: mismo planificador CONTROL que la conducción (UCS no tiene selector propio [UCS-C]).
## Diferencia [N]: la velocidad de salida se decide por la intención (amortiguar, orientar, encadenar con conducción).
class_name ReceiveAction
extends RefCounted

var cfg: FutbolConfig
var planner: ContactPlanner
var _connected := {}


func _init(config: FutbolConfig, contact_planner: ContactPlanner) -> void:
	cfg = config
	planner = contact_planner


## then_dir_yaw: dirección de salida; exit_speed: m/s del balón tras el control (0 = amortiguar del todo).
func request(p: Player, ball: Ball, then_dir_yaw: float, exit_speed: float) -> bool:
	if p.executor.active():
		return false
	var req := {"dir": then_dir_yaw, "speed": p.velocity.length(), "max_start": 30, "max_turn_deg": 90.0, "kind": &"receive"}
	var plan := planner.plan(p, p.catalog.group(&"CONTROL"), ball.predictor, req)
	if not plan.valid():
		return false
	plan.payload = {"dir": then_dir_yaw, "exit_speed": exit_speed}
	p.start_action(plan)
	if not _connected.has(p.get_instance_id()):
		_connected[p.get_instance_id()] = true
		p.executor.contact_ok.connect(_on_contact.bind(p, ball))
	return true


func _on_contact(plan: ContactPlan, p: Player, ball: Ball) -> void:
	if plan.kind != &"receive":
		return
	var dir_yaw: float = plan.payload["dir"]
	var v := Vector3(sin(dir_yaw), 0.0, cos(dir_yaw)) * float(plan.payload["exit_speed"])
	ball.register_contact(p.player_id, p.team, 5, v, Vector3.UP.cross(v) / cfg.ball_radius, &"receive")
