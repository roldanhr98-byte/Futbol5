## Golpeo: entrada (usuario o IA) → destino → tipo → planificador KICK → evento → velocidad resuelta → física.
## Reglas de UCS 0x54f488 [UCS-C]: tiro por distancia (ShotDist*), pase por tiempo de vuelo 50–195 frames sobre la
## distancia², raso si alcanza, si no elevado; potencia máx por atributo; pie no hábil ×0,95; golpeo hacia atrás pierde
## potencia; error angular por técnica (adelante/atrás). Detalles propios de Fútbol 5 marcados [N].
class_name KickAction
extends RefCounted

enum Kind { PASE_CORTO, PASE_LARGO, PASE_ELEVADO, CENTRO, TIRO, TIRO_DE_PRIMERA }

var cfg: FutbolConfig
var planner: ContactPlanner
var _connected := {}
var rng := RandomNumberGenerator.new()


func _init(config: FutbolConfig, contact_planner: ContactPlanner) -> void:
	cfg = config
	planner = contact_planner
	rng.seed = cfg.random_seed + 23


## Calcula la velocidad y el efecto del balón para un golpeo desde `from` hacia `target`. Devuelve
## {vel, spin, frames, lofted}. `power01` solo afecta a TIRO (0..1, [N]).
func solve(p: Player, kind: Kind, from: Vector3, target: Vector3, power01: float = 1.0, curl: float = 0.0) -> Dictionary:
	var vmax := FutbolConfig.lerp_attr(p.a("power"), cfg.kick_speed_max_attr50, cfg.kick_speed_max_attr99)
	var to := target - from
	var flat := Vector3(to.x, 0.0, to.z)
	var dist := minf(flat.length(), cfg.max_kick_distance)
	var dir := flat.normalized() if flat.length() > 0.001 else p.facing()
	target = from + dir * dist + Vector3(0.0, to.y, 0.0)
	var spin_mag := FutbolConfig.lerp_attr(p.a("technique"), cfg.curl_spin_attr50, cfg.curl_spin_attr99) * curl
	var spin := Vector3(0.0, spin_mag, 0.0)
	var out := {}
	match kind:
		Kind.TIRO, Kind.TIRO_DE_PRIMERA:
			# potencia por distancia (UCS map(dist, ShotDistNoPower, ShotDistMaxPower, 0, pMax) [UCS-C]) × escala [N]
			var f := clampf((dist - cfg.shot_dist_no_power) / (cfg.shot_dist_max_power - cfg.shot_dist_no_power), 0.0, 1.0)
			var speed := maxf(cfg.kick_speed_min, vmax * f * cfg.shot_speed_scale * clampf(power01, 0.2, 1.0))
			var frames := maxi(4, int(round(dist / speed * cfg.tick_hz)))
			var v := TrajectorySolver.solve_air(from, target, frames, spin, cfg)
			out = {"vel": v, "spin": spin, "frames": frames, "lofted": true}
		Kind.CENTRO:
			# [N] centro: elevado con vértice a cross_apex_height
			var t := sqrt(2.0 * maxf(0.5, cfg.cross_apex_height - from.y) / cfg.gravity) * 2.0
			var frames_c := maxi(10, int(round(t * cfg.tick_hz)))
			out = {"vel": TrajectorySolver.solve_air(from, target, frames_c, spin, cfg), "spin": spin, "frames": frames_c, "lofted": true}
		_:
			var frames_p := int(round(cfg.pass_flight_frames(dist)))
			var lofted := kind == Kind.PASE_ELEVADO or target.y - cfg.ball_radius > cfg.lofted_height_threshold
			var v2 := Vector3.INF
			if not lofted:
				v2 = TrajectorySolver.solve_ground(from, target, frames_p, vmax, cfg)
				if v2 == Vector3.INF:
					lofted = true          # el raso no alcanza: elevado (UCS [UCS-C])
			if lofted:
				v2 = TrajectorySolver.solve_air(from, target, frames_p, spin, cfg)
			out = {"vel": v2, "spin": spin, "frames": frames_p, "lofted": lofted}
	# límite de velocidad (el pie no hábil se aplica en el contacto, según el clip elegido)
	var v3: Vector3 = out["vel"]
	var cap := vmax
	if v3.length() > cap:
		v3 = v3.normalized() * cap
	if v3.length() < cfg.kick_speed_min and kind in [Kind.TIRO, Kind.TIRO_DE_PRIMERA]:
		v3 = v3.normalized() * cfg.kick_speed_min
	out["vel"] = v3
	return out


## Error angular por técnica (UCS 0x54f298 [UCS-C]): interpola entre error adelante y atrás según el giro.
func apply_error(p: Player, v: Vector3, back_angle: float, pressure01: float) -> Vector3:
	var fw := FutbolConfig.lerp_attr(p.a("technique"), cfg.err_fw_deg_attr50, cfg.err_fw_deg_attr99)
	var bw := FutbolConfig.lerp_attr(p.a("technique"), cfg.err_bw_deg_attr50, cfg.err_bw_deg_attr99)
	var t := clampf((absf(back_angle) - deg_to_rad(22.5)) / deg_to_rad(157.5), 0.0, 1.0)
	var err := deg_to_rad(lerpf(fw, bw, t)) * clampf(pressure01, 0.0, 1.0)
	var e := rng.randf_range(-err, err)
	return v.rotated(Vector3.UP, e)


## Pide el golpeo: planifica un clip KICK cuya salida apunte al destino; en el contacto vuelve a resolver desde la
## posición real del balón (así la trayectoria es exacta aunque el contacto se haya desplazado unos cm) [N].
func request(p: Player, ball: Ball, kind: Kind, target: Vector3, power01: float = 1.0, curl: float = 0.0, pressure01: float = 0.0) -> bool:
	if p.executor.active():
		return false
	var dir_yaw := atan2(target.x - ball.state.pos.x, target.z - ball.state.pos.z)
	var group := p.catalog.group(&"KICK")
	var req := {"dir": dir_yaw, "speed": p.velocity.length(), "max_start": 20 if kind == Kind.TIRO_DE_PRIMERA else 12, "max_turn_deg": 90.0, "kind": &"kick"}
	var plan := planner.plan(p, group, ball.predictor, req)
	if not plan.valid():
		return false
	plan.payload = {"kind": kind, "target": target, "power": power01, "curl": curl, "pressure": pressure01}
	p.start_action(plan)
	if not _connected.has(p.get_instance_id()):
		_connected[p.get_instance_id()] = true
		p.executor.contact_ok.connect(_on_contact.bind(p, ball))
	return true


func _on_contact(plan: ContactPlan, p: Player, ball: Ball) -> void:
	if plan.kind != &"kick":
		return
	var pl := plan.payload
	var res := solve(p, pl["kind"], ball.state.pos, pl["target"], pl["power"], pl["curl"])
	var v: Vector3 = res["vel"]
	if plan.meta.foot != &"" and plan.meta.foot != p.strong_foot:
		v *= cfg.wrong_foot_power
	var back := angle_difference(p.yaw, atan2(v.x, v.z))
	if absf(back) > deg_to_rad(22.5):
		v *= FutbolConfig.lerp_attr(p.a("technique"), cfg.back_kick_power_attr50, cfg.back_kick_power_attr99)
	v = apply_error(p, v, back, pl["pressure"])
	ball.register_contact(p.player_id, p.team, 8, v, res["spin"], &"kick")
