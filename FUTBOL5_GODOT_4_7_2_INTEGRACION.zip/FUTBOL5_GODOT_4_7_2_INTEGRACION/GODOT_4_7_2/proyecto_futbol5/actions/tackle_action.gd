## Entradas: alcance por fuerza (UCS 0x48200c / 0x481d4c [UCS-C]) + planificador TACKLE/TACKLESLIDE + registro de contacto
## con prioridad alta; si coincide con un toque del rival en el mismo frame, el balón mezcla 7/8–1/8 y el perdedor
## hace el duelo de fuerza (UCS 0x46f968 / 0x4734ac [UCS-C]).
class_name TackleAction
extends RefCounted

var cfg: FutbolConfig
var planner: ContactPlanner
var _connected := {}


func _init(config: FutbolConfig, contact_planner: ContactPlanner) -> void:
	cfg = config
	planner = contact_planner


func reach(p: Player, slide: bool, pressing: bool) -> float:
	if slide:
		return cfg.slide_range
	if pressing:
		return FutbolConfig.lerp_attr(p.a("strength"), cfg.tackle_range_press_50, cfg.tackle_range_press_99)
	return FutbolConfig.lerp_attr(p.a("strength"), cfg.tackle_range_passive_50, cfg.tackle_range_passive_99)


func request(p: Player, ball: Ball, slide: bool, pressing: bool) -> bool:
	if p.executor.active():
		return false
	var b := ball.predictor.at(18)
	if b.pos.y > 0.9 or Vector2(b.pos.x - p.global_position.x, b.pos.z - p.global_position.z).length() > reach(p, slide, pressing):
		return false
	var cat := &"TACKLESLIDE" if slide else &"TACKLE"
	var plan := planner.plan(p, p.catalog.group(cat), ball.predictor, {"speed": p.velocity.length(), "max_start": 6, "kind": &"tackle"})
	if not plan.valid():
		return false
	p.start_action(plan)
	if not _connected.has(p.get_instance_id()):
		_connected[p.get_instance_id()] = true
		p.executor.contact_ok.connect(_on_contact.bind(p, ball))
	return true


func _on_contact(plan: ContactPlan, p: Player, ball: Ball) -> void:
	if plan.kind != &"tackle":
		return
	var away := p.facing() * 4.0          # [N] el balón sale despejado hacia delante del defensor
	ball.register_contact(p.player_id, p.team, 9, away, Vector3.ZERO, &"tackle")


## Duelo de fuerza (UCS 0x4734ac [UCS-C]): true si `p` cae.
static func strength_duel_falls(p: Player, rival: Player, rng: RandomNumberGenerator) -> bool:
	var mine := FutbolConfig.lerp_attr(p.a("strength"), 0.0, 200.0)
	var theirs := FutbolConfig.lerp_attr(rival.a("strength"), 0.0, 200.0) if rival != null else 0.0
	return rng.randi_range(0, 99) < int(theirs - mine) + 50
