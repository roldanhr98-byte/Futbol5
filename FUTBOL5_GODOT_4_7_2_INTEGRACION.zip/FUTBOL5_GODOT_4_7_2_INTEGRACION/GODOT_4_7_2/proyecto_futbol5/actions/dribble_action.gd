## Conducción: cada toque se PLANIFICA (clip CONTROL cuyo evento coincide con el balón previsto) y, al validarse,
## el balón se lanza hacia el punto del siguiente toque. Nunca se pega el balón al pie.
## UCS: 0x47e8c4 → 0x47f274 → 0x473590 → 0x4721d0 modo 2 → 0x47fd5c [UCS-C estructura].
class_name DribbleAction
extends RefCounted

var cfg: FutbolConfig
var planner: ContactPlanner
var _connected := {}
var rng := RandomNumberGenerator.new()


func _init(config: FutbolConfig, contact_planner: ContactPlanner) -> void:
	cfg = config
	planner = contact_planner
	rng.seed = cfg.random_seed + 11


## Pide el próximo toque. dir_yaw: hacia dónde quiere llevar el balón el jugador. Devuelve true si hay plan.
func request_touch(p: Player, ball: Ball, dir_yaw: float) -> bool:
	if p.executor.active():
		return false
	var special_pct := FutbolConfig.lerp_attr(p.a("technique"), 0.0, cfg.special_touch_pct_attr99)
	var req := {
		"dir": dir_yaw,
		"speed": p.velocity.length() * FutbolConfig.lerp_attr(p.a("technique"), cfg.dribble_speed_scale_attr50, cfg.dribble_speed_scale_attr99) / cfg.dribble_speed_scale_attr99,
		"allow_special": rng.randf() * 100.0 < special_pct,
		"forbid_tags": PackedStringArray(["HEAD"]),
		"max_turn_deg": 75.0,
		"kind": &"dribble",
	}
	var plan := planner.plan(p, p.catalog.group(&"CONTROL"), ball.predictor, req)
	if not plan.valid():
		return false
	plan.payload = {"dir": dir_yaw}
	p.start_action(plan)
	if not _connected.has(p.get_instance_id()):
		_connected[p.get_instance_id()] = true
		p.executor.contact_ok.connect(_on_contact.bind(p, ball))
	return true


## Contacto validado: velocidad del balón hacia el punto del siguiente toque.
func _on_contact(plan: ContactPlan, p: Player, ball: Ball) -> void:
	if plan.kind != &"dribble":
		return
	var dir_yaw: float = plan.payload.get("dir", p.yaw)
	var dir := Vector3(sin(dir_yaw), 0.0, cos(dir_yaw))
	var speed := p.desired_speed
	var frac := clampf(speed / p.max_speed(), 0.0, 1.0)
	var interval := lerpf(cfg.touch_interval_max, cfg.touch_interval_min, frac)
	var ahead := cfg.touch_ahead(frac)
	var frames := maxi(6, int(round(interval * cfg.tick_hz)))
	var target := p.global_position + dir * (speed * interval + ahead)
	target.y = cfg.ball_radius
	var from := ball.state.pos
	var v := TrajectorySolver.solve_ground(from, target, frames, 12.0, cfg)
	if v == Vector3.INF:
		v = dir * 12.0
	ball.register_contact(p.player_id, p.team, 4, v, Vector3.UP.cross(v) / cfg.ball_radius, &"dribble")
