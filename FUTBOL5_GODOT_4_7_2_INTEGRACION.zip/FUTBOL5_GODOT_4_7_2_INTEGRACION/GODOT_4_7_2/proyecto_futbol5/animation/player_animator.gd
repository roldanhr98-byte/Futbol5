## Reproduce un clip con control explícito de fase (necesario para la sincronización pie‑balón).
## Si hay un AnimationPlayer asignado, lo mueve por seek(); si no (pruebas headless), solo lleva el tiempo.
## La raíz NO la mueve el AnimationPlayer: el convertidor saca el desplazamiento de raíz a los metadatos y el jugador
## se desplaza con root_delta() (como UCS, que guarda la raíz en animdb aparte de la pose [UCS-C]).
class_name PlayerAnimator
extends RefCounted

var catalog: AnimCatalog
var anim_player: AnimationPlayer = null     ## opcional
var library_name := &"futbol5"
var meta: AnimClipMeta = null
var t := 0.0                ## tiempo de CLIP (s); avanza dt · rate · nominal_rate()
var rate := 1.0             ## multiplicador de fase (UCS +0x350 / +0x4b0 [UCS-C])
var finished := true
var loop := false


func _init(cat: AnimCatalog) -> void:
	catalog = cat


func play(m: AnimClipMeta, start_t: float = 0.0, play_rate: float = 1.0, looping: bool = false) -> void:
	meta = m
	t = start_t
	rate = play_rate
	finished = false
	loop = looping
	if anim_player != null:
		var anim := catalog.get_animation(m.clip_name)
		if anim != null:
			var lib: AnimationLibrary
			if anim_player.has_animation_library(library_name):
				lib = anim_player.get_animation_library(library_name)
			else:
				lib = AnimationLibrary.new()
				anim_player.add_animation_library(library_name, lib)
			if not lib.has_animation(m.clip_name):
				lib.add_animation(m.clip_name, anim)
			anim_player.play(String(library_name) + "/" + String(m.clip_name), 0.12)
			anim_player.speed_scale = 0.0          # la fase la controla este script
			anim_player.seek(t, true)


func duration() -> float:
	if meta == null:
		return 0.0
	return meta.length_s


## Segundos reales que faltan hasta el tiempo de clip clip_t con el rate actual.
func seconds_until(clip_t: float) -> float:
	if meta == null:
		return 0.0
	return (clip_t - t) / maxf(1e-6, rate * meta.nominal_rate())


## Avanza la fase y devuelve el desplazamiento de raíz del tick en espacio del clip (sin girar).
func advance(dt: float) -> Vector3:
	if meta == null or finished:
		return Vector3.ZERO
	var before := meta.root_at(t)
	t += dt * rate * meta.nominal_rate()
	var d := duration()
	if t >= d:
		if loop and d > 0.0:
			var wrap_delta := meta.root_at(d) - before
			t = fmod(t, d)
			before = meta.root_at(0.0)
			wrap_delta += meta.root_at(t) - before
			_sync_player()
			return wrap_delta
		t = d
		finished = true
	_sync_player()
	return meta.root_at(t) - before


func yaw_delta(prev_t: float) -> float:
	if meta == null:
		return 0.0
	return meta.yaw_at(t) - meta.yaw_at(prev_t)


func _sync_player() -> void:
	if anim_player != null and anim_player.current_animation != "":
		anim_player.seek(t, true)
