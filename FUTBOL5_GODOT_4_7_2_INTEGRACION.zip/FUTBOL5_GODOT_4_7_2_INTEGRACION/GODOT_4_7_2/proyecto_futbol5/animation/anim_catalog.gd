## Catálogo indexado de clips propios. Carga SOLO metadatos al arrancar (pequeños) y los Animation bajo demanda,
## con caché LRU acotada para móviles. Índice: res://data/catalog/catalogo.json (lo genera convertir_a_godot.py).
class_name AnimCatalog
extends RefCounted

var metas := {}                    ## StringName -> AnimClipMeta
var by_category := {}              ## StringName -> Array[AnimClipMeta]
var by_system := {}
var missing: PackedStringArray     ## entradas del índice cuyo recurso no se pudo cargar
var max_cached_animations := 64    ## [N] tamaño de la caché LRU de Animation

var _anim_cache := {}              ## StringName -> Animation
var _lru: Array[StringName] = []


func load_index(index_path: String = "res://data/catalog/catalogo.json") -> int:
	var f := FileAccess.open(index_path, FileAccess.READ)
	if f == null:
		push_error("No se puede abrir el índice del catálogo: %s" % index_path)
		return 0
	var data = JSON.parse_string(f.get_as_text())
	if typeof(data) != TYPE_DICTIONARY or not data.has("clips"):
		push_error("Índice de catálogo inválido")
		return 0
	for entry in data["clips"]:
		var meta := load(entry["meta"]) as AnimClipMeta
		if meta == null:
			missing.append(str(entry.get("name", entry["meta"])))
			continue
		add_meta(meta)
	return metas.size()


func add_meta(meta: AnimClipMeta) -> void:
	metas[meta.clip_name] = meta
	if not by_category.has(meta.category):
		by_category[meta.category] = []
	by_category[meta.category].append(meta)
	if not by_system.has(meta.system):
		by_system[meta.system] = []
	by_system[meta.system].append(meta)


func group(category: StringName) -> Array:
	return by_category.get(category, [])


func get_meta_by_name(clip_name: StringName) -> AnimClipMeta:
	return metas.get(clip_name, null)


## Animation del clip, cargado bajo demanda (null en pruebas sin recursos de pose).
func get_animation(clip_name: StringName) -> Animation:
	if _anim_cache.has(clip_name):
		_lru.erase(clip_name)
		_lru.append(clip_name)
		return _anim_cache[clip_name]
	var meta := get_meta_by_name(clip_name)
	if meta == null or meta.animation_path.is_empty() or not ResourceLoader.exists(meta.animation_path):
		return null
	var anim := load(meta.animation_path) as Animation
	_anim_cache[clip_name] = anim
	_lru.append(clip_name)
	while _lru.size() > max_cached_animations:
		var old: StringName = _lru.pop_front()
		_anim_cache.erase(old)
	return anim


## Comprobación de integridad: todos los clips del índice cargados y con datos coherentes.
func validate() -> PackedStringArray:
	var problems: PackedStringArray = []
	for n in missing:
		problems.append("falta recurso: %s" % n)
	for m in metas.values():
		var meta: AnimClipMeta = m
		if meta.frames <= 0 or meta.fps <= 0.0:
			problems.append("%s: frames/fps inválidos" % meta.clip_name)
		if meta.category in [&"CONTROL", &"KICK", &"KICKSETPIECE", &"TACKLE", &"TACKLESLIDE", &"GKSAVE"] and not meta.has_contact():
			problems.append("%s: categoría de contacto sin evento de contacto" % meta.clip_name)
		if not meta.root_times.is_empty() and meta.root_times.size() != meta.root_pos.size():
			problems.append("%s: raíz con tamaños distintos" % meta.clip_name)
	return problems
