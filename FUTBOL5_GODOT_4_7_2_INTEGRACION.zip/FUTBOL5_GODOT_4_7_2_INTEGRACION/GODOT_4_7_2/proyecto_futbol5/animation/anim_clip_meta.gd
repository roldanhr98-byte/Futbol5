## Metadatos de un clip propio de Fútbol 5. Lo genera herramientas/convertir_a_godot.py desde el JSON del clip.
## Equivale funcionalmente al registro de animdb de UCS (evento de contacto, rangos, pie, raíz) [UCS-C estructura],
## pero los datos son VUESTROS: se autoran o se calculan desde vuestras animaciones.
##
## Espacios: la raíz y la posición del balón en el evento están en el espacio de la RAÍZ AL INICIO DEL CLIP:
## +Z hacia delante (hacia donde mira el jugador al empezar), +X a la izquierda del jugador, +Y arriba. Metros.
class_name AnimClipMeta
extends Resource

@export var clip_name: StringName              ## nombre original EXACTO (también nombre del Animation)
@export var source_file: String                ## archivo JSON original (ruta relativa a ANIMACIONES_PROPIAS/)
@export var source_sha256: String              ## hash del JSON original
@export var category: StringName               ## LOCO, STAND, TURN, SIDESTEP, CONTROL, KICK, KICKSETPIECE, TACKLE, TACKLESLIDE, FALL, GETUP, STUMBLE, GKSAVE, GKTHROW, GKKICK, THROW, NIS, OTHER
@export var system: StringName                 ## sistema del juego: locomocion, conduccion, control, giro, frenado, pase, centro, tiro, entrada, caida, recuperacion, disputa, portero, balon_parado, otro
@export var mirrored := false
@export var mirror_of: StringName              ## clip fuente si es espejo
@export var fps := 60.0
@export var frames := 0
@export var length_s := 0.0
@export var speed_pct := 100.0                 ## velocidad de reproducción nominal (UCS f60 [UCS-C])
@export var foot: StringName                   ## "L", "R" o "" (UCS bits 0x80/0x100 [UCS-C])
@export var tags: PackedStringArray            ## HEAD, SPECIAL, DRIBBLE, FIRST_TOUCH, JOSTLE, BALL_IN_HANDS…
@export var speed_class := 0.0                 ## m/s de entrada para el que está pensado (UCS f0a/f0c [UCS-C estructura])
@export var speed_tol := 1.5                   ## m/s
@export var dir_deg := 0.0                     ## dirección (respecto al frente inicial) en la que sale el balón o gira el cuerpo (UCS f12)
@export var dir_tol_deg := 45.0                ## tolerancia angular (UCS f1a)
@export var elev_range_deg := Vector2(-10, 30) ## rango de elevación del golpeo (UCS f16/f18 [I])
@export var events: Array[Dictionary] = []     ## {type:"contact", frame:int, part:"foot_r"|..., ball_local:Vector3}
@export var root_times: PackedFloat32Array     ## s
@export var root_pos: PackedVector3Array       ## desplazamiento de raíz (x, 0, z) en espacio inicial
@export var root_yaw: PackedFloat32Array       ## giro de raíz acumulado (rad, + = izquierda)
@export var animation_path: String             ## res:// del Animation convertido
@export var compatible := true                 ## false si el validador encontró un problema
@export var notes: String


func has_contact() -> bool:
	for e in events:
		if e.get("type", "") == "contact":
			return true
	return false


func contact_event(i: int = 0) -> Dictionary:
	var n := 0
	for e in events:
		if e.get("type", "") == "contact":
			if n == i:
				return e
			n += 1
	return {}


## Multiplicador de reproducción nominal (UCS f60: velocidad en % [UCS-C]).
func nominal_rate() -> float:
	return speed_pct / 100.0


## Tiempo de CLIP (s) del evento de contacto i.
func contact_time(i: int = 0) -> float:
	var e := contact_event(i)
	if e.is_empty():
		return -1.0
	return float(e["frame"]) / fps


func root_at(t: float) -> Vector3:
	return _sample_vec(root_pos, t)


func yaw_at(t: float) -> float:
	if root_times.is_empty():
		return 0.0
	var tt := t
	if tt <= root_times[0]:
		return root_yaw[0]
	for k in range(root_times.size() - 1):
		if tt <= root_times[k + 1]:
			var a := (tt - root_times[k]) / maxf(1e-6, root_times[k + 1] - root_times[k])
			return lerpf(root_yaw[k], root_yaw[k + 1], a)
	return root_yaw[root_yaw.size() - 1]


func _sample_vec(arr: PackedVector3Array, t: float) -> Vector3:
	if root_times.is_empty() or arr.is_empty():
		return Vector3.ZERO
	var tt := t
	if tt <= root_times[0]:
		return arr[0]
	for k in range(root_times.size() - 1):
		if tt <= root_times[k + 1]:
			var a := (tt - root_times[k]) / maxf(1e-6, root_times[k + 1] - root_times[k])
			return arr[k].lerp(arr[k + 1], a)
	return arr[arr.size() - 1]


## Velocidad media de la raíz (m/s) en reproducción nominal: se usa para sincronizar zancada y velocidad real.
func root_speed() -> float:
	var dur := length_s / nominal_rate()
	if dur <= 0.0 or root_pos.is_empty():
		return 0.0
	return Vector2(root_pos[root_pos.size() - 1].x, root_pos[root_pos.size() - 1].z).length() / dur
