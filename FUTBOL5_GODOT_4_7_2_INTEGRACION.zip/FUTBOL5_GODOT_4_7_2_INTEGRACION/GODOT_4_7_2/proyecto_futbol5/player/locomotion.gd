## Locomoción: entrada (destino o dirección + velocidad pedida) → velocidad con aceleración/frenado → orientación →
## selección de clip LOCO/STAND/TURN → fase sincronizada con la velocidad real.
## Estructura de UCS 0x47b278 / 0x47c29c / 0x480b54 [UCS-C]: llegada a ¼ yd, giro sin clip < 30°, clip de giro ≥ 50°,
## pérdida de velocidad al girar. Velocidades, aceleraciones y curvas: [N] (las de UCS no se recuperaron [L]).
class_name Locomotion
extends RefCounted

var cfg: FutbolConfig
var gait: StringName = &"STAND"
var turning := false


func _init(config: FutbolConfig) -> void:
	cfg = config


func gait_for_speed(v: float) -> StringName:
	if v < 0.25:
		return &"STAND"
	if v < (cfg.walk_speed + cfg.jog_speed) * 0.5:
		return &"WALK"
	if v < (cfg.jog_speed + cfg.run_speed) * 0.5:
		return &"JOG"
	if v < (cfg.run_speed + cfg.sprint_speed_attr50) * 0.5:
		return &"RUN"
	return &"SPRINT"


func tick(p: Player, dt: float) -> void:
	var want := Vector3.ZERO
	if p.desired_target != Vector3.INF:
		var to := p.desired_target - p.global_position
		to.y = 0.0
		var dist := to.length()
		if dist > cfg.arrive_radius:
			# frenar a tiempo: v² = 2·a·d
			var v_arrive := sqrt(2.0 * cfg.decel * maxf(0.0, dist - cfg.arrive_radius))
			want = to / dist * minf(minf(p.desired_speed, p.max_speed()), v_arrive)
	var cur := p.velocity
	# giro: si la diferencia es grande se pierde velocidad (UCS: lineal hasta ½ a 180° [UCS-C estructura])
	if want.length() > 0.01 and cur.length() > 0.5:
		var turn := absf(angle_difference(atan2(cur.x, cur.z), atan2(want.x, want.z)))
		if turn > deg_to_rad(cfg.turn_no_clip_deg):
			want *= 1.0 - (1.0 - cfg.turn_speed_loss_at_180) * turn / PI
		turning = turn > deg_to_rad(cfg.turn_clip_deg)
	else:
		turning = false
	var diff := want - cur
	var rate := cfg.accel if want.length() >= cur.length() else cfg.decel
	var step := rate * dt
	if diff.length() > step:
		diff = diff.normalized() * step
	p.velocity = cur + diff
	p.global_position += p.velocity * dt
	# orientación hacia la velocidad (o hacia el objetivo si está casi parado)
	if p.velocity.length() > 0.3:
		var target_yaw := atan2(p.velocity.x, p.velocity.z)
		var max_turn := deg_to_rad(cfg.turn_rate_deg) * dt
		p.yaw += clampf(angle_difference(p.yaw, target_yaw), -max_turn, max_turn)
	_update_clip(p, dt)


## Elige el clip del grupo según la marcha y ajusta la fase para que la zancada coincida con la velocidad real.
func _update_clip(p: Player, dt: float) -> void:
	var g := gait_for_speed(p.velocity.length())
	var cat := &"STAND" if g == &"STAND" else (&"TURN" if turning else &"LOCO")
	var need_new := p.animator.meta == null or p.animator.finished or p.animator.meta.category != cat or g != gait
	gait = g
	if need_new:
		var m := pick_clip(p, cat, p.velocity.length())
		if m != null:
			p.animator.play(m, 0.0, 1.0, cat != &"TURN")
	if p.animator.meta != null and cat == &"LOCO":
		var rs := p.animator.meta.root_speed()
		if rs > 0.01:
			p.animator.rate = clampf(p.velocity.length() / rs, 0.6, 1.6)   # [N] sincronía de zancada
	p.animator.advance(dt)          # en locomoción la raíz la mueve el motor, no el clip


## Selector LOCO/STAND/TURN: clip de la categoría con speed_class más cercana (UCS: identificador f0a [UCS-C]).
func pick_clip(p: Player, cat: StringName, speed: float) -> AnimClipMeta:
	var best: AnimClipMeta = null
	var best_cost := INF
	for c in p.catalog.group(cat):
		var m: AnimClipMeta = c
		if not m.compatible:
			continue
		var cost := absf(m.speed_class - speed)
		if cat == &"TURN" and p.velocity.length() > 0.01 and p.desired_target != Vector3.INF:
			var to := p.desired_target - p.global_position
			var turn := angle_difference(p.yaw, atan2(to.x, to.z))
			cost += absf(turn - deg_to_rad(m.dir_deg)) * 4.0
		if cost < best_cost:
			best_cost = cost
			best = m
	return best
