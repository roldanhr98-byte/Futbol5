## Planificador genérico de contacto: elige (clip, frame de inicio, orientación) cuyo evento coincide con el balón previsto.
## Traducción a Fútbol 5 del patrón común de UCS (SEL‑2 0x47f274, SEL‑3 0x475b40, SEL‑4 0x4817c4, SEL‑5 0x4330d8 [UCS-C]):
##   para cada frame futuro i y cada clip del grupo: balón previsto en i + tEv, jugador previsto en i,
##   error = balón − (jugador + evento girado); viable si la corrección cabe en el paso máximo; coste mínimo.
## Pesos del coste: [N] (UCS: pesos propios en sus unidades, solo parcialmente recuperados).
class_name ContactPlanner
extends RefCounted

var cfg: FutbolConfig
var rng := RandomNumberGenerator.new()

## Pesos del coste [N]
var w_err := 40.0          ## por m² de corrección por frame
var w_dir := 2.0           ## por rad² de desvío de dirección
var w_speed := 0.15        ## por (m/s)² de diferencia de velocidad
var w_turn := 1.0          ## por rad² de giro de orientación necesario
var w_height := 30.0       ## por m² de diferencia de altura
var w_random := 0.01       ## desempate aleatorio (UCS rnd² [UCS-C])


func _init(config: FutbolConfig) -> void:
	cfg = config
	rng.seed = cfg.random_seed + 7


## request: {
##   dir: float (yaw deseado para el balón tras el contacto, o NAN = libre),
##   speed: float (velocidad actual del jugador, m/s),
##   allow_special: bool, require_tags: PackedStringArray, forbid_tags: PackedStringArray,
##   max_start: int (frames de inicio a probar), max_turn_deg: float, kind: StringName }
func plan(player: Player, clips: Array, predictor: BallPredictor, request: Dictionary) -> ContactPlan:
	var best := ContactPlan.new()
	var max_start: int = request.get("max_start", cfg.plan_search_frames)
	var want_dir: float = request.get("dir", NAN)
	var speed: float = request.get("speed", player.velocity.length())
	var max_turn := deg_to_rad(float(request.get("max_turn_deg", 60.0)))
	var allow_special: bool = request.get("allow_special", false)
	var require_tags: PackedStringArray = request.get("require_tags", PackedStringArray())
	var forbid_tags: PackedStringArray = request.get("forbid_tags", PackedStringArray())
	var dt := cfg.dt()
	for c in clips:
		var m: AnimClipMeta = c
		if not m.compatible or not m.has_contact():
			continue
		if not allow_special and m.tags.has("SPECIAL"):
			continue
		var skip := false
		for tg in require_tags:
			if not m.tags.has(tg):
				skip = true
		for tg in forbid_tags:
			if m.tags.has(tg):
				skip = true
		if skip:
			continue
		var ev := m.contact_event(0)
		var t_ev := maxi(1, int(round(m.contact_time(0) / m.nominal_rate() / dt)))
		var local: Vector3 = ev.get("ball_local", Vector3.ZERO)
		var max_step: float = cfg.max_correction_per_tick.get(String(m.category), 0.1)
		var speed_cost := w_speed * pow(speed - m.speed_class, 2.0)
		if absf(speed - m.speed_class) > m.speed_tol * 2.0:
			continue
		for i in range(max_start + 1):
			var j := player.predict_position(i)
			var facing := player.predict_yaw(i)
			# orientación del clip: si se pide dirección, se gira el clip para que el balón salga hacia ella
			var yaw := facing
			var dir_cost := 0.0
			if not is_nan(want_dir):
				yaw = want_dir - deg_to_rad(m.dir_deg)
				var turn := angle_difference(facing, yaw)
				if absf(turn) > max_turn:
					continue
				dir_cost = w_turn * turn * turn
			# el contacto ocurre en la fase de jugadores del tick i + t_ev − 1: el balón habrá dado i + t_ev − 1 pasos
			var b := predictor.at(i + t_ev - 1)
			var contact_world := j + local.rotated(Vector3.UP, yaw)
			var err := Vector2(b.pos.x - contact_world.x, b.pos.z - contact_world.z)
			var per_frame := err.length() / maxf(1.0, float(t_ev))
			if per_frame > max_step:
				continue
			var dh := b.pos.y - local.y
			var cost := w_err * per_frame * per_frame * 3600.0 + speed_cost + dir_cost + w_height * dh * dh
			if m.foot != &"" and m.foot != player.strong_foot:
				cost += cfg.wrong_foot_cost
			cost += w_random * rng.randf()
			if cost < best.cost:
				best.meta = m
				best.cost = cost
				best.start_in = i
				best.frames_to_contact = t_ev
				best.yaw = yaw
				best.ball_at_contact = b.pos
				var natural := j + m.root_at(m.contact_time(0)).rotated(Vector3.UP, yaw)
				best.root_natural = Vector3(natural.x, 0.0, natural.z)
				var tgt := b.pos - local.rotated(Vector3.UP, yaw) + m.root_at(m.contact_time(0)).rotated(Vector3.UP, yaw)
				best.root_target = Vector3(tgt.x, 0.0, tgt.z)
				best.kind = request.get("kind", &"")
	return best
