## Ejecuta un ContactPlan: reproduce el clip, fija la fase para que el evento caiga en el frame previsto, reparte la
## corrección de raíz con paso máximo por categoría, gira como mucho N°/frame, valida en el frame del contacto y
## llama a la acción. Traducción de UCS 0x473590 + 0x473670 + 0x4721d0 + 0x473370 [UCS-C estructura].
class_name ContactExecutor
extends RefCounted

signal contact_ok(plan: ContactPlan)
signal contact_failed(plan: ContactPlan, reason: StringName)

var cfg: FutbolConfig
var plan: ContactPlan = null
var frames_left := 0          ## cuenta atrás hasta el contacto (UCS +0x4a9)
var waiting_start := 0        ## frames hasta empezar el clip (plan.start_in)
var correction_left := Vector3.ZERO
var done_contact := false
var _clip_started := false     ## el clip del plan se arranca SIEMPRE de cero, aunque sea el mismo que el anterior


func _init(config: FutbolConfig) -> void:
	cfg = config


func active() -> bool:
	return plan != null


func begin(p: ContactPlan) -> void:
	plan = p
	waiting_start = p.start_in
	frames_left = p.frames_to_contact
	correction_left = p.correction()
	done_contact = false
	_clip_started = false


func cancel() -> void:
	plan = null


## Un tick. Devuelve el desplazamiento de raíz que debe aplicar el jugador en este tick (mundo).
func tick(player: Player, ball: Ball) -> Vector3:
	if plan == null:
		return Vector3.ZERO
	var dt := cfg.dt()
	if waiting_start > 0:
		waiting_start -= 1
		if waiting_start == 0:
			_start_clip(player)
		return player.velocity * dt          # sigue con la locomoción hasta empezar
	if not _clip_started:
		_start_clip(player)
	var delta := Vector3.ZERO
	if not done_contact:
		# --- aproximación: raíz del clip + parte de la corrección (paso máximo por categoría) ---
		var clip_delta := player.animator.advance(dt).rotated(Vector3.UP, plan.yaw)
		delta = Vector3(clip_delta.x, 0.0, clip_delta.z)
		if frames_left > 0:
			var max_step: float = cfg.max_correction_per_tick.get(String(plan.meta.category), 0.1)
			var step := correction_left / float(frames_left)
			if step.length() > max_step:
				step = step.normalized() * max_step
			delta += step
			correction_left -= step
			frames_left -= 1
			# giro limitado hacia la orientación del plan
			var max_turn := deg_to_rad(cfg.approach_turn_deg_per_tick)
			player.yaw += clampf(angle_difference(player.yaw, plan.yaw + player.animator.meta.yaw_at(player.animator.t)), -max_turn, max_turn)
			if frames_left == 0:
				player.animator.t = plan.meta.contact_time(0)      # encaje exacto de la fase (UCS: cuenta == 1)
				_contact(player, ball, delta)
	else:
		var clip_delta2 := player.animator.advance(dt).rotated(Vector3.UP, plan.yaw)
		delta = Vector3(clip_delta2.x, 0.0, clip_delta2.z)
		player.yaw = plan.yaw + player.animator.meta.yaw_at(player.animator.t)
		if player.animator.finished:
			plan = null
	return delta


func _start_clip(player: Player) -> void:
	_clip_started = true
	player.animator.play(plan.meta, 0.0, 1.0)
	player.yaw = plan.yaw


func _contact(player: Player, ball: Ball, pending_delta: Vector3) -> void:
	done_contact = true
	var tol := cfg.tol_kick if plan.meta.category in [&"KICK", &"KICKSETPIECE"] else cfg.tol_control
	var local: Vector3 = plan.meta.contact_event(0).get("ball_local", Vector3.ZERO)
	# punto de contacto previsto = raíz actual + (evento − raíz del clip en el evento), girado al marco del clip
	var rel := local - plan.meta.root_at(plan.meta.contact_time(0))
	var foot_point := player.global_position + pending_delta + rel.rotated(Vector3.UP, plan.yaw)
	var b := ball.state.pos
	var planar := Vector2(b.x - foot_point.x, b.z - foot_point.z).length()
	var dh := b.y - local.y
	if ball.held_by != null:
		contact_failed.emit(plan, &"balon_en_manos")
		return
	if planar > tol * 2.0 or dh > tol * 2.0 or dh < -cfg.tol_height_factor_below * tol * 2.0:
		contact_failed.emit(plan, &"fuera_de_tolerancia")
		return
	contact_ok.emit(plan)
