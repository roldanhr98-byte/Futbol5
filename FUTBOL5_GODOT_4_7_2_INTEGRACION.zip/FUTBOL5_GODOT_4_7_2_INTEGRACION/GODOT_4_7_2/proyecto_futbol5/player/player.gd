## Jugador de campo o portero. Dueño de su posición y orientación; el balón NO lo mueve nunca.
## Dos modos de desplazamiento [N]:
##   - locomoción: motor cinemático (velocidad/aceleración) + clip LOCO/STAND/TURN sincronizado por velocidad;
##   - acción de contacto: raíz del clip + corrección planificada (ContactExecutor), como UCS [UCS-C].
class_name Player
extends Node3D

signal action_finished(kind: StringName)

@export var player_id := 0
@export var team := 0
@export var is_goalkeeper := false
@export var strong_foot: StringName = &"R"
## Atributos 50..99 (UCS idx 0..5 [UCS-C]): velocidad, fuerza, potencia, técnica, reacción, portero
@export var attr := {"speed": 70, "strength": 70, "power": 70, "technique": 70, "response": 70, "gk": 50}

var cfg: FutbolConfig
var catalog: AnimCatalog
var animator: PlayerAnimator
var executor: ContactExecutor
var locomotion: Locomotion
var yaw := 0.0                       ## rad; 0 = mirando a +Z
var velocity := Vector3.ZERO         ## m/s (plano XZ)
var desired_target := Vector3.INF    ## destino de movimiento (UCS +0x3a8)
var desired_speed := 0.0             ## m/s pedida
var _clip_start_pos := Vector3.ZERO


func setup(config: FutbolConfig, cat: AnimCatalog) -> void:
	cfg = config
	catalog = cat
	animator = PlayerAnimator.new(cat)
	executor = ContactExecutor.new(cfg)
	locomotion = Locomotion.new(cfg)
	var ap := get_node_or_null("AnimationPlayer") as AnimationPlayer
	if ap != null:
		animator.anim_player = ap


func facing() -> Vector3:
	return Vector3(sin(yaw), 0.0, cos(yaw))


func a(name: String) -> int:
	return int(attr.get(name, 50))


func max_speed() -> float:
	return FutbolConfig.lerp_attr(a("speed"), cfg.sprint_speed_attr50, cfg.sprint_speed_attr99)


## Posición prevista dentro de i frames (para los planificadores). [N] velocidad constante salvo acción en curso.
func predict_position(i: int) -> Vector3:
	if executor.active():
		var p := executor.plan
		var k := clampi(i, 0, maxi(1, executor.frames_left))
		return global_position.lerp(p.root_target, float(k) / float(maxi(1, executor.frames_left)))
	return global_position + velocity * (float(i) * cfg.dt())


func predict_yaw(_i: int) -> float:
	return yaw


func root_start_of_clip() -> Vector3:
	return _clip_start_pos


## Empieza una acción de contacto ya planificada.
func start_action(plan: ContactPlan) -> void:
	executor.begin(plan)
	if plan.start_in == 0:
		_clip_start_pos = global_position


## Tick del jugador (lo llama MatchSim en orden fijo). ball se usa para validar contactos.
func tick(ball: Ball) -> void:
	var dt := cfg.dt()
	if executor.active():
		var was_waiting := executor.waiting_start > 0
		var delta := executor.tick(self, ball)
		if was_waiting and executor.waiting_start == 0:
			_clip_start_pos = global_position
		global_position += delta
		velocity = delta / dt
		if not executor.active():
			action_finished.emit(&"contact")
		return
	locomotion.tick(self, dt)
