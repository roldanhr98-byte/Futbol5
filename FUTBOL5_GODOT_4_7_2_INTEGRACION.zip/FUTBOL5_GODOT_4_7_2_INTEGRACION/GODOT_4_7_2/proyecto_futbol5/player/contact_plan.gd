## Resultado de un planificador de contacto (UCS: estructura del plan de 0x47f274 [UCS-C]).
class_name ContactPlan
extends RefCounted

var meta: AnimClipMeta
var start_in := 0            ## frames hasta empezar el clip (0 = ya)
var frames_to_contact := 0   ## frames desde el inicio del clip hasta el evento
var yaw := 0.0               ## orientación de la raíz al empezar el clip (rad)
var ball_at_contact := Vector3.ZERO   ## balón previsto en el frame del contacto
var root_target := Vector3.ZERO       ## dónde debe estar la raíz en el contacto
var root_natural := Vector3.ZERO      ## dónde estaría sin corrección
var cost := INF
var kind: StringName = &""            ## dribble, receive, kick, tackle, save…
var payload := {}                     ## datos de la acción (destino del golpeo, etc.)


func correction() -> Vector3:
	return root_target - root_natural


func valid() -> bool:
	return meta != null and cost < INF
