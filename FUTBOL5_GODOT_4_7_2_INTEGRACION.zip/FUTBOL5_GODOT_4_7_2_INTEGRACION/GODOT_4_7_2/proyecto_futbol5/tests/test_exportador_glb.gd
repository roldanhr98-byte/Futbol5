## Prueba del exportador: crea con Godot un personaje mínimo (Skeleton3D + AnimationPlayer con KICK_PRUEBA_R),
## lo guarda como .glb en user:// y comprueba que tools/exportar_clips_json.gd lo puede leer.
## Uso: godot --headless --path . --script res://tests/test_exportador_glb.gd -- --salida RUTA.glb
extends SceneTree


func _initialize() -> void:
	process_frame.connect(_run, CONNECT_ONE_SHOT)


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var out := args[args.find("--salida") + 1] if args.has("--salida") else "user://prueba.glb"
	var r := Node3D.new(); r.name = "PersonajePrueba"
	var sk := Skeleton3D.new(); sk.name = "Skeleton3D"; r.add_child(sk); sk.owner = r
	for b in [["hips", -1, Vector3(0, 0.95, 0)], ["thigh_r", 0, Vector3(-0.1, -0.05, 0)], ["foot_r", 1, Vector3(0, -0.85, 0.05)]]:
		var i := sk.add_bone(b[0])
		if b[1] >= 0:
			sk.set_bone_parent(i, b[1])
		sk.set_bone_rest(i, Transform3D(Basis(), b[2]))
	sk.reset_bone_poses()
	# malla mínima con piel (un triángulo por hueso) para que el glTF guarde un esqueleto real, como un personaje
	var stl := SurfaceTool.new()
	stl.set_skin_weight_count(SurfaceTool.SKIN_4_WEIGHTS)
	stl.begin(Mesh.PRIMITIVE_TRIANGLES)
	for bi in sk.get_bone_count():
		var o := sk.get_bone_global_rest(bi).origin
		for v in [Vector3(0, 0, 0), Vector3(0.05, 0, 0), Vector3(0, 0.05, 0)]:
			stl.set_bones(PackedInt32Array([bi, 0, 0, 0]))
			stl.set_weights(PackedFloat32Array([1, 0, 0, 0]))
			stl.add_vertex(o + v)
	var mi := MeshInstance3D.new(); mi.name = "Cuerpo"; mi.mesh = stl.commit()
	var skin := Skin.new()
	for bi in sk.get_bone_count():
		skin.add_named_bind(sk.get_bone_name(bi), sk.get_bone_global_rest(bi).affine_inverse())
	mi.skin = skin
	sk.add_child(mi); mi.owner = r
	mi.skeleton = NodePath("..")
	var ap := AnimationPlayer.new(); ap.name = "AnimationPlayer"; r.add_child(ap); ap.owner = r
	var a := Animation.new(); a.length = 0.8
	var tp := a.add_track(Animation.TYPE_POSITION_3D); a.track_set_path(tp, "Skeleton3D:hips")
	var tr := a.add_track(Animation.TYPE_ROTATION_3D); a.track_set_path(tr, "Skeleton3D:thigh_r")
	for k in 9:
		var t := k * 0.1
		a.position_track_insert_key(tp, t, Vector3(0, 0.95, 1.5 * t))
		a.rotation_track_insert_key(tr, t, Quaternion(Vector3.RIGHT, sin(t * 6.0) * 0.8))
	var lib := AnimationLibrary.new(); lib.add_animation("KICK_PRUEBA_R", a); ap.add_animation_library("", lib)
	root.add_child(r)
	var doc := GLTFDocument.new(); var st := GLTFState.new()
	var e := doc.append_from_scene(r, st)
	if e == OK:
		e = doc.write_to_filesystem(st, out)
	print("glb de prueba: ", out, " -> ", error_string(e))
	quit(0 if e == OK else 1)
