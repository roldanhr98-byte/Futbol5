## Pruebas automáticas del núcleo (física, solucionadores, predictor, portería, catálogo, conducción planificada).
## Uso: godot --headless --path . --script res://tests/run_tests.gd
## Requiere haber convertido clips (los sintéticos de ANIMACIONES_PROPIAS/EJEMPLOS_SINTETICOS sirven) con
## HERRAMIENTAS/convertir_a_godot.py. Sale con código 1 si falla alguna prueba.
extends SceneTree

var cfg: FutbolConfig
var fails := 0
var passes := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	if ok:
		passes += 1
		print("  OK    ", name, "  ", detail)
	else:
		fails += 1
		printerr("  FALLA ", name, "  ", detail)


func _initialize() -> void:
	# los nodos solo están dentro del árbol cuando arranca el bucle principal
	process_frame.connect(_run, CONNECT_ONE_SHOT)


func _run() -> void:
	cfg = load("res://data/config/futbol_config_default.tres") as FutbolConfig
	if cfg == null:
		cfg = FutbolConfig.new()
	print("== física del balón")
	test_physics()
	print("== solucionadores")
	test_solvers()
	print("== predictor")
	test_predictor()
	print("== portería")
	test_goal()
	print("== catálogo")
	var cat := test_catalog()
	print("== conducción planificada (integración)")
	if cat != null and not cat.group(&"CONTROL").is_empty():
		test_dribble(cat)
	else:
		check("hay clips CONTROL convertidos", false, "convierte los ejemplos antes de probar")
	print("\nRESULTADO: %d OK, %d FALLAS" % [passes, fails])
	quit(1 if fails > 0 else 0)


func test_physics() -> void:
	var s := BallState.new()
	s.pos = Vector3(0, 2.0, 0)
	var n := 0
	while not (s.pos.y <= cfg.ball_radius + 1e-4) and n < 600:
		BallPhysics.step(s, cfg, cfg.dt())
		n += 1
	var t_ideal := sqrt(2.0 * (2.0 - cfg.ball_radius) / cfg.gravity)
	check("caída libre 2 m ≈ sqrt(2h/g)", absf(n * cfg.dt() - t_ideal) < 0.05, "%.3f s vs %.3f s" % [n * cfg.dt(), t_ideal])
	# bote: restitución
	s = BallState.new()
	s.pos = Vector3(0, 1.0, 0)
	var peak := 0.0
	var bounced := false
	for i in range(240):
		BallPhysics.step(s, cfg, cfg.dt())
		if s.vel.y > 0.0:
			bounced = true
		if bounced:
			peak = maxf(peak, s.pos.y)
	var expect := cfg.ball_radius + (1.0 - cfg.ball_radius) * cfg.restitution * cfg.restitution
	check("altura del primer bote ≈ e²·h", absf(peak - expect) < 0.08, "%.3f m vs %.3f m" % [peak, expect])
	# rodadura hasta pararse: distancia ≈ v²/(2a)
	s = BallState.new()
	s.pos = Vector3(0, cfg.ball_radius, 0)
	s.vel = Vector3(0, 0, 6.0)
	s.grounded = true
	var k := 0
	while s.vel.length() > 0.0 and k < 3000:
		BallPhysics.step(s, cfg, cfg.dt())
		k += 1
	var d_ideal := 36.0 / (2.0 * cfg.roll_decel)
	check("rodadura 6 m/s se para a v²/2a", absf(s.pos.z - d_ideal) / d_ideal < 0.05, "%.2f m vs %.2f m" % [s.pos.z, d_ideal])
	# determinismo
	var a := BallState.new(); a.pos = Vector3(0, 0.5, 0); a.vel = Vector3(3, 6, 15); a.spin = Vector3(0, 20, 0)
	var b := a.copy()
	for i in range(300):
		BallPhysics.step(a, cfg, cfg.dt())
		BallPhysics.step(b, cfg, cfg.dt())
	check("paso determinista (mismo estado → mismo resultado)", a.pos == b.pos and a.vel == b.vel)
	# efecto: con spin vertical el balón se desvía lateralmente
	var c := BallState.new(); c.pos = Vector3(0, 0.3, 0); c.vel = Vector3(0, 4, 20); c.spin = Vector3(0, 30, 0)
	for i in range(40):
		BallPhysics.step(c, cfg, cfg.dt())
	check("Magnus: spin +Y curva hacia +X con vel +Z", c.pos.x > 0.05, "x = %.3f m" % c.pos.x)


func test_solvers() -> void:
	var from := Vector3(0, cfg.ball_radius, 0)
	for tgt in [Vector3(2, 1.5, 15), Vector3(-5, 0.4, 25), Vector3(0, 2.2, 10)]:
		var frames := 45
		var v := TrajectorySolver.solve_air(from, tgt, frames, Vector3.ZERO, cfg)
		var s := BallState.new(); s.pos = from; s.vel = v
		for i in range(frames):
			BallPhysics.step(s, cfg, cfg.dt())
		check("solve_air llega a %s en %d frames" % [tgt, frames], s.pos.distance_to(tgt) < 0.05, "error %.3f m" % s.pos.distance_to(tgt))
	var tgt2 := Vector3(0, cfg.ball_radius, 12)
	var v2 := TrajectorySolver.solve_ground(from, tgt2, 90, 25.0, cfg)
	var s2 := BallState.new(); s2.pos = from; s2.vel = v2; s2.grounded = true
	for i in range(90):
		BallPhysics.step(s2, cfg, cfg.dt())
	check("solve_ground 12 m en 1.5 s", absf(s2.pos.z - 12.0) < 0.05, "z = %.3f" % s2.pos.z)
	check("solve_ground imposible → INF", TrajectorySolver.solve_ground(from, Vector3(0, 0, 200), 30, 10.0, cfg) == Vector3.INF)


func test_predictor() -> void:
	var b := Ball.new()
	root.add_child(b)
	b.setup(cfg)
	b.state.pos = Vector3(0, 0.5, 0); b.state.vel = Vector3(1, 5, 10); b.state.grounded = false
	b.predictor.reset(b.state)
	var pred := b.predictor.at(100).pos
	for i in range(100):
		b.physics_tick()
	check("predictor = simulación real a 100 frames", pred.distance_to(b.state.pos) < 1e-4, "dif %.6f m" % pred.distance_to(b.state.pos))
	b.queue_free()


func test_goal() -> void:
	var b := Ball.new()
	root.add_child(b)
	b.setup(cfg)
	var scored := [0]
	for g in b.goals:
		g.goal_scored.connect(func(_s): scored[0] += 1)
	var L := cfg.pitch_length * 0.5
	b.state.pos = Vector3(0, 0.6, L - 3.0); b.state.vel = Vector3(0, 1.5, 12); b.state.grounded = false
	for i in range(120):
		b.physics_tick()
	check("tiro centrado entra: 1 gol", scored[0] == 1, "goles %d" % scored[0])
	check("la red retiene el balón", b.state.pos.z <= L + cfg.goal_depth + 0.01, "z = %.2f" % b.state.pos.z)
	scored[0] = 0
	var posts := [0]
	b.post_hit.connect(func(): posts[0] += 1)
	b.state.pos = Vector3(cfg.goal_half_width + cfg.post_radius, 0.8, L - 3.0); b.state.vel = Vector3(0, 0.5, 14); b.state.grounded = false
	for i in range(60):
		b.physics_tick()
	check("balón al poste rebota (sin gol)", posts[0] >= 1 and scored[0] == 0 and b.state.vel.z < 0.0, "postes %d goles %d vz %.2f" % [posts[0], scored[0], b.state.vel.z])
	scored[0] = 0
	b.state.pos = Vector3(0, 0.6, L - 3.0); b.state.vel = Vector3(0, 9, 12); b.state.grounded = false
	for i in range(120):
		b.physics_tick()
	check("tiro alto por encima del larguero: sin gol", scored[0] == 0)
	b.queue_free()


func test_catalog() -> AnimCatalog:
	var cat := AnimCatalog.new()
	if not FileAccess.file_exists("res://data/catalog/catalogo.json"):
		check("existe data/catalog/catalogo.json", false, "ejecuta HERRAMIENTAS/convertir_a_godot.py")
		return null
	var n := cat.load_index()
	check("índice cargado", n > 0, "%d clips" % n)
	var probs := cat.validate()
	check("validación del catálogo sin problemas", probs.is_empty(), str(probs.slice(0, 5)))
	var any: AnimClipMeta = cat.metas.values()[0]
	var anim := cat.get_animation(any.clip_name)
	check("Animation cargable", anim != null and anim.get_track_count() > 0, "%s pistas %d" % [any.clip_name, anim.get_track_count() if anim else 0])
	var mirrors := 0
	for m in cat.metas.values():
		if (m as AnimClipMeta).mirrored:
			mirrors += 1
	print("    clips: %d  espejos: %d  categorías: %s" % [n, mirrors, str(cat.by_category.keys())])
	return cat


func test_dribble(cat: AnimCatalog) -> void:
	var ball := Ball.new()
	root.add_child(ball)
	ball.setup(cfg)
	var p := Player.new()
	root.add_child(p)
	p.setup(cfg, cat)
	p.attr["technique"] = 80
	p.global_position = Vector3(0, 0, -10)
	p.velocity = Vector3(0, 0, 3.5)
	p.desired_speed = 3.5
	p.desired_target = Vector3(0, 0, 30)
	ball.state.pos = Vector3(0, cfg.ball_radius, -8.8)
	ball.state.vel = Vector3(0, 0, 3.6)
	ball.state.grounded = true
	ball.predictor.reset(ball.state)
	var planner := ContactPlanner.new(cfg)
	var dribble := DribbleAction.new(cfg, planner)
	var touches := [0]
	var failed := [0]
	ball.touched.connect(func(_id, _k): touches[0] += 1)
	p.executor.contact_failed.connect(func(_pl, _r): failed[0] += 1)
	var max_sep := 0.0
	var no_plan := 0
	for tick in range(int(6.0 * cfg.tick_hz)):
		if not p.executor.active():
			if not dribble.request_touch(p, ball, 0.0):
				no_plan += 1
		p.tick(ball)
		ball.apply_pending()
		ball.physics_tick()
		if tick > 30:
			max_sep = maxf(max_sep, Vector2(ball.state.pos.x - p.global_position.x, ball.state.pos.z - p.global_position.z).length())
	check("conducción: varios toques validados en 6 s", touches[0] >= 5, "toques %d, fallos %d, ticks sin plan %d" % [touches[0], failed[0], no_plan])
	check("conducción: el balón no se escapa (sep. máx < 3 m)", max_sep < 3.0, "sep. máx %.2f m" % max_sep)
	check("conducción: el jugador avanza", p.global_position.z > 5.0, "z final %.2f" % p.global_position.z)
	check("conducción: sin contactos fallidos", failed[0] == 0, "fallos %d" % failed[0])
