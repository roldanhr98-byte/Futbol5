## Carga todos los scripts del proyecto y falla si alguno no compila. Uso:
##   godot --headless --path . --script res://tests/check_scripts.gd
extends SceneTree


func _init() -> void:
	var bad := 0
	var total := 0
	for dir in ["res://core", "res://ball", "res://animation", "res://player", "res://actions", "res://input", "res://ai", "res://goalkeeper", "res://match", "res://debug"]:
		for f in DirAccess.get_files_at(dir):
			if not f.ends_with(".gd"):
				continue
			total += 1
			var s := load(dir + "/" + f) as GDScript
			if s == null or not s.can_instantiate():
				bad += 1
				printerr("NO COMPILA: ", dir + "/" + f)
	print("scripts: %d  con error: %d" % [total, bad])
	quit(1 if bad > 0 else 0)
