## Exporta las animaciones de VUESTRO modelo (.glb / .gltf, o una escena .tscn con Skeleton3D + AnimationPlayer)
## al formato de clip futbol5_clip_v1, para pasarlas luego por HERRAMIENTAS/validar_animaciones.py y
## HERRAMIENTAS/convertir_a_godot.py.
##
## Uso (headless):
##   godot --headless --path . --script res://tools/exportar_clips_json.gd -- \
##         --entrada RUTA.glb --salida CARPETA [--raiz hips] [--fps 60] [--eventos eventos.json] [--girar180]
##
## - Categoría: por el prefijo del nombre de la animación (LOCO_, STAND_, TURN_, CONTROL_, KICK_, GKSAVE_, TACKLE_…);
##   si no tiene prefijo conocido queda OTHER (podéis editar el JSON).
## - Eventos de contacto: archivo opcional --eventos con {"NOMBRE_CLIP": [{"frame": 14, "part": "foot_r"}], …}
##   o {"NOMBRE_CLIP": {"events": [...], "meta": {"foot": "R", "speed_class": 3.5, ...}}}.
##   Si el evento solo trae "part", el convertidor calcula ball_local con la posición de ese hueso [N].
## - --girar180: si vuestro modelo mira a −Z, gira todo 180° para cumplir la convención +Z = frente.
extends SceneTree

const CATS := ["LOCO", "STAND", "TURN", "SIDESTEP", "CONTROL", "KICKSETPIECE", "KICK", "TACKLESLIDE", "TACKLE", "FALL",
	"GETUP", "STUMBLE", "GKSAVE", "GKTHROW", "GKKICK", "THROW", "NIS"]


func _initialize() -> void:
	process_frame.connect(_run, CONNECT_ONE_SHOT)


func _arg(args: PackedStringArray, name: String, def: String = "") -> String:
	var i := args.find(name)
	return args[i + 1] if i >= 0 and i + 1 < args.size() else def


func _find(n: Node, cls: String) -> Node:
	if n.is_class(cls):
		return n
	for c in n.get_children():
		var r := _find(c, cls)
		if r != null:
			return r
	return null


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var src := _arg(args, "--entrada")
	var out := _arg(args, "--salida")
	var fps := float(_arg(args, "--fps", "60"))
	var flip := args.has("--girar180")
	if src.is_empty() or out.is_empty():
		printerr("uso: --entrada RUTA.glb --salida CARPETA [--raiz hueso] [--fps 60] [--eventos eventos.json] [--girar180]")
		quit(2)
		return
	var scene_root: Node = null
	if src.get_extension().to_lower() in ["glb", "gltf"]:
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		if doc.append_from_file(src, state) != OK:
			printerr("no se puede leer ", src); quit(1); return
		scene_root = doc.generate_scene(state)
	else:
		var ps := load(src) as PackedScene
		if ps == null:
			printerr("no se puede cargar ", src); quit(1); return
		scene_root = ps.instantiate()
	root.add_child(scene_root)
	var skel := _find(scene_root, "Skeleton3D") as Skeleton3D
	var ap := _find(scene_root, "AnimationPlayer") as AnimationPlayer
	if skel == null or ap == null:
		printerr("la escena necesita un Skeleton3D y un AnimationPlayer"); quit(1); return
	var root_bone := _arg(args, "--raiz", skel.get_bone_name(0))
	var extra := {}
	var ev_path := _arg(args, "--eventos")
	if not ev_path.is_empty():
		extra = JSON.parse_string(FileAccess.get_file_as_string(ev_path))
	var bones := []
	for b in skel.get_bone_count():
		var par := skel.get_bone_parent(b)
		var rest := skel.get_bone_rest(b)
		var rq := rest.basis.get_rotation_quaternion()
		bones.append({"name": skel.get_bone_name(b), "parent": skel.get_bone_name(par) if par >= 0 else "",
			"rest_pos": [rest.origin.x, rest.origin.y, rest.origin.z], "rest_rot": [rq.x, rq.y, rq.z, rq.w]})
	DirAccess.make_dir_recursive_absolute(out)
	var n := 0
	for lib_name in ap.get_animation_library_list():
		var lib := ap.get_animation_library(lib_name)
		for anim_name in lib.get_animation_list():
			var anim := lib.get_animation(anim_name)
			var clip := _export(anim, String(anim_name), skel, bones, root_bone, fps, flip, ap, scene_root)
			if extra.has(clip["name"]):
				var e = extra[clip["name"]]
				if typeof(e) == TYPE_ARRAY:
					clip["events"] = e
				else:
					clip["events"] = e.get("events", [])
					for k in e.get("meta", {}):
						clip["meta"][k] = e["meta"][k]
			var cat_dir: String = out.path_join(clip["category"])
			DirAccess.make_dir_recursive_absolute(cat_dir)
			var f := FileAccess.open(cat_dir.path_join(clip["name"] + ".json"), FileAccess.WRITE)
			f.store_string(JSON.stringify(clip, " "))
			f.close()
			n += 1
	print("%d clips exportados a %s" % [n, out])
	quit(0)


func _export(anim: Animation, name: String, skel: Skeleton3D, bones: Array, root_bone: String, fps: float, flip: bool, ap: AnimationPlayer, scene_root: Node) -> Dictionary:
	var clean := name.replace(" ", "_").replace("|", "_").replace(".", "_")
	var category := "OTHER"
	for c in CATS:
		if clean.to_upper().begins_with(c + "_"):
			category = c
			break
	var frames := maxi(1, int(round(anim.length * fps)))
	var tracks := {}
	var flip_q := Quaternion(Vector3.UP, PI)
	for t in anim.get_track_count():
		var tt := anim.track_get_type(t)
		if tt != Animation.TYPE_POSITION_3D and tt != Animation.TYPE_ROTATION_3D:
			continue
		var path := anim.track_get_path(t)
		var node := ap.get_node(ap.root_node).get_node_or_null(NodePath(path.get_concatenated_names()))
		if node != skel or path.get_subname_count() == 0:
			continue
		var bone := String(path.get_subname(0))
		if skel.find_bone(bone) < 0:
			continue
		var is_root := skel.get_bone_parent(skel.find_bone(bone)) < 0
		if not tracks.has(bone):
			tracks[bone] = {}
		var keys := []
		for f in frames + 1:
			var time := minf(anim.length, f / fps)
			if tt == Animation.TYPE_POSITION_3D:
				var p := anim.position_track_interpolate(t, time)
				if flip and is_root:
					p = flip_q * p
				keys.append([f, p.x, p.y, p.z])
			else:
				var q := anim.rotation_track_interpolate(t, time).normalized()
				if flip and is_root:
					q = (flip_q * q).normalized()
				keys.append([f, q.x, q.y, q.z, q.w])
		tracks[bone]["pos" if tt == Animation.TYPE_POSITION_3D else "rot"] = keys
	return {"format": "futbol5_clip_v1", "name": clean, "category": category, "fps": fps, "frames": frames,
		"skeleton": {"id": scene_root.name, "bones": bones}, "root_bone": root_bone, "tracks": tracks, "events": [],
		"meta": {"system": "otro", "loop": anim.loop_mode != Animation.LOOP_NONE},
		"author_note": "exportado con tools/exportar_clips_json.gd desde " + scene_root.name}
