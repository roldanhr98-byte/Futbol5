## Bucle del partido a tick fijo y en ORDEN FIJO (determinista; base para multijugador por entradas):
##   1. IA (escalonada a cfg.ai_think_hz) y entrada humana
##   2. jugadores (locomoción / ejecución de contactos) → registran contactos
##   3. balón: aplicar contactos (arbitraje) → 4. paso de física + portería → 5. reglas
## UCS usa un orden parecido (0x464d84: balón y portería, reglas, contactos [UCS-C]); aquí los contactos se aplican antes
## del paso para que el balón salga en el mismo tick del contacto [N].
class_name MatchSim
extends Node

signal goal(team_scored: int)

@export var config: FutbolConfig
var catalog := AnimCatalog.new()
var ball: Ball
var players: Array[Player] = []
var teams: Array[TeamAI] = []
var player_ais := {}
var keepers := {}
var human: HumanInput = null
var human_player: Player = null
var actions := {}
var planner: ContactPlanner
var tick_count := 0


func _ready() -> void:
	if config == null:
		config = load("res://data/config/futbol_config_default.tres")
	Engine.physics_ticks_per_second = config.tick_hz
	catalog.load_index()
	setup_systems()


func setup_systems() -> void:
	planner = ContactPlanner.new(config)
	actions = {
		"dribble": DribbleAction.new(config, planner),
		"kick": KickAction.new(config, planner),
		"receive": ReceiveAction.new(config, planner),
		"tackle": TackleAction.new(config, planner),
	}
	if ball == null:
		ball = Ball.new()
		add_child(ball)
	ball.setup(config)
	for g in ball.goals:
		g.goal_scored.connect(func(side): goal.emit(0 if side > 0 else 1))
	teams = [TeamAI.new(config, 0), TeamAI.new(config, 1)]


func add_player(p: Player) -> void:
	p.setup(config, catalog)
	players.append(p)
	teams[p.team].players.append(p)
	if p.is_goalkeeper:
		keepers[p.player_id] = GoalkeeperAI.new(config, p, planner)
	else:
		player_ais[p.player_id] = PlayerAI.new(config, p)


func _physics_process(_delta: float) -> void:
	step()


func step() -> void:
	tick_count += 1
	var think_every := maxi(1, int(round(config.tick_hz / config.ai_think_hz)))
	# 1. decisiones (cada jugador piensa en un tick distinto: carga repartida)
	var possession_team := ball.last_touch_team
	for t in teams:
		if tick_count % think_every == t.team:
			t.think(ball, possession_team == t.team, teams[1 - t.team].players)
	for p in players:
		if p == human_player:
			continue
		if (tick_count + p.player_id) % think_every != 0:
			continue
		if p.is_goalkeeper:
			keepers[p.player_id].think(ball)
		else:
			var role: Dictionary = teams[p.team].roles.get(p.player_id, {})
			player_ais[p.player_id].think(role, ball, teams[p.team].players, teams[1 - p.team].players, actions)
	if human != null and human_player != null:
		human.apply_to(human_player, 0.0)
	# 2. jugadores
	for p in players:
		p.tick(ball)
	# 3–4. balón
	ball.apply_pending()
	ball.physics_tick()
