## Depuración visual [N]: trayectoria prevista del balón, punto de contacto planificado y estado de cada jugador.
## Añadir como hijo de la escena del partido; activar con F3. Usa ImmediateMesh (barato también en móvil).
class_name DebugDraw
extends MeshInstance3D

var sim: MatchSim
var enabled := false
var _mesh := ImmediateMesh.new()


func _ready() -> void:
	mesh = _mesh
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	material_override = mat


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_F3:
		enabled = not enabled


func _process(_d: float) -> void:
	_mesh.clear_surfaces()
	if not enabled or sim == null or sim.ball == null:
		return
	_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	var prev := sim.ball.predictor.at(0).pos
	for i in range(1, 120, 2):
		var s := sim.ball.predictor.at(i).pos
		_mesh.surface_set_color(Color.YELLOW)
		_mesh.surface_add_vertex(prev)
		_mesh.surface_add_vertex(s)
		prev = s
	for p in sim.players:
		if p.executor.active():
			var b := p.executor.plan.ball_at_contact
			_mesh.surface_set_color(Color.RED)
			_mesh.surface_add_vertex(b + Vector3(-0.15, 0, 0))
			_mesh.surface_add_vertex(b + Vector3(0.15, 0, 0))
			_mesh.surface_add_vertex(b + Vector3(0, 0, -0.15))
			_mesh.surface_add_vertex(b + Vector3(0, 0, 0.15))
	_mesh.surface_end()
