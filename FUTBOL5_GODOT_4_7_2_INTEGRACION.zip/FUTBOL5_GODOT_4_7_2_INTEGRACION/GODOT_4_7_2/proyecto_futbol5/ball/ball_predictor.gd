## Predictor de trayectoria: estados futuros del balón con la MISMA física (UCS fn 0x44cdb4, anillo de 390 frames [UCS-C]).
## Se reconstruye perezosamente: solo calcula hasta el frame pedido y se invalida cuando el balón recibe un contacto.
class_name BallPredictor
extends RefCounted

var cfg: FutbolConfig
var _states: Array[BallState] = []
var _valid := false
var _base: BallState


func _init(config: FutbolConfig) -> void:
	cfg = config


func reset(from: BallState) -> void:
	_base = from.copy()
	_states.clear()
	_states.append(_base.copy())
	_valid = true


## Avanza un frame reutilizando lo ya calculado (el frame 1 previsto ES el nuevo estado real: misma física).
func advance(real_state: BallState) -> void:
	if not _valid or _states.size() < 2:
		reset(real_state)
		return
	_states.pop_front()
	_states[0] = real_state.copy()


func invalidate() -> void:
	_valid = false


func is_valid() -> bool:
	return _valid


## Estado previsto dentro de `frames` frames (0 = ahora). Limitado a cfg.predictor_frames.
func at(frames: int) -> BallState:
	var n := clampi(frames, 0, cfg.predictor_frames)
	var dt := cfg.dt()
	while _states.size() <= n:
		var s := _states[_states.size() - 1].copy()
		BallPhysics.step(s, cfg, dt)
		_states.append(s)
	return _states[n]


## Primer frame en que el balón queda por debajo de `height` y dentro de `radius` del punto `p` (o −1).
func first_frame_near(p: Vector3, radius: float, height: float, max_frames: int) -> int:
	for i in range(mini(max_frames, cfg.predictor_frames) + 1):
		var s := at(i)
		if s.pos.y <= height and Vector2(s.pos.x - p.x, s.pos.z - p.z).length() <= radius:
			return i
	return -1
