## Portería: colisión con postes, larguero y red, y detección de gol.
## Estructura de UCS (fns 0x44aa1c, 0x44a48c, 0x44baac, 0x44a89c, 0x44e2ac [UCS-C]): impacto con cilindros de poste y
## larguero, rebote de la componente normal, red que retiene el balón y gol cuando el balón SUPERA ENTERA la línea entre
## postes y por debajo del larguero. Dimensiones y coeficientes: [N] (futbol_config.gd).
class_name GoalFrame
extends RefCounted

signal goal_scored(side: int)

var cfg: FutbolConfig
var side: int            ## +1 portería en z = +L/2, −1 en z = −L/2
var line_z: float


func _init(config: FutbolConfig, goal_side: int) -> void:
	cfg = config
	side = goal_side
	line_z = side * cfg.pitch_length * 0.5


## Resuelve colisiones del balón con esta portería tras un paso de física. Devuelve true si el balón tocó poste/larguero.
func collide(s: BallState, prev_pos: Vector3) -> bool:
	var r := cfg.ball_radius
	var hit := false
	var posts := [Vector3(-cfg.goal_half_width - cfg.post_radius, 0.0, line_z), Vector3(cfg.goal_half_width + cfg.post_radius, 0.0, line_z)]
	for p in posts:
		# poste vertical: distancia en el plano XZ
		var d := Vector2(s.pos.x - p.x, s.pos.z - p.z)
		var min_d := r + cfg.post_radius
		if d.length() < min_d and s.pos.y < cfg.goal_height + cfg.post_radius:
			var n := Vector3(d.x, 0.0, d.y).normalized()
			if n == Vector3.ZERO:
				n = Vector3(0.0, 0.0, -side)
			s.pos += n * (min_d - d.length())
			s.vel = _reflect(s.vel, n, cfg.post_restitution)
			hit = true
	# larguero: cilindro horizontal en x ∈ [−hw, hw], y = goal_height, z = line_z
	if absf(s.pos.x) <= cfg.goal_half_width:
		var d2 := Vector2(s.pos.y - (cfg.goal_height + cfg.post_radius), s.pos.z - line_z)
		var min_d2 := r + cfg.post_radius
		if d2.length() < min_d2:
			var n2 := Vector3(0.0, d2.x, d2.y).normalized()
			s.pos += n2 * (min_d2 - d2.length())
			s.vel = _reflect(s.vel, n2, cfg.post_restitution)
			hit = true
	# red: caja detrás de la línea
	var behind := (s.pos.z - line_z) * side
	if behind > 0.0 and absf(s.pos.x) < cfg.goal_half_width and s.pos.y < cfg.goal_height:
		if behind > cfg.goal_depth - r:
			s.pos.z = line_z + side * (cfg.goal_depth - r)
			s.vel *= cfg.net_damping
		if absf(s.pos.x) > cfg.goal_half_width - r:
			s.pos.x = signf(s.pos.x) * (cfg.goal_half_width - r)
			s.vel.x *= -cfg.net_damping
		if s.pos.y > cfg.goal_height - r:
			s.pos.y = cfg.goal_height - r
			s.vel.y = -absf(s.vel.y) * cfg.net_damping
	return hit


## Gol: el centro del balón cruza line_z + radio (balón entero dentro) entre postes y por debajo del larguero.
func check_goal(prev_pos: Vector3, pos: Vector3) -> bool:
	var limit := line_z + side * (cfg.ball_radius + cfg.goal_line_margin)
	var was := (prev_pos.z - limit) * side
	var now := (pos.z - limit) * side
	if was < 0.0 and now >= 0.0:
		var t := was / (was - now)
		var cross := prev_pos.lerp(pos, t)
		if absf(cross.x) < cfg.goal_half_width and cross.y < cfg.goal_height:
			goal_scored.emit(side)
			return true
	return false


static func _reflect(v: Vector3, n: Vector3, restitution: float) -> Vector3:
	var vn := v.dot(n)
	if vn >= 0.0:
		return v
	return v - (1.0 + restitution) * vn * n
