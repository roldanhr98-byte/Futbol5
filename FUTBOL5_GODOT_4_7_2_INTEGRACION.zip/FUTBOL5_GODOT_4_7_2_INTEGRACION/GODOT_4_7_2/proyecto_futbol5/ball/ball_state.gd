## Estado físico del balón. Valor copiable: la simulación real y el predictor usan exactamente la misma estructura.
class_name BallState
extends RefCounted

var pos := Vector3.ZERO      ## centro del balón (m). Y arriba.
var vel := Vector3.ZERO      ## m/s
var spin := Vector3.ZERO     ## rad/s (vector de rotación)
var grounded := true         ## true si está rodando o en reposo sobre el suelo
var touches := 0             ## contador de contactos aplicados (UCS: balón+0xb0 [UCS-C])


func copy() -> BallState:
	var b := BallState.new()
	b.pos = pos
	b.vel = vel
	b.spin = spin
	b.grounded = grounded
	b.touches = touches
	return b
