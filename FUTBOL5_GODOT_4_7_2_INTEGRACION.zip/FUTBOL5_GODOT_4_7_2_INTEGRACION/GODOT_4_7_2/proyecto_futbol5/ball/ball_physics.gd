## Paso de física del balón: función pura y determinista.
## La usan el balón real (ball.gd), el predictor (ball_predictor.gd) y los solucionadores (trajectory_solver.gd).
## Así se cumple la regla de UCS de que el planificador predice con la misma física que luego se aplica [UCS-C].
## Estructura tomada de UCS fn 0x449ee8 [UCS-C estructura]; todos los coeficientes son [N] (ver futbol_config.gd).
class_name BallPhysics
extends RefCounted


static func step(s: BallState, cfg: FutbolConfig, dt: float) -> void:
	var r := cfg.ball_radius
	if s.grounded and s.pos.y <= r + 0.0001 and absf(s.vel.y) < 0.0001:
		_roll(s, cfg, dt)
		return
	# --- en el aire ---
	var v := s.vel
	var speed := v.length()
	var acc := Vector3(0.0, -cfg.gravity, 0.0)
	acc += -cfg.air_drag_k * speed * v             # arrastre cuadrático
	acc += cfg.magnus_k * s.spin.cross(v)          # efecto (Magnus)
	s.vel = v + acc * dt
	s.pos += s.vel * dt
	s.spin *= maxf(0.0, 1.0 - cfg.spin_decay_air * dt)
	s.grounded = false
	if s.pos.y <= r:
		_ground_contact(s, cfg)


## Bote: velocidad vertical con restitución; velocidad horizontal y efecto convergen hacia rodadura sin deslizamiento.
static func _ground_contact(s: BallState, cfg: FutbolConfig) -> void:
	var r := cfg.ball_radius
	s.pos.y = r
	var vy := -s.vel.y
	var h := Vector3(s.vel.x, 0.0, s.vel.z)
	# velocidad de superficie que impone el efecto: v_roll = ω × (r·up)
	var v_roll := s.spin.cross(Vector3(0.0, r, 0.0))
	var k := cfg.bounce_spin_transfer
	var h_new := h + (v_roll - h) * k * 0.5
	var spin_target := Vector3.UP.cross(h_new) / r
	s.spin = s.spin.lerp(spin_target, k)
	if vy * cfg.restitution > cfg.bounce_min_speed:
		s.vel = Vector3(h_new.x, vy * cfg.restitution, h_new.z)
		s.grounded = false
	else:
		s.vel = Vector3(h_new.x, 0.0, h_new.z)
		s.grounded = true


## Rodadura: deceleración constante y efecto igual al de rodadura sin deslizamiento.
static func _roll(s: BallState, cfg: FutbolConfig, dt: float) -> void:
	var h := Vector3(s.vel.x, 0.0, s.vel.z)
	var sp := h.length()
	if sp <= cfg.roll_stop_speed:
		s.vel = Vector3.ZERO
		s.spin = Vector3.ZERO
		s.pos.y = cfg.ball_radius
		return
	var new_sp := maxf(0.0, sp - cfg.roll_decel * dt)
	h = h * (new_sp / sp)
	# el efecto lateral sigue curvando un poco el balón al rodar (k reducido) [N]
	var side := cfg.magnus_k * 0.25 * Vector3(0.0, s.spin.y, 0.0).cross(h)
	h += side * dt
	s.vel = h
	s.pos += h * dt
	s.pos.y = cfg.ball_radius
	s.spin = Vector3.UP.cross(h) / cfg.ball_radius + Vector3(0.0, s.spin.y * maxf(0.0, 1.0 - 2.0 * dt), 0.0)
