## Balón del partido: dueño ÚNICO del estado físico del balón.
## Ningún sistema de animación mueve el balón: los jugadores REGISTRAN contactos (velocidad y efecto) y el balón los
## aplica en un punto fijo del ciclo (UCS: registro 0x46f968 → aplicación 0x46fb7c/0x448654 [UCS-C]).
class_name Ball
extends Node3D

signal touched(player_id: int, kind: StringName)
signal post_hit()

var cfg: FutbolConfig
var state := BallState.new()
var predictor: BallPredictor
var goals: Array[GoalFrame] = []
var rng := RandomNumberGenerator.new()
var last_touch_player := -1
var last_touch_team := -1
var held_by: Node3D = null        ## portero con el balón en las manos (posición tomada de la mano)

var _pending: Array[Dictionary] = []


func setup(config: FutbolConfig) -> void:
	cfg = config
	predictor = BallPredictor.new(cfg)
	rng.seed = cfg.random_seed
	goals = [GoalFrame.new(cfg, 1), GoalFrame.new(cfg, -1)]
	state.pos = Vector3(0.0, cfg.ball_radius, 0.0)
	predictor.reset(state)


## Registra un contacto para aplicarlo al final del tick. priority alta gana; con dos contactos en el mismo tick
## se mezcla 7/8–1/8 a favor de un ganador elegido al azar (UCS [UCS-C]). Devuelve el perdedor (o {}).
func register_contact(player_id: int, team: int, priority: int, vel: Vector3, spin: Vector3, kind: StringName) -> Dictionary:
	var c := {"player": player_id, "team": team, "priority": priority, "vel": vel, "spin": spin, "kind": kind}
	if _pending.is_empty():
		_pending.append(c)
		return {}
	var other: Dictionary = _pending[0]
	var winner := c if rng.randi_range(0, 1) == 0 else other
	var loser := other if winner == c else c
	var mixed := winner.duplicate()
	mixed["vel"] = (winner["vel"] as Vector3) * 0.875 + (loser["vel"] as Vector3) * 0.125
	mixed["spin"] = (winner["spin"] as Vector3) * 0.875 + (loser["spin"] as Vector3) * 0.125
	_pending[0] = mixed
	return loser


## Aplica los contactos pendientes (llamado por MatchSim tras actualizar a los jugadores).
func apply_pending() -> void:
	if _pending.is_empty():
		return
	var c: Dictionary = _pending[0]
	_pending.clear()
	state.vel = c["vel"]
	state.spin = c["spin"]
	state.grounded = state.vel.y <= 0.0001 and state.pos.y <= cfg.ball_radius + 0.0001
	if state.vel.y > 0.0:
		state.grounded = false
	state.touches += 1
	last_touch_player = c["player"]
	last_touch_team = c["team"]
	held_by = null
	predictor.reset(state)
	touched.emit(c["player"], c["kind"])


## Paso de física del tick (llamado por MatchSim).
func physics_tick() -> void:
	if held_by != null:
		state.pos = held_by.global_position + Vector3(0.0, 1.2, 0.3)
		state.vel = Vector3.ZERO
		predictor.reset(state)
		return
	var prev := state.pos
	BallPhysics.step(state, cfg, cfg.dt())
	var hit := false
	for g in goals:
		if g.collide(state, prev):
			hit = true
		g.check_goal(prev, state.pos)
	if hit:
		post_hit.emit()
		predictor.reset(state)
	else:
		predictor.advance(state)
	position = state.pos
