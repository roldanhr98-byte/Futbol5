## Solucionadores de golpeo: velocidad inicial para llevar el balón a un destino en un tiempo dado.
## UCS define el golpeo por destino y tiempo de vuelo (fns 0x4498a0, 0x449184, 0x44946c [UCS-C]); aquí se resuelve
## simulando con BallPhysics y corrigiendo iterativamente, para que la trayectoria real coincida con la planificada.
class_name TrajectorySolver
extends RefCounted


## Pase/tiro por el aire: llegar a `target` (centro del balón) en `frames` frames. Devuelve la velocidad inicial.
static func solve_air(from: Vector3, target: Vector3, frames: int, spin: Vector3, cfg: FutbolConfig, iterations: int = 8) -> Vector3:
	var dt := cfg.dt()
	var t := maxf(1.0, float(frames)) * dt
	var v := (target - from) / t + Vector3(0.0, 0.5 * cfg.gravity * t, 0.0)
	for _i in range(iterations):
		var end := _simulate_air(from, v, spin, frames, cfg)
		var err := target - end
		if err.length() < 0.01:
			break
		v += err / t
	return v


## Pase raso: velocidad horizontal para que el balón rodando llegue a `target` en `frames` frames.
## Devuelve Vector3.INF si no se puede (el balón se pararía antes aunque se lance a la velocidad máxima).
static func solve_ground(from: Vector3, target: Vector3, frames: int, max_speed: float, cfg: FutbolConfig) -> Vector3:
	var dir := Vector3(target.x - from.x, 0.0, target.z - from.z)
	var dist := dir.length()
	if dist < 0.001:
		return Vector3.ZERO
	dir /= dist
	var lo := 0.0
	var hi := max_speed
	if _roll_distance(hi, frames, cfg) < dist:
		return Vector3.INF
	for _i in range(24):
		var mid := 0.5 * (lo + hi)
		if _roll_distance(mid, frames, cfg) < dist:
			lo = mid
		else:
			hi = mid
	return dir * hi


static func _simulate_air(from: Vector3, v: Vector3, spin: Vector3, frames: int, cfg: FutbolConfig) -> Vector3:
	var s := BallState.new()
	s.pos = from
	s.vel = v
	s.spin = spin
	s.grounded = false
	var dt := cfg.dt()
	for _i in range(frames):
		BallPhysics.step(s, cfg, dt)
	return s.pos


static func _roll_distance(speed: float, frames: int, cfg: FutbolConfig) -> float:
	var s := BallState.new()
	s.pos = Vector3(0.0, cfg.ball_radius, 0.0)
	s.vel = Vector3(speed, 0.0, 0.0)
	s.grounded = true
	var dt := cfg.dt()
	for _i in range(frames):
		BallPhysics.step(s, cfg, dt)
	return s.pos.x
