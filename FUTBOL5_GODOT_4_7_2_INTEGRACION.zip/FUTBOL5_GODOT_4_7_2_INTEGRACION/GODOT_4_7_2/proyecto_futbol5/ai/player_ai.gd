## IA de jugador de campo [N]: decide por utilidad a cfg.ai_think_hz y ejecuta con LOS MISMOS sistemas que el humano
## (Locomotion, DribbleAction, KickAction, ReceiveAction, TackleAction). Retardo de reacción por atributo
## (ResponsePlayerMoveOOP 21→1 frames [UCS-C]).
class_name PlayerAI
extends RefCounted

var cfg: FutbolConfig
var p: Player
var react_delay := 0
var _pending_target := Vector3.INF


func _init(config: FutbolConfig, player: Player) -> void:
	cfg = config
	p = player


## role: diccionario de TeamAI. actions: {dribble, kick, receive, tackle}. Devuelve la decisión tomada (para depurar).
func think(role: Dictionary, ball: Ball, mates: Array, opponents: Array, actions: Dictionary) -> StringName:
	if p.executor.active():
		return &"busy"
	var target: Vector3 = role.get("target", p.global_position)
	if target.distance_to(_pending_target) > 0.5:
		_pending_target = target
		react_delay = int(round(FutbolConfig.lerp_attr(p.a("response"), cfg.react_frames_attr50, cfg.react_frames_attr99)))
	var has_ball := ball.last_touch_player == p.player_id and ball.state.pos.distance_to(p.global_position) < 1.6
	if has_ball:
		var goal := Vector3(0.0, 0.0, (1.0 if p.team == 0 else -1.0) * cfg.pitch_length * 0.5)
		var shot_u := _shot_utility(goal, opponents)
		var best_pass := _best_pass(ball, mates, opponents)
		if shot_u > 0.55:
			(actions["kick"] as KickAction).request(p, ball, KickAction.Kind.TIRO, goal + Vector3(randf_range(-1.0, 1.0), 0.6, 0.0), 1.0, 0.0, _pressure(opponents))
			return &"shoot"
		if best_pass["u"] > 0.6:
			(actions["kick"] as KickAction).request(p, ball, KickAction.Kind.PASE_CORTO, best_pass["to"], 1.0, 0.0, _pressure(opponents))
			return &"pass"
		var dir := atan2(goal.x - p.global_position.x, goal.z - p.global_position.z)
		p.desired_target = p.global_position + Vector3(sin(dir), 0.0, cos(dir)) * 3.0
		p.desired_speed = p.max_speed() * 0.75
		(actions["dribble"] as DribbleAction).request_touch(p, ball, dir)
		return &"dribble"
	if react_delay > 0:
		react_delay -= int(round(cfg.tick_hz / cfg.ai_think_hz))
		return &"reacting"
	p.desired_target = target
	p.desired_speed = p.max_speed() if role.get("role") == &"press" else p.cfg.run_speed
	if role.get("role") == &"press" and ball.state.pos.distance_to(p.global_position) < 2.5:
		if (actions["tackle"] as TackleAction).request(p, ball, false, true):
			return &"tackle"
	return role.get("role", &"idle")


func _pressure(opponents: Array) -> float:
	var d := INF
	for o in opponents:
		d = minf(d, p.global_position.distance_to((o as Player).global_position))
	return clampf(1.0 - (d - 1.0) / 4.0, 0.0, 1.0)     # [N] 1 m = presión máxima, 5 m = ninguna


func _shot_utility(goal: Vector3, opponents: Array) -> float:
	var d := p.global_position.distance_to(goal)
	var u := clampf(1.0 - (d - 4.0) / 14.0, 0.0, 1.0)  # [N]
	for o in opponents:
		if _blocks(p.global_position, goal, (o as Player).global_position, 0.6):
			u *= 0.6
	return u


func _best_pass(ball: Ball, mates: Array, opponents: Array) -> Dictionary:
	var best := {"u": 0.0, "to": Vector3.ZERO}
	for m in mates:
		var mate: Player = m
		if mate == p:
			continue
		var to := mate.global_position + mate.velocity * 0.6
		var d := p.global_position.distance_to(to)
		if d < 3.0 or d > 25.0:
			continue
		var u := 1.0 - d / 30.0
		for o in opponents:
			if _blocks(ball.state.pos, to, (o as Player).global_position, 1.0):
				u *= 0.3
		if u > best["u"]:
			best = {"u": u, "to": Vector3(to.x, cfg.ball_radius, to.z)}
	return best


static func _blocks(a: Vector3, b: Vector3, c: Vector3, radius: float) -> bool:
	var ab := Vector2(b.x - a.x, b.z - a.z)
	var ac := Vector2(c.x - a.x, c.z - a.z)
	var t := clampf(ac.dot(ab) / maxf(1e-6, ab.length_squared()), 0.0, 1.0)
	return (ac - ab * t).length() < radius
