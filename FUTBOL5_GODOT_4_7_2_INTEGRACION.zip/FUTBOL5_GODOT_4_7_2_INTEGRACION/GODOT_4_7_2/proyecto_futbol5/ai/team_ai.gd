## IA de equipo [N] con reglas de UCS donde existen: máximo 1 entrada y 2 presiones simultáneas [UCS-C], marcaje a
## distancia por fuerza (MarkingDist 1,5 yd [UCS-C/I]), líneas con y sin balón (BackLinePOS/OOP, MidLinePercent [UCS-C]
## como proporción del campo). Se ejecuta a cfg.ai_think_hz; reparte roles y objetivos, no mueve a nadie directamente.
class_name TeamAI
extends RefCounted

var cfg: FutbolConfig
var team := 0
var players: Array[Player] = []
var attack_dir := 1.0          ## +1 ataca hacia +Z
var roles := {}                ## player_id -> {role, target, mark}
var active_presses := 0
var active_tackles := 0


func _init(config: FutbolConfig, team_id: int) -> void:
	cfg = config
	team = team_id
	attack_dir = 1.0 if team == 0 else -1.0


## Decide roles. has_ball: si este equipo tiene la posesión. opponents: jugadores rivales.
func think(ball: Ball, has_ball: bool, opponents: Array) -> void:
	roles.clear()
	active_presses = 0
	var field := players.filter(func(p): return not p.is_goalkeeper)
	# distancia de cada uno al balón previsto en 12 frames
	var bpos := ball.predictor.at(12).pos
	field.sort_custom(func(a, b): return a.global_position.distance_to(bpos) < b.global_position.distance_to(bpos))
	var half := cfg.pitch_length * 0.5
	var line_z := attack_dir * (0.15 if has_ball else -0.35) * half   # [N] altura del bloque
	for i in range(field.size()):
		var p: Player = field[i]
		var role := &"support"
		var target := Vector3.ZERO
		if has_ball:
			if i == 0:
				role = &"carrier_or_receiver"
				target = bpos
			else:
				# desmarque: ocupar carriles y profundidad [N]
				var lane := (float(i % 3) - 1.0) * cfg.pitch_width * 0.3
				target = Vector3(lane, 0.0, line_z + attack_dir * (2.0 + 3.0 * float(i % 2)))
		else:
			if i < cfg.max_active_presses:
				role = &"press"
				target = bpos
				active_presses += 1
			else:
				role = &"mark"
				var mark := _nearest_free_opponent(p, opponents)
				if mark != null:
					var goal := Vector3(0.0, 0.0, -attack_dir * half)
					var dir := (goal - mark.global_position).normalized()
					target = mark.global_position + dir * FutbolConfig.lerp_attr(p.a("strength"), cfg.marking_dist, cfg.marking_dist)
					roles[p.player_id] = {"role": role, "target": target, "mark": mark.player_id}
					continue
				target = Vector3(0.0, 0.0, line_z)
		roles[p.player_id] = {"role": role, "target": target}


func _nearest_free_opponent(p: Player, opponents: Array) -> Player:
	var taken := {}
	for r in roles.values():
		if r.has("mark"):
			taken[r["mark"]] = true
	var best: Player = null
	var bd := INF
	for o in opponents:
		var op: Player = o
		if op.is_goalkeeper or taken.has(op.player_id):
			continue
		var d := p.global_position.distance_to(op.global_position)
		if d < bd:
			bd = d
			best = op
	return best


func can_tackle() -> bool:
	return active_tackles < cfg.max_active_tackles
