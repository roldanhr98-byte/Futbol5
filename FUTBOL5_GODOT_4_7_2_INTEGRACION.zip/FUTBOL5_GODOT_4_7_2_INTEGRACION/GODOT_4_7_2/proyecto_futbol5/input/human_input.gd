## Entrada humana [N]. UCS no usa joystick: fija un DESTINO de carrera con toques/arrastres y deja que la locomoción
## decida marcha y giros (UCS 0x54c86c, radios de toque escalados por la cámara [UCS-C]). Aquí el joystick virtual se
## convierte en un destino móvil (posición + dirección · distancia de mira) para reutilizar la misma lógica.
class_name HumanInput
extends RefCounted

var look_ahead := 2.5        ## [N] m de destino delante del jugador
var deadzone := 0.15         ## [N]
var sprint_threshold := 0.9  ## [N] inclinación a partir de la cual se pide sprint
var stick := Vector2.ZERO    ## −1..1 (x derecha, y arriba de pantalla); lo rellena la UI o Input.get_vector
var pass_pressed := false
var shoot_held_time := 0.0   ## s que se mantiene el botón de tiro → potencia
var shoot_released := false


func read_from_input_map() -> void:
	stick = Input.get_vector("move_left", "move_right", "move_down", "move_up")
	pass_pressed = Input.is_action_just_pressed("pass")
	shoot_released = Input.is_action_just_released("shoot")


## Convierte el stick en destino y velocidad pedida para el jugador controlado. camera_yaw: giro de la cámara.
func apply_to(p: Player, camera_yaw: float) -> void:
	var m := stick.length()
	if m < deadzone:
		p.desired_target = p.global_position
		p.desired_speed = 0.0
		return
	var world := Vector3(-stick.x, 0.0, stick.y).rotated(Vector3.UP, camera_yaw).normalized()
	p.desired_target = p.global_position + world * look_ahead
	var f := clampf((m - deadzone) / (1.0 - deadzone), 0.0, 1.0)
	p.desired_speed = p.max_speed() if f >= sprint_threshold else lerpf(p.cfg.walk_speed, p.cfg.run_speed, f / sprint_threshold)


func shot_power01() -> float:
	return clampf(shoot_held_time / 0.8, 0.2, 1.0)    ## [N] 0,8 s = potencia máxima
