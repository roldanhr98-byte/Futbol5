## Portero [N] con reglas de UCS: reacción ResponseGKSave 15→4 frames, alcance Min/MaxSaveDist por atributo de portero,
## planificación de la parada con el PREDICTOR del balón y los eventos de clips GKSAVE (UCS SEL‑5 0x4330d8 [UCS-C]).
class_name GoalkeeperAI
extends RefCounted

var cfg: FutbolConfig
var p: Player
var planner: ContactPlanner
var goal_z := 0.0
var _threat_frames := 0
var _connected := false


func _init(config: FutbolConfig, keeper: Player, contact_planner: ContactPlanner) -> void:
	cfg = config
	p = keeper
	planner = contact_planner
	goal_z = (-1.0 if p.team == 0 else 1.0) * cfg.pitch_length * 0.5


func reaction_frames() -> int:
	return int(round(FutbolConfig.lerp_attr(p.a("gk"), cfg.gk_react_frames_attr50, cfg.gk_react_frames_attr99)))


func reach_max() -> float:
	return FutbolConfig.lerp_attr(p.a("gk"), cfg.gk_reach_max_50, cfg.gk_reach_max_99)


## Posición: en la bisectriz entre el balón y el centro de la portería, a gk_line_offset de la línea [N].
func position_target(ball: Ball) -> Vector3:
	var goal := Vector3(0.0, 0.0, goal_z)
	var b := ball.state.pos
	var dir := Vector3(b.x - goal.x, 0.0, b.z - goal.z).normalized()
	return goal + dir * cfg.gk_line_offset


## Frame en que el balón previsto cruza la línea de su portería entre postes (o −1).
func shot_crossing_frame(ball: Ball) -> int:
	var prev := ball.predictor.at(0).pos
	for i in range(1, cfg.predictor_frames):
		var s := ball.predictor.at(i).pos
		if (prev.z - goal_z) * (s.z - goal_z) <= 0.0:
			return i if absf(s.x) < cfg.goal_half_width + 0.5 and s.y < cfg.goal_height + 0.3 else -1
		prev = s
	return -1


func think(ball: Ball) -> StringName:
	if p.executor.active():
		return &"busy"
	var f := shot_crossing_frame(ball)
	if f > 0:
		_threat_frames += int(round(cfg.tick_hz / cfg.ai_think_hz))
		if _threat_frames >= reaction_frames():
			var plan := planner.plan(p, p.catalog.group(&"GKSAVE"), ball.predictor, {"speed": 0.0, "max_start": mini(f, 30), "max_turn_deg": 90.0, "kind": &"save"})
			if plan.valid() and Vector2(plan.root_target.x - p.global_position.x, plan.root_target.z - p.global_position.z).length() <= reach_max():
				p.start_action(plan)
				if not _connected:
					_connected = true
					p.executor.contact_ok.connect(_on_save.bind(ball))
				return &"save"
		return &"set"
	_threat_frames = 0
	p.desired_target = position_target(ball)
	p.desired_speed = p.cfg.run_speed
	return &"position"


## Parada: desvía el balón hacia fuera (o lo atrapa si llega lento) [N].
func _on_save(plan: ContactPlan, ball: Ball) -> void:
	if plan.kind != &"save":
		return
	var v := ball.state.vel
	if v.length() < 12.0 and plan.meta.tags.has("CATCH"):
		ball.register_contact(p.player_id, p.team, 10, Vector3.ZERO, Vector3.ZERO, &"catch")
		ball.held_by = p
		return
	var out := Vector3(signf(ball.state.pos.x) if ball.state.pos.x != 0.0 else 1.0, 0.4, -signf(goal_z) * 0.3).normalized() * v.length() * 0.35
	ball.register_contact(p.player_id, p.team, 10, out, Vector3.ZERO, &"save")
