# REGLAS DE GOLPEO Y BALÓN (implementadas)

## Golpeo (`actions/kick_action.gd`)
| Tipo | Cómo se resuelve | Origen |
|---|---|---|
| PASE_CORTO | raso, `solve_ground`; tiempo de vuelo por distancia² entre 50 frames (5 yd) y 195 (60 yd) × `pass_time_scale` | [UCS-C] tiempos; escala [N] |
| PASE_LARGO / PASE_ELEVADO | `solve_air`; elevado si el destino está > ½ yd de altura | [UCS-C/I] |
| CENTRO | `solve_air` con altura de vértice `cross_apex_height` y efecto | [N] |
| TIRO | potencia por distancia (−62,2 m sin potencia … 29,3 m potencia máxima) × `shot_speed_scale`; velocidad máx 30,8→36,2 m/s según potencia | [UCS-C/I] + escala [N] |
| TIRO_DE_PRIMERA | el plan se hace sobre el balón en movimiento (predictor) y en el contacto se vuelve a resolver desde la posición real del balón | [UCS-C estructura] |
| Pie malo | potencia ×0,95 y coste extra en el planificador | [UCS-C] 3891/4096 |
| De espaldas | potencia ×0,875→0,9375; error 11,7°→5,9° (de frente 4,1°→1,7°) | [UCS-C] |
| Error bajo presión | `apply_error` escala el error con `pressure01` | [N] |

## Balón (`ball/*.gd`)
Aire: gravedad + arrastre −k|v|v + Magnus k(ω×v), decaimiento de efecto. Bote: restitución vertical, convergencia de velocidad/efecto hacia rodadura (fracción `bounce_spin_transfer`, UCS 25–50 % [UCS-C estructura]). Rodadura: deceleración constante, ligera curva por efecto vertical. Postes y larguero cilíndricos, red que amortigua, gol solo con el balón **entero** pasada la línea, entre postes y bajo el larguero [UCS-C 0x44e2ac]. Todos los coeficientes [N]: ver CALIBRACION_FISICA.md.

## Disputa
Dos contactos en el mismo tick: ganador al azar y mezcla 7/8–1/8 [UCS-C]. Entradas: alcance pasivo 0,69→1,14 m, presionando 1,37→2,29 m, en plancha 2,29 m; máximo 1 entrada y 2 presiones activas por equipo [UCS-C]; duelo de fuerza decide la caída [UCS-C estructura].
