# MANUAL MAESTRO — para Claude u otro desarrollador que continúe el juego

Lee este documento antes de modificar el código. Describe la arquitectura, las herramientas, el flujo de incorporación de animaciones y el estado del desarrollo.

## 0. Qué contiene este paquete

Proyecto base de **Godot 4.7.2 para un juego de Fútbol 5**. Incluye sistemas de física, movimiento, contactos, conducción, recepción, golpeo, inteligencia artificial, portero, herramientas de animación, ejemplos, documentación y pruebas.

La carpeta `ANIMACIONES_PROPIAS/EJEMPLOS_SINTETICOS/` contiene 38 clips sintéticos `EJ_*` destinados a comprobar el funcionamiento del pipeline. Se pueden incorporar más animaciones y recursos al proyecto mediante los formatos y herramientas descritos en §3.

Las etiquetas técnicas que aparecen en el código y la documentación identifican el tipo de dato:
- `[UCS-C]`: dato o regla identificados en la investigación técnica de referencia.
- `[UCS-C/I]`: dato convertido a metros mediante la escala indicada en la documentación.
- `[UCS-C estructura]`: estructura de una regla identificada; el valor numérico utilizado es propio.
- `[N]`: valor propuesto para Fútbol 5, ajustable durante la calibración.
- `[L]`: dato que no se pudo determinar.
- `[P]`: elemento pendiente de completar o verificar.

## 1. Arranque rápido: verificar que todo funciona

```bash
cd GODOT_4_7_2/proyecto_futbol5
godot --headless --path . --import
godot --headless --path . --script res://tests/check_scripts.gd
python3 ../../HERRAMIENTAS/convertir_a_godot.py ../../ANIMACIONES_PROPIAS/EJEMPLOS_SINTETICOS . --espejos --limpiar
godot --headless --path . --script res://tests/run_tests.gd
```

Resultados esperados:
- Scripts: 25, con error: 0.
- Pruebas: 22 OK, 0 fallas.

`godot` corresponde al ejecutable de Godot 4.7.2. En Windows puede utilizarse `Godot_v4.7.2-stable_win64_console.exe`. Se requiere Python 3.9 o superior, sin dependencias adicionales.

## 2. Arquitectura en una pantalla

Consultar `ARQUITECTURA_GODOT.md`.

1. `Ball` es el responsable del estado y movimiento del balón; los jugadores registran contactos.
2. `BallPhysics.step` centraliza la física. El predictor y los solucionadores utilizan ese mismo sistema.
3. Los contactos se planifican y ejecutan mediante `ContactPlanner` y `ContactExecutor`, manteniendo la interacción física entre jugador y balón.
4. Orden del tick en `MatchSim`: decisiones → jugadores → `apply_pending` → `physics_tick`.
5. Los parámetros se administran desde `FutbolConfig`.
6. Los nombres de los clips se conservan desde el JSON hasta el catálogo.

## 3. Cómo incorporar animaciones

### 3.1 Formatos de entrada

El flujo contempla animaciones de personajes con esqueleto en estos formatos:
- `.glb` y `.gltf` (recomendados).
- Escenas `.tscn` de Godot con `Skeleton3D` y `AnimationPlayer`.
- `.fbx`, mediante importación en Godot o conversión desde Blender.

Desde Blender se puede exportar mediante **Archivo → Exportar → glTF 2.0**, activando la opción de animación y exportando cada acción como clip.

### 3.2 Categorías y nombres de clips

Prefijos reconocidos por el flujo:

`LOCO_`, `STAND_`, `TURN_`, `SIDESTEP_`, `CONTROL_`, `KICK_`, `KICKSETPIECE_`, `TACKLE_`, `TACKLESLIDE_`, `FALL_`, `GETUP_`, `STUMBLE_`, `GKSAVE_`, `GKTHROW_`, `GKKICK_`, `THROW_`.

Ejemplos:
- `CONTROL_TOQUE_R_RAPIDO`
- `KICK_TIRO_R`
- `TURN_IZQ_90`

El sistema puede generar variantes espejo cuando corresponda (por ejemplo, cambiar el lado del pie).

### 3.3 Exportar a JSON futbol5_clip_v1

```bash
godot --headless --path GODOT_4_7_2/proyecto_futbol5 --script res://tools/exportar_clips_json.gd -- \
      --entrada /ruta/mi_jugador.glb --salida ANIMACIONES_PROPIAS/MIS_CLIPS --raiz Hips --eventos eventos.json [--girar180]
```

Parámetros:
- `--entrada`: modelo o archivo de animación.
- `--salida`: carpeta de destino de los JSON.
- `--raiz`: hueso de cadera o raíz que lleva el desplazamiento.
- `--eventos`: archivo con eventos y metadatos.
- `--girar180`: utilizar cuando el modelo mira hacia −Z.

### 3.4 Marcar contactos y metadatos (`eventos.json`)

```json
{
  "CONTROL_TOQUE_R_RAPIDO": {
    "events": [{"type": "contact", "frame": 11, "part": "RightFoot"}],
    "meta": {"foot": "R", "speed_class": 5.5, "system": "conduccion", "tags": ["DRIBBLE"]}
  },
  "KICK_TIRO_R": {
    "events": [{"type": "contact", "frame": 22, "part": "RightFoot"}],
    "meta": {"foot": "R", "speed_class": 2.5, "system": "tiro"}
  },
  "LOCO_TROTE": {
    "meta": {"speed_class": 3.5, "loop": true, "system": "locomocion"}
  },
  "TURN_IZQ_90": {
    "meta": {"dir_deg": 90, "speed_class": 2.0, "system": "giro"}
  },
  "GKSAVE_ESTIRADA_IZQ_BAJA": {
    "events": [{"type": "contact", "frame": 14, "part": "LeftHand"}],
    "meta": {"system": "portero", "tags": ["CATCH"]}
  }
}
```

Campos:
- `frame`: fotograma en el que el pie o la mano realiza el contacto. La velocidad predeterminada es 60 FPS.
- `part`: hueso o parte del cuerpo que realiza el contacto.
- `ball_local`: posición opcional del balón en metros, relativa a la raíz al inicio del clip. Si no se especifica, se calcula a partir de la posición del hueso `part` en ese fotograma, ajustada a la altura del radio del balón.
- Para un contacto lateral, se puede proporcionar `ball_local` explícitamente como `[x, y, z]`.
- Coordenadas: `+Z` hacia delante y `+X` hacia la izquierda.
- `speed_class`: velocidad del jugador en m/s para la que está pensado el clip. Si falta, se calcula a partir de la raíz.
- `dir_deg`: dirección de salida del balón en los golpeos o ángulo de giro del cuerpo en clips `TURN`. El signo positivo representa la izquierda.

### 3.5 Validar, catalogar, convertir y probar

```bash
python3 HERRAMIENTAS/validar_animaciones.py ANIMACIONES_PROPIAS/MIS_CLIPS --informe PRUEBAS/validacion_mis_clips.json

python3 HERRAMIENTAS/catalogar.py ANIMACIONES_PROPIAS/MIS_CLIPS CATALOGO/MIS_CLIPS

python3 HERRAMIENTAS/convertir_a_godot.py ANIMACIONES_PROPIAS/MIS_CLIPS GODOT_4_7_2/proyecto_futbol5 --espejos --limpiar --skeleton-path Skeleton3D

godot --headless --path GODOT_4_7_2/proyecto_futbol5 --script res://tests/run_tests.gd

python3 HERRAMIENTAS/verificar_integridad.py generar ANIMACIONES_PROPIAS ANIMACIONES_PROPIAS/INVENTARIO_SHA256.txt
```

`--skeleton-path` indica la ruta del `Skeleton3D` relativa al nodo raíz del `AnimationPlayer`; por ejemplo, `Armature/Skeleton3D`.

Se pueden procesar varias carpetas colocando los clips bajo una carpeta padre común. La opción `--limpiar` permite regenerar los recursos convertidos.

### 3.6 Montar el personaje

La escena del jugador se organiza así:
- Nodo principal: `Player`, con el script `player/player.gd`.
- Hijo: modelo del personaje.
- El `AnimationPlayer` se llama `AnimationPlayer` y es hijo directo de `Player`, o se asigna manualmente mediante `animator.anim_player`.

El desplazamiento de raíz lo aplica `Player`. El `AnimationPlayer` debe configurarse de acuerdo con ese flujo de root motion.

## 4. Estado probado

- 25 scripts compilan en Godot 4.7.2.
- 22 pruebas aprobadas.
- Caída, bote y rodadura del balón.
- Determinismo de la simulación y efecto Magnus.
- Tres solucionadores aéreos, uno raso y uno para situaciones imposibles.
- Predictor y física real con resultados coincidentes.
- Gol, red, poste y larguero.
- Catálogo con 67 clips.
- Animaciones cargables.
- Conducción planificada durante 6 segundos: 11 toques, 0 fallos y separación máxima de 1,3 m.
- Exportador `.glb → JSON` probado con un personaje con piel generado por Godot (`tests/test_exportador_glb.gd`); cinemática directa y espejos verificados.

## 5. Tareas pendientes y criterios de aceptación

| # | Tarea | Criterio de aceptación |
|---|---|---|
| 1 | Incorporar y validar el conjunto de animaciones | Validador con 0 errores y 22 pruebas aprobadas |
| 2 | Escena jugable 1 contra 1 con el modelo | Conducir durante 30 segundos sin perder el balón; contacto visual de los pies con error inferior a 5 cm |
| 3 | Pase y control entre 2 jugadores | Al menos el 90 % de los pases de 10 m terminan controlados |
| 4 | Tiro y portero | Gol, poste, parada y blocaje visualmente correctos; trayectoria visible con F3 |
| 5 | IA 4+1 contra 4+1 | Partido de 5 minutos sin bloqueos; máximo 1 entrada y 2 presiones por equipo |
| 6 | Controles táctiles Android | Joystick y 2 botones; objetivo de 60 FPS en Mali-G57, según `OPTIMIZACION.md` |
| 7 | Calibración | Métricas de `CALIBRACION_FISICA.md`, sección 2, dentro de los rangos establecidos |
| 8 | Pendientes de diseño | Saque de portero, saques de banda, saques de esquina, faltas y reanudaciones |

## 6. Estructura del paquete

- `GODOT_4_7_2/proyecto_futbol5/`: proyecto principal de Godot, scripts, escenas y pruebas.
- `HERRAMIENTAS/`: validadores, catalogadores, conversores y utilidades.
- `ANIMACIONES_PROPIAS/`: ejemplos y clips incorporados.
- `CATALOGO/`: catálogos CSV y JSON.
- `METADATOS/ESQUEMAS/`: esquemas de datos, incluido `futbol5_clip_v1.schema.json`.
- `REGLAS/`: reglas y parámetros de funcionamiento.
- `PRUEBAS/`: resultados e informes.
- `OPTIMIZACION/`: documentación de rendimiento.
- `DOCUMENTACION/`: manuales y documentos técnicos.
- `INVENTARIO_SHA256.txt`: inventario para verificar la integridad de los archivos.

Documentos principales para continuar:
- `ARQUITECTURA_GODOT.md`
- `PLAN_DE_IMPLEMENTACION.md`
- `CALIBRACION_FISICA.md`
- `MANUAL_MAESTRO_OTRO_CLAUDE.md`

## Objetivo final

Conseguir un Fútbol 5 jugable y coherente: desplazamiento natural, conducción, controles, pases, centros y tiros; animaciones sincronizadas con los contactos físicos reales con el balón; inteligencia artificial y portero integrados con la simulación.
