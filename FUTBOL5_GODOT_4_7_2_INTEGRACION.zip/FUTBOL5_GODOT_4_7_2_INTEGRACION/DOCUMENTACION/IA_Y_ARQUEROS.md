# IA Y ARQUEROS (implementadas)

## Equipo (`ai/team_ai.gd`)
Roles por tick de IA (10 Hz [N], escalonado por jugador): **presión** (hasta `max_active_presses`=2 [UCS-C]), **marca** a `marking_dist` 1,37 m [UCS-C/I], **apoyo** en líneas de pase. Una sola entrada activa por equipo [UCS-C].

## Jugador (`ai/player_ai.gd`)
Utilidad tiro / pase / conducción con el predictor y la posición de rivales; retraso de reacción 21→1 frames según `response` [UCS-C ResponsePlayerMoveOOP]. Límite de posesión 20 s [UCS-C].

## Portero (`goalkeeper/gk_ai.gd`)
- Colocación en la bisectriz del ángulo balón‑postes a `gk_line_offset` de la línea [N].
- Reacción 15→4 frames según atributo `gk` [UCS-C ResponseGKSave].
- Alcance mínimo 1,25→1,65 m y máximo 2,29→2,74 m [UCS-C/I TechniqueGKMin/MaxSaveDist].
- `shot_crossing_frame` con el predictor; plan GKSAVE con el planificador genérico (mismo mecanismo que UCS SEL-5 0x4330d8); al validar: blocaje (`held_by`) o desvío.
- Salidas a balón suelto dentro de `gk_sweep_dist` [N].
Pendiente: saque del portero (SEL-7 de UCS) solo esbozado; distribución con la mano = pase con `PASE_ELEVADO`.
