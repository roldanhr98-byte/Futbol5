# OPTIMIZACIÓN ANDROID (objetivo Mali-G57, 60 fps)

| Área | Medida | Dónde |
|---|---|---|
| Renderer | Mobile (configurado) + compresión ETC2/ASTC (configurada). Recomendado: 1 luz direccional con sombras 2048 px y 2 cascadas | project.godot |
| Simulación | 60 Hz fijos, `physics_interpolation` activo para render suave | project.godot |
| Física | balón con física propia (sin RigidBody ni Jolt); 1 paso analítico por tick | ball_physics.gd |
| Predictor | perezoso, se reutiliza avanzando 1 frame; solo se recalcula tras un contacto | ball_predictor.gd |
| Planificador | solo al pedir acción (no cada tick); `plan_search_frames` 12 × clips del grupo | contact_planner.gd |
| IA | 10 Hz escalonada (cada jugador piensa en un tick distinto) | match_sim.gd |
| Animación | metadatos al arrancar; `Animation` bajo demanda con LRU de 64 | anim_catalog.gd |
| Animación | `AnimationPlayer` con `speed_scale = 0` y `seek()`; desactivar `AnimationTree` si no se usa | player_animator.gd |
| Pistas | exportar a 30 fps las de locomoción si memoria aprieta (el convertidor respeta el fps del JSON) | convertir_a_godot.py |
| Modelos | ≤ 5 000 triángulos por jugador, 1 material, ≤ 40 huesos con influencia, texturas ASTC/ETC2 | importación |
| Memoria | 10 jugadores × ~200 clips ≈ 15–30 MB de pistas con 30 huesos a 60 fps (medir con el monitor) | — |
| Perfilado | Godot Debugger → Monitors (Process, Physics), `--print-fps` en el dispositivo | — |
Presupuesto orientativo por tick (Mali-G57 / Cortex-A55): física+predictor < 0,2 ms, IA < 0,6 ms (escalonada), planificador < 1 ms el tick en que se usa, animación < 1,5 ms para 10 jugadores. Medidlo: son [N].
