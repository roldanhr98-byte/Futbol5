# REGLAS DE MOVIMIENTO Y CONDUCCIÓN (implementadas)

| Regla | Implementación | Origen |
|---|---|---|
| Destino móvil a ¼ yd: dentro de `arrive_radius` se considera llegado | locomotion.gd `tick` | [UCS-C/I] 0x2000 |
| Frenada a tiempo v² = 2·a·d | locomotion.gd | [N] |
| Giro < 30° sin clip; ≥ 50° clip TURN; pérdida lineal de velocidad hasta ½ a 180° | locomotion.gd | [UCS-C] 0x555 / 0x8e4 / 0x480b54; curva exacta [L] |
| Selección LOCO/STAND/TURN por clase de velocidad más cercana | `Locomotion.pick_clip` | [UCS-C estructura] selector 0x47c29c por id f0a |
| Sincronía de zancada: rate = v_real / v_raíz_clip (0,6–1,6) | `_update_clip` | [N] |
| Conducción = toques planificados, nunca balón pegado | dribble_action.gd | [UCS-C] SEL-2 0x47f274 |
| Escala de velocidad al conducir 0,80 → 0,934 según técnica | dribble_action.gd | [UCS-C] TechniqueDribbleSpeedScale |
| Distancia del toque por delante 0,69 / 0,80 / 1,03 m según fracción de velocidad (rodilla 0,3125) | `FutbolConfig.touch_ahead` | [UCS-C/I] |
| Toques especiales hasta 50 % con técnica 99 | dribble_action.gd | [UCS-C] TechniqueSpecialControlPercent1 |
| Paso máximo de corrección por categoría y frame | contact_executor.gd | [UCS-C/I] tabla 0x13a480 |
| Tolerancia de validación 1/16 yd (control), 1/8 yd (golpeo); altura −3·tol…+tol | contact_executor.gd | [UCS-C/I] |
| Si falla la validación: `contact_failed` y la acción se replanifica | contact_executor.gd | [UCS-C] 0x473370 |
| Recepción con dirección y velocidad de salida (primer toque orientado) | receive_action.gd | [UCS-C estructura] |
| Intervalo entre toques 0,70 → 0,35 s | dribble_action.gd | [N] |
