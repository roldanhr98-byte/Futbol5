# ESQUELETO Y RETARGETING

- La jerarquía de huesos de UCS **no se recuperó** [P]; el sistema NO depende de ella.
- El sistema funciona con **vuestro** esqueleto: el formato futbol5_clip_v1 lleva su propia lista de huesos con padre y pose de reposo, y el convertidor escribe pistas `Skeleton3D:<hueso>`.
- Requisitos mínimos del esqueleto: un hueso raíz (o la cadera) para el root motion (`root_bone`); huesos de pie izquierdo/derecho y cabeza para los eventos (`part`); nombres con sufijo de lado reconocible para el espejo (`_l/_r`, `_L/_R`, `.L/.R`, `Left/Right`).
- Convención: +Z frente, +X izquierda, Y arriba, metros. Si vuestro modelo mira a −Z, exportad con `--girar180`.
- Retargeting entre modelos: usad el `SkeletonProfileHumanoid` de Godot al importar el .glb (Import → Skeleton → Retarget → Bone Map) **antes** de exportar con `tools/exportar_clips_json.gd`; así todos los clips quedan con los nombres del perfil (`Hips`, `LeftFoot`, `RightFoot`, `Head`…). Entonces usad `--raiz Hips` y `part: "RightFoot"`.
- Espejo: el convertidor invierte X de posiciones, (x, −y, −z, w) de rotaciones, intercambia nombres de lado, pie, signo de `dir_deg` y X de `ball_local`. Comprobad visualmente un clip espejo por categoría: si vuestro esqueleto tiene ejes locales distintos por lado (algunos rigs de Blender), desactivad el espejo (`meta.no_mirror`) y exportad ambos lados.
