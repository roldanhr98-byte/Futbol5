# CALIBRACIÓN FÍSICA Y DE JUGABILIDAD

Todos los parámetros viven en `GODOT_4_7_2/proyecto_futbol5/core/futbol_config.gd` (recurso `FutbolConfig`, editable en el inspector o en `data/config/futbol_config_default.tres`).

Etiquetas: **[UCS-C]** valor o regla confirmados en UCS (constante leída en el binario o en `mpx_config`), **[UCS-C/I]** confirmado en UCS y convertido a metros con la escala inferida (1 yd = 32768 u), **[UCS-C estructura]** la forma de la regla es de UCS pero el número es propio, **[N]** valor NUEVO propuesto para Fútbol 5 (no viene de UCS, hay que calibrarlo). Las curvas de velocidad y los coeficientes físicos de UCS **no están recuperados [L]**: todos los coeficientes físicos son [N].

## 1. Tabla de parámetros

| Grupo | Parámetro | Valor inicial | Clase | Rango de prueba | Nota |
|---|---|---|---|---|---|
| Simulación | `tick_hz` | 60 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] UCS simula a frames fijos; 60 Hz [I] |
| Simulación | `predictor_frames` | 240 | N | 120 … 360 | [N] UCS usa 390 [UCS-C]; 240 (4 s) basta en Fútbol 5 |
| Simulación | `random_seed` | 12345 | N | 6172.5 … 18517.5 | [N] semilla del RNG determinista del partido |
| Campo | `pitch_length` | 40.0 | N | 20 … 60 | [N] fútbol 5/futsal |
| Campo | `pitch_width` | 20.0 | N | 10 … 30 | [N] |
| Campo | `goal_half_width` | 1.5 | N | 0.75 … 2.25 | [N] portería 3 × 2 m (UCS: 4 yd, fútbol 11) |
| Campo | `goal_height` | 2.0 | N | 1 … 3 | [N] |
| Campo | `post_radius` | 0.04 | N | 0.02 … 0.06 | [N] (UCS ≈ 0,044 m sobre el borde interior [UCS-C/I]) |
| Campo | `goal_depth` | 1.0 | N | 0.5 … 1.5 | [N] profundidad de la red |
| Campo | `goal_line_margin` | 0.0 | N | 0 … 0 | [N] el balón debe superar la línea entera (UCS lo exige [UCS-C]) |
| Balón | `ball_radius` | 0.105 | N | 0.0525 … 0.1575 | [N] (UCS 0,115 m [UCS-C/I]) |
| Balón | `ball_mass` | 0.42 | N | 0.21 … 0.63 | [N] |
| Balón | `gravity` | 9.81 | N | 4.905 … 14.715 | [N] (UCS 98 u/frame² ≈ 9,85 m/s² [UCS-C/I]) |
| Balón | `air_drag_k` | 0.012 | N | 0.006 … 0.018 | [N] a = −k·/v/·v (1/m). UCS usa una tabla por velocidad (no recuperada [L]) |
| Balón | `magnus_k` | 0.0010 | N | 0.0005 … 0.0015 | [N] a = k·(ω × v). UCS: producto vectorial efecto×velocidad [UCS-C estructura] |
| Balón | `spin_decay_air` | 0.15 | N | 0.075 … 0.225 | [N] fracción de efecto perdida por segundo en el aire |
| Balón | `restitution` | 0.50 | N | 0.25 … 0.75 | [N] rebote vertical (balón de futsal: bote bajo). UCS: valor en ejecución [P] |
| Balón | `bounce_min_speed` | 0.6 | N | 0.3 … 0.9 | [N] por debajo, el balón deja de botar y rueda |
| Balón | `bounce_spin_transfer` | 0.35 | N | 0.175 … 0.525 | [N] 0..1 convergencia velocidad/efecto hacia rodadura en cada bote. UCS: 25–50 % según la velocidad vertical [UCS-C estructura] |
| Balón | `roll_decel` | 0.9 | N | 0.45 … 1.35 | [N] deceleración de rodadura (m/s²) |
| Balón | `roll_stop_speed` | 0.05 | N | 0.025 … 0.075 | [N] |
| Balón | `post_restitution` | 0.55 | N | 0.275 … 0.825 | [N] |
| Balón | `net_damping` | 0.15 | N | 0.075 … 0.225 | [N] velocidad que conserva el balón al tocar la red |
| Jugador · locomoción | `walk_speed` | 1.6 | N | 0.8 … 2.4 | [N] |
| Jugador · locomoción | `jog_speed` | 3.5 | N | 1.75 … 5.25 | [N] |
| Jugador · locomoción | `run_speed` | 5.5 | N | 2.75 … 8.25 | [N] |
| Jugador · locomoción | `sprint_speed_attr50` | 7.0 | N | 3.5 … 10.5 | [N] valor con atributo 50 |
| Jugador · locomoción | `sprint_speed_attr99` | 8.5 | N | 4.25 … 12.75 | [N] con atributo 99 (relación ≈ SpeedSprint1/SpeedSprint0 = 1,214 [UCS-C]) |
| Jugador · locomoción | `accel` | 6.0 | N | 3 … 9 | [N] m/s² (UCS: curvas ilegibles [L]) |
| Jugador · locomoción | `decel` | 9.0 | N | 4.5 … 13.5 | [N] |
| Jugador · locomoción | `turn_rate_deg` | 360.0 | N | 180 … 540 | [N] giro sin clip, grados/s |
| Jugador · locomoción | `turn_no_clip_deg` | 30.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 0x555: por debajo no se usa clip de giro |
| Jugador · locomoción | `turn_clip_deg` | 50.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 0x8e4: a partir de aquí se planifica un clip TURN |
| Jugador · locomoción | `turn_speed_loss_at_180` | 0.5 | UCS-C estructura | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C estructura] la fracción de velocidad cae linealmente hasta ½ a 180° |
| Jugador · locomoción | `arrive_radius` | 0.23 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x2000 = ¼ yd |
| Contacto (planificador y ejecución) | `plan_search_frames` | 12 | N | 6 … 18 | [N] frames de inicio que se prueban (UCS: n variable) |
| Contacto (planificador y ejecución) | `playback_scale_min` | 0.875 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 0x380/1024 |
| Contacto (planificador y ejecución) | `playback_scale_max` | 1.2 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 0x4cc/1024 |
| Contacto (planificador y ejecución) | `approach_turn_deg_per_tick` | 2.11 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 0x60 en 16384/vuelta |
| Contacto (planificador y ejecución) | `tol_control` | 0.057 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x800 = 1/16 yd (toque y control) |
| Contacto (planificador y ejecución) | `tol_kick` | 0.114 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x1000 = 1/8 yd (golpeo) |
| Contacto (planificador y ejecución) | `tol_height_factor_below` | 3.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] la altura admite −3·tol … +tol |
| Contacto (planificador y ejecución) | `wrong_foot_cost` | 0.30 | N | 0.15 … 0.45 | [N] (UCS +0x90000 en sus unidades de coste) |
| Conducción | `dribble_speed_scale_attr50` | 0.80 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] TechniqueDribbleSpeedScale0 820/1024 |
| Conducción | `dribble_speed_scale_attr99` | 0.934 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 956/1024 |
| Conducción | `touch_ahead_min` | 0.69 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x6000 (parado) |
| Conducción | `touch_ahead_mid` | 0.80 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x7000 (a la fracción de velocidad 0,3125) |
| Conducción | `touch_ahead_max` | 1.03 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0x9000 (velocidad máxima) |
| Conducción | `special_touch_pct_attr99` | 50.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] TechniqueSpecialControlPercent1 |
| Conducción | `touch_interval_min` | 0.35 | N | 0.175 … 0.525 | [N] s entre toques a velocidad máxima |
| Conducción | `touch_interval_max` | 0.70 | N | 0.35 … 1.05 | [N] s entre toques caminando |
| Golpeo | `kick_speed_max_attr50` | 30.8 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] KickPower0 18382 u/frame |
| Golpeo | `kick_speed_max_attr99` | 36.2 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] KickPower1 21627 u/frame |
| Golpeo | `kick_speed_min` | 6.7 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0xfa5 |
| Golpeo | `wrong_foot_power` | 0.95 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] 3891/4096 |
| Golpeo | `back_kick_power_attr50` | 0.875 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] TechniqueRotPowerScaleBW0 896·4/4096 |
| Golpeo | `back_kick_power_attr99` | 0.9375 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] …1 960·4/4096 |
| Golpeo | `err_fw_deg_attr50` | 4.1 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] TechniqueKickErrorFW0 187 (16384/vuelta) |
| Golpeo | `err_fw_deg_attr99` | 1.7 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] …1 78 |
| Golpeo | `err_bw_deg_attr50` | 11.7 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] TechniqueKickErrorBW0 533 |
| Golpeo | `err_bw_deg_attr99` | 5.9 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] …1 270 |
| Golpeo | `pass_time_short_frames` | 50.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] tiempo de vuelo a 5 yd |
| Golpeo | `pass_time_long_frames` | 195.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] tiempo de vuelo a 60 yd |
| Golpeo | `pass_ref_short_m` | 4.57 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 5 yd |
| Golpeo | `pass_ref_long_m` | 54.86 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 60 yd |
| Golpeo | `pass_time_scale` | 0.8 | N | 0.4 … 1.2 | [N] Fútbol 5 juega más rápido: escala el tiempo UCS |
| Golpeo | `lofted_height_threshold` | 0.457 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] destino > ½ yd ⇒ pase elevado |
| Golpeo | `cross_apex_height` | 2.6 | N | 1.3 … 3.9 | [N] |
| Golpeo | `shot_dist_no_power` | -62.2 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] ShotDistNoPower −68 yd (mapa distancia → potencia) |
| Golpeo | `shot_dist_max_power` | 29.3 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] ShotDistMaxPower 32 yd |
| Golpeo | `shot_speed_scale` | 0.85 | N | 0.425 … 1.275 | [N] Fútbol 5: tiros más cortos |
| Golpeo | `max_kick_distance` | 54.86 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 60 yd |
| Golpeo | `curl_spin_attr50` | 6.0 | N | 3 … 9 | [N] rad/s (UCS TechniqueCurl0/1 = 500/8000, unidad desconocida [P]) |
| Golpeo | `curl_spin_attr99` | 14.0 | N | 7 … 21 | [N] |
| Defensa e IA | `max_active_tackles` | 1 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] |
| Defensa e IA | `max_active_presses` | 2 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] |
| Defensa e IA | `marking_dist` | 1.37 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] MarkingDist 49152 = 1,5 yd |
| Defensa e IA | `react_frames_attr50` | 21.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] ResponsePlayerMoveOOP0 |
| Defensa e IA | `react_frames_attr99` | 1.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] …1 |
| Defensa e IA | `slide_range` | 2.29 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] StrengthSlideTackleRange 2,5 yd |
| Defensa e IA | `tackle_range_passive_50` | 0.69 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 0,75 yd |
| Defensa e IA | `tackle_range_passive_99` | 1.14 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 1,25 yd |
| Defensa e IA | `tackle_range_press_50` | 1.37 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 1,5 yd |
| Defensa e IA | `tackle_range_press_99` | 2.29 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] 2,5 yd |
| Defensa e IA | `ai_think_hz` | 10.0 | N | 5 … 15 | [N] frecuencia de decisión de la IA |
| Defensa e IA | `possession_limit_s` | 20.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] PossessionTimerLimit 1200 frames |
| Portero | `gk_react_frames_attr50` | 15.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] ResponseGKSave0 |
| Portero | `gk_react_frames_attr99` | 4.0 | UCS-C | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C] ResponseGKSave1 |
| Portero | `gk_reach_min_50` | 1.25 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] TechniqueGKMinSaveDist0 1,37 yd |
| Portero | `gk_reach_min_99` | 1.65 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] …1 1,8 yd |
| Portero | `gk_reach_max_50` | 2.29 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] TechniqueGKMaxSaveDist0 2,5 yd |
| Portero | `gk_reach_max_99` | 2.74 | UCS-C/I | dato de UCS escalado; tocar solo si el Fútbol 5 lo pide | [UCS-C/I] …1 3 yd |
| Portero | `gk_line_offset` | 0.9 | N | 0.45 … 1.35 | [N] distancia a la línea en la bisectriz |
| Portero | `gk_sweep_dist` | 6.0 | N | 3 … 9 | [N] distancia a la que sale a por balones sueltos |

`max_correction_per_tick` (m/frame por categoría, [UCS-C/I] desde la tabla 0x13a480): CONTROL 0.206, KICK 0.343, KICKSETPIECE 0.26, TACKLE 0.043, TACKLESLIDE 0.064, GKSAVE 0.114, TURN 0.

## 2. Procedimiento (en este orden: cada paso depende del anterior)

1. **Balón solo** (sin jugadores). `tests/run_tests.gd` ya comprueba caída, bote, rodadura, Magnus, solucionadores y portería. Ajusta:
   - `restitution` con un vídeo de referencia: bote desde 1 m → altura medida h₁ ⇒ e = √(h₁/1).
   - `roll_decel`: balón rodando a v₀ se para en d ⇒ a = v₀²/(2d). Futsal ≈ 0.6–1.2 m/s²; sala con césped artificial ≈ 1.5–2.5.
   - `air_drag_k`: tiro a 25 m/s debe perder ≈ 15–25 % de velocidad en 20 m.
   - `magnus_k` y `curl_spin_*`: un tiro con efecto máximo a 15 m debe desviarse 1–2 m.
2. **Locomoción**: `walk/jog/run/sprint`, `accel`, `decel`, `turn_rate_deg`. Métrica: 0→sprint en 1.0–1.4 s; frenada desde sprint en < 1 m extra; las zancadas no patinan (rate de locomoción entre 0.85 y 1.15 la mayor parte del tiempo — si no, cambia `speed_class` de los clips LOCO o añade clips).
3. **Conducción**: `touch_interval_*`, `touch_ahead_*`, `dribble_speed_scale_*`. Métrica: separación jugador‑balón 0.4–1.3 m, ≥ 95 % de toques validados (prueba `conducción` de run_tests).
4. **Recepción / control**: `tol_control`, `max_correction_per_tick.CONTROL`. Métrica: un pase de 12 m a 10 m/s se controla en ≥ 90 % de los casos con técnica 70.
5. **Golpeo**: `kick_speed_*`, `pass_time_scale`, `err_*`, `shot_speed_scale`. Métrica: pase corto de 8 m llega en 0.6–0.9 s; tiro a 10 m llega en 0.45–0.6 s; error medio de dirección observable pero no ridículo.
6. **Defensa e IA**: rangos de entrada, `react_frames_*`, `max_active_presses`. Métrica: robos por minuto y pérdidas por minuto parecidos entre equipos iguales.
7. **Portero**: `gk_react_*`, `gk_reach_*`, `gk_line_offset`. Métrica: el portero de 70 para ≈ 60–70 % de tiros centrados a 10 m y ≈ 20–35 % de tiros a la escuadra.

## 3. Perfiles sugeridos

| Perfil | Cambios sobre el valor inicial |
|---|---|
| Arcade | `accel` 8, `decel` 12, `roll_decel` 0.7, `tol_control` ×1.5, `err_*` ×0.6, `gk_react_*` ×1.2 |
| Simulación | valores iniciales |
| Futsal realista | `restitution` 0.4, `roll_decel` 0.8, `pass_time_scale` 0.85, `sprint_speed_attr99` 8.0 |
| Móvil fácil | `plan_search_frames` 16 (más planes válidos), `tol_control` ×1.3, `react_frames_*` ×1.3 |

## 4. Métricas automáticas

`tests/run_tests.gd` imprime los valores medidos (tiempo de caída, altura de bote, distancia de rodadura, error de solucionadores, goles, toques validados, separación máxima). Añade allí tus propias métricas cuando metas clips reales: cada prueba usa el mismo `FutbolConfig` que el juego.
