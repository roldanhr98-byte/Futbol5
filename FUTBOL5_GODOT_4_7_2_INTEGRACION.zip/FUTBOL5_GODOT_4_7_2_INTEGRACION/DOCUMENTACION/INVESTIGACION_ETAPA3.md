# ETAPA 3 · INVESTIGACIÓN TÉCNICA DE LOS PENDIENTES

> Continúa las etapas 1 y 2 sin reemplazarlas. **[C]** comprobado · **[I]** inferencia · **[P]** pendiente · **[L]** fuera de
> alcance · **[N]** decisión nueva para Fútbol 5 (no procede de UCS). Pseudocódigo de Ghidra 11.2.1 (programa rebasado a 0,
> límites de `.eh_frame`), contrastado con el ensamblador. Binario `libMPX.so` SHA‑256 `e7c5d97e…190a`, sin cambios.

## 0. Comparación técnica del conjunto de animaciones recibido en la etapa 3
`animaciones_futbol5_nombres_originales(1).zip` (8.383.382 B, SHA‑256 `3fa72c92ae35fe58540dd130d841534e0c73a2308a131f71a503ecd8ad8b374f`):

| Comprobación | Resultado |
|---|---|
| Archivos | 2.023 (2.022 clips JSON + `index.json`), ninguno dañado [C] |
| Comparación con el ZIP de la etapa 1 (`animaciones_futbol5_conectadas_y_sin_conectar.zip`) | **los 2.023 archivos son idénticos byte a byte** [C] |
| Nombre de cada clip frente a la tabla `ANM_*` de UCS del mismo índice | coincide en los 2.022 [C] |
| Posiciones de las 19 articulaciones frente al bloque B de los `.sat` de UCS (ETAPA2_04) | coinciden en todas las claves de los 2.022; error máximo 0,05 mm (redondeo de la exportación) [C] |
| Tiempos de clave frente al pool de `animdb.adb` | idénticos en 1.835 de 2.022 [C] |

Conclusión [C]: la comparación técnica registró coincidencias byte a byte entre los JSON analizados y los datos de movimiento
identificados en `anims.pak` de UCS, convertidos a JSON. Este resultado queda documentado como antecedente técnico de la
investigación. La versión del paquete descrita en este documento contiene los ejemplos sintéticos y las herramientas de
integración; el flujo general para incorporar y catalogar clips se describe en `LEEME_PRIMERO.md` y en
`DOCUMENTACION/MANUAL_MAESTRO_OTRO_CLAUDE.md`. Script utilizado en aquella comparación: `herramientas/comparar_zip_con_ucs.py`.

## A. Locomoción y giro — reparto real de las funciones candidatas
| Función | Llamadores | Qué hace | Evidencia |
|---|---|---|---|
| **0x47b278** (0xed0 B) | 0x470e10 (actualización del jugador), 0x4707f0 | **Actualización de movimiento sin contacto**: lee el destino de carrera `+0x3a8/+0x3ac`, la velocidad `+0x1c`, la velocidad objetivo `+0x3b0`; decide parar, seguir, girar (TURN) o cambiar de marcha (LOCO/STAND/SIDESTEP) | [C] |
| **0x480b54** (0x9dc B) | 0x47b278 (×5), 0x475570, 0x45252c | **Planificador de giro**: si dirección pedida y movimiento difieren < 0x555 (30°) no hay clip de giro y se sigue en LOCO; si no, construye un perfil de 90 frames (`0x47d050`) y prueba los clips del grupo **TURN** (`0x893ca8`) comparando su raíz con el perfil | [C estructura · P coste exacto] |
| **0x47c29c** (0x3f0 B) | 0x47b278, 0x480b54, 0x475570 | **Selector LOCO/STAND por identificador de marcha**: busca en el grupo de la categoría actual el clip cuyo `f0a` (rt+0x96) es igual al identificador pedido; desempata por dirección (`f12`, peso 0x80) y flags, `rnd(8)` | [C] |
| **0x474c6c** (0x274 B) | 0x47b278, 0x475570, 0x47d75c | **Selector genérico por coste** dentro del grupo de la categoría actual: `(Δdirección·w1)² + ((id − f0a)·w2)² + (Δorientación vs f20·256 · w3)²` + `rnd(32)`; pesos según categoría (STUMBLE, FALL, GETUP, SIDESTEP…) | [C] |
| **0x475570** (0x3a4 B) | 0x4743d8, 0x47a680 | Reinicio de locomoción tras otra acción: elige entre giro (0x480b54), LOCO (0x47c29c) y parado/lateral (0x474c6c) según el ángulo hacia el destino y la velocidad respecto a `0x851698` | [C] |
| **0x475134** (0x3ac B) | 0x55fb3c (balón parado) | **Carrera de balón parado**: estado 12 (KICKSETPIECE), grupo `0x893de8`; ajusta la raíz con 0x44781c para llegar al balón | [C] |
| **0x47d780** (0x254 B) | 0x46f55c, 0x472be0 (entrada), 0x4740cc | **Tropiezo (STUMBLE, grupo 5)** tras contacto o entrada | [C] |

Identificadores de marcha `f0a` observados en los datos de UCS (no espejados) [C datos · I significado por nombres]:
LOCO `20` (caminar), `30` (con balón en las manos del portero), `40` (trote), `60` (carrera/sprint); STAND `0` reposo,
`8/9` listo, `11` (37 clips: esperas), `1/2/5…` variantes de situación; el selector de STAND (0x47c29c) elige el identificador
según la situación: con el balón cerca y bajo (`< 1 yd`) `8`; balón alto `0xd`/`1`; balón parado `9`; reposo `0` [C ramas].

Reglas de 0x47b278 comprobadas [C]:
- Llegada al destino si la distancia < 0x2000 (¼ yd ≈ 0,23 m): se frena y se elige STAND.
- Velocidad < 0x642 (1602 u/frame) o < `0x851698` (umbral de marcha, ilegible): tratamiento de "parado".
- Giro sin clip si la diferencia angular < 0x555 (30°); clip de giro si ≥ 0x8e4 (50°); 0xe39 (80°) como límite para encadenar.
- **Reducción de velocidad al girar**: `v' = curva(0x851494)[ curva(0x851290)[v/128] · (1 − |Δángulo|/360°) ]` → con la curva inversa
  y la directa, un giro de 180° reduce la "fracción de velocidad" a la mitad [C estructura · L valores de las curvas].
- Corrección de orientación durante el cambio de marcha: `map(velocidad, 0x8000..0x28000, Δ…)` limitada a ±0x800 (±45°) [C].

**Curvas de velocidad, umbral de marcha (0x851698), aceleración y frenado**: los consumidores son 0x47b278, 0x47d388, 0x47d298,
0x480b54 y 0x47d050; todos leen las tablas de la región de `.data` ilegible [L]. **No hay constantes alternativas en el
código**. No se recuperan.

## B. Control táctil
- `DragStart`/`DragRelease` se enlazan en **0x66ec28**, dentro del framework de interfaz (región 0x66xxxx, enlace de eventos
  de widgets mediante 0x665b30), **no en la jugabilidad** [C].
- La jugabilidad interpreta los toques en **0x54c86c** (controlador por equipo): proyecta a pantalla el balón previsto a 18
  frames y los jugadores (0x499df4) y define radios de toque en mundo:
  `escala = (DistDefault(35) << 21) / (|cámara − objetivo| >> 6)`; `radio_balón = CtrlBallScreenRadiusMin/Max (48/112) · escala`;
  `radio_jugador = CtrlPlayerScreenRadius (96) · escala` [C]. Es decir, los radios en píxeles se convierten a mundo según el
  zoom de la cámara.
- La traducción "trazo → destino de carrera `+0x3a8` / vector de golpeo `+0x4d4`" ocurre en ramas de 0x54c86c que dependen de
  estructuras de interfaz no analizadas [P]. `RunArrowLength` (10) y `RunTimeout` (300 frames) acotan la flecha de carrera [C defectos].
- **Para Fútbol 5 [N]**: el joystick virtual no equivale al toque de UCS. UCS no controla la velocidad continua: fija un
  **destino** y deja que la locomoción elija marcha y giros. El paquete Godot convierte el joystick en un *destino móvil*
  (`posición + dirección · distancia_de_mira`) y una velocidad pedida, para reutilizar la misma lógica de destino.

## C. Conducción y recepción (ampliación)
- Las recepciones y los toques comparten el planificador CONTROL (etapa 2). Diferencias por velocidad [C]: el perfil de
  80 frames sale de la fracción de velocidad; la distancia del siguiente toque crece de `0x6000` a `0x9000` (0,69→1,03 m)
  entre parado y velocidad máxima; la escala de velocidad en conducción es 820→956/1024 según técnica.
- La transición CONTROL→LOCO tras el toque la hace 0x475570 (reinicio de locomoción) cuando el clip termina [C].

## D. Golpeo (ampliación)
- **SEL‑3 0x475b40** compara los mismos campos que SEL‑2: `f0a` (clase de velocidad), altura del evento (`rt+0x34`·escala),
  fase del evento (`rt+0x2c`), `f20` (orientación, en pasos de 256), rangos `f0e/f10` y `f16/f18`, dirección `f12`; penaliza el
  pie no hábil con +0x90000; desempate aleatorio [C campos · P pesos exactos].
- **Modo 4** de la máquina de estados: no tiene rama propia de ejecución en 0x4721d0; cae en el tratamiento por defecto
  (cuenta atrás y fin) [C]. No se encontró ningún planificador que lo asigne en las funciones analizadas [P].
- Unidades de los parámetros de golpeo con la escala 1/32768 yd por frame a 60 Hz [I]: `KickPower0/1` = **30,8 → 36,2 m/s**;
  velocidad mínima de golpeo `0xfa5` = 6,7 m/s; `TechniqueKickErrorFW0/1` 187→78 y `BW0/1` 533→270 en 16384/vuelta =
  4,1°→1,7° y 11,7°→5,9° [I unidad angular].

## E. Física del balón (ampliación)
Orden de actualización del partido **0x464d84** [C]: `0x44aa1c` (paso del balón con portería) → `0x4488e4` (reglas: gol, fuera,
sonidos) → `0x4484c8` (balón en las manos) → `0x4486cc` → `0x46fb7c` (contactos pendientes).
- **Portería [C constantes · I geometría]**: postes en x = ±0x20636 (4 yd + 0x636 ≈ 4,05 yd), larguero a z = 0x15b8b
  (2,715 yd ≈ 2,48 m), línea de gol |y| = 0x1c8000 (57 yd). `0x44a48c` calcula el impacto con los postes y `0x44baac` con el
  larguero; `0x44a89c` y `0x44bea0` hacen el rebote (velocidad normal reflejada con factor `0x1000 − p`) y marcan `balón+0xc1`.
  La red retiene el balón: con el gol concedido se limita a |y| ≤ 0x1c943c y |x| ≤ 0x20000 [C].
- **Gol** (0x44e2ac): interpola el cruce entre la posición anterior y la actual; gol si |x| < 0x20000 (4 yd), z < 0x15555
  (8 pies = 2,44 m, el larguero reglamentario) y el balón supera la línea en 0x17c9 (0,17 m ≈ radio + media línea) [C].
- `0x15555` (8 ft) aparece en 7 funciones (portero, saque, IA): cuarta confirmación de la unidad 1/32768 yd [I fuerte].
- Balón en las manos (0x4484c8): la posición se toma de la mano del jugador (0x477070), velocidad pendiente a cero [C].
- **Coeficientes de rebote en postes, rozamiento, restitución del suelo, arrastre y deriva**: siguen sin valor recuperable
  [P/L]. El factor de rebote de los postes llega como parámetro calculado en 0x44aa1c, no como constante [C].

## F/G. IA y porteros (ampliación)
- SEL‑5 0x4330d8 usa los campos `rt+0x92/0x94` (rango), `0x96` (clase), `0x24/0x18` (frame de referencia), `0x90` (`f14`),
  `0x5c` (nº de eventos), `0x30` (distancia del evento), `0x2c` (fase), `0x2a` (giro final) y predice al portero 14 veces
  con 0x4715ec [C campos · P pesos].
- 0x4555fc (reacción de jugadores al balón alto: usa 0x15556 y 0x22aab = 3,33 yd) y 0x46f61c (decisión con el balón cerca de la
  portería, usa 0x15555 y la línea 0x1c8000) [C constantes · I papel].
- El resto de la IA (marcaje, presión, pases del bot, desmarques) queda como en etapas 1–2.

## H. Esqueleto
- 33 huesos (bloque A) y 19 posiciones con nombre (bloque B) [C]. Jerarquía y nombres de los 33 huesos: **no están en el
  `.sat` ni como cadenas en el binario**; los `.ftm` de `models.pak/character/body` tienen cabecera `FTTM` y nombres de malla,
  pero no se encontraron nombres de hueso en texto [P].
- Para Fútbol 5 el esqueleto será el vuestro: el paquete usa **vuestro** `Skeleton3D` y no asume ninguna correspondencia con
  UCS [N].

## Estado de todos los pendientes
| ID | Estado tras la etapa 3 |
|---|---|
| P2‑01 locomoción/giro | **Resuelto en estructura** (funciones, selectores, umbrales angulares); curvas numéricas [L] |
| P2‑02 gesto táctil | Parcial: radios y proyección [C]; trazo→destino [P]; DragStart/Release son de la interfaz [C] |
| P2‑03 modo 4 y costes | Modo 4 sin ejecución propia [C]; campos de coste de SEL‑3/SEL‑5 [C], pesos [P] |
| P2‑04 traspaso `+0x94` | Parcial: escritores 0x448654, 0x4484c8, 0x449104, 0x450060; secuencia del partido [C] |
| P2‑05 jerarquía de huesos | [P] sin fuente legible |
| P2‑06 mezcla de pose | [P] |
| P2‑07 postes y red | **Resuelto en estructura** (constantes y funciones) [C]; coeficiente de rebote [P] |
