# PLAN DE IMPLEMENTACIÓN (siguientes pasos en vuestro juego)

1. **Abrir y probar el proyecto base** (30 min): `godot --headless --path . --script res://tests/run_tests.gd` → 22 OK.
2. **Exportar vuestras animaciones** (ver MANUAL_MAESTRO_OTRO_CLAUDE.md §3): .glb → JSON → validar → convertir. Empezad con el mínimo jugable:
   - LOCO: caminar, trote, carrera, sprint (4) · STAND: reposo, frenada (2) · TURN: 90° izq/der, 180° (3)
   - CONTROL: toque de conducción pie derecho a 3 velocidades (3; el espejo da el izquierdo) + 2 recepciones
   - KICK: pase raso, pase elevado, tiro, centro (4) · TACKLE: 1 de pie, 1 en plancha · GKSAVE: estirada baja/media a un lado (2; espejo) + centro (1) · FALL/GETUP: 1+1
3. **Marcar los eventos de contacto** en `eventos.json` (frame en que el pie toca el balón) y meta `foot`/`speed_class`.
4. **Escena de partido**: MatchSim + Ball + 2 Player con vuestro modelo; comprobar conducción y pase con F3 (trayectoria prevista).
5. **Calibrar** en el orden de CALIBRACION_FISICA.md §2.
6. **IA y porteros**: activar TeamAI/PlayerAI/GkAI para 4+1 contra 4+1.
7. **Táctil**: `HumanInput` para el joystick; botones pase/tiro. (UCS: gestos DragStart/DragRelease son de la interfaz, no de la jugabilidad [UCS-C]).
8. **Ampliar el catálogo**: más ángulos de toque (±45°, ±90°), recepciones de pecho/cabeza, regates SPECIAL; cada clip nuevo se convierte y entra solo en el planificador.
9. **Rendimiento en el dispositivo** (OPTIMIZACION.md).
