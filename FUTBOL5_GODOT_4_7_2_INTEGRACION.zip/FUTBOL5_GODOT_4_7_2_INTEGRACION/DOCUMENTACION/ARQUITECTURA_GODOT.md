# ARQUITECTURA GODOT 4.7.2

Proyecto: `GODOT_4_7_2/proyecto_futbol5/` (abrir `project.godot` con Godot 4.7.2; renderer Mobile; física a 60 Hz).

## Principios (todos derivados de lo confirmado en UCS)
1. **El balón es el único dueño de su estado físico** (`ball/ball.gd`). Las animaciones nunca lo mueven: los jugadores *registran* un contacto (velocidad + efecto) y el balón lo aplica en un punto fijo del tick. UCS: registro 0x46f968 → aplicación 0x46fb7c/0x448654 [UCS-C].
2. **Una sola física determinista** (`ball/ball_physics.gd`, función pura `BallPhysics.step`) usada por el balón real, el predictor y los solucionadores. Lo que se planifica es lo que ocurre [UCS-C].
3. **Contactos planificados**: cada toque (conducción, control, pase, tiro, entrada, parada) elige *clip + frame de inicio + orientación* para que el evento de contacto del clip coincida con el balón previsto; la diferencia se corrige moviendo la raíz poco a poco con un paso máximo por categoría [UCS-C].
4. **Root motion en metadatos**: el convertidor saca el desplazamiento horizontal y el giro de la raíz a `AnimClipMeta`; el `AnimationPlayer` solo pone la pose (se mueve con `seek()`), y el jugador avanza con la raíz del clip + corrección.
5. **Tick fijo y orden fijo** (`match/match_sim.gd`): decisiones (IA/entrada) → jugadores → `ball.apply_pending()` → `ball.physics_tick()` (portería, gol, predictor). Mismo orden que el bucle de partido de UCS 0x464d84 [UCS-C].

## Carpetas y scripts
| Carpeta | Script | Función |
|---|---|---|
| core | futbol_config.gd | Todos los parámetros (Resource exportable, etiquetados [UCS-C]/[N]) |
| ball | ball_state.gd, ball_physics.gd, ball_predictor.gd, trajectory_solver.gd, goal_frame.gd, ball.gd | Estado, física, predicción (4 s), solucionadores aire/raso, postes/larguero/red/gol, balón del partido |
| animation | anim_clip_meta.gd, anim_catalog.gd, player_animator.gd | Metadatos de clip, catálogo con caché LRU, reproductor con fase controlada |
| player | player.gd, locomotion.gd, contact_plan.gd, contact_planner.gd, contact_executor.gd | Jugador, motor de locomoción, plan/planificador/ejecutor de contacto |
| actions | dribble_action.gd, receive_action.gd, kick_action.gd, tackle_action.gd | Conducción, recepción/primer toque, pases/centros/tiros/tiro de primera, entradas |
| input | human_input.gd | Joystick virtual → destino móvil, sprint |
| ai | team_ai.gd, player_ai.gd | Roles (presión/marca/apoyo), utilidad tiro/pase/conducción |
| goalkeeper | gk_ai.gd | Colocación en bisectriz, reacción, alcance, plan GKSAVE |
| match | match_sim.gd | Orden del tick, IA escalonada |
| debug | debug_draw.gd | Trayectoria prevista (F3) |
| tools | exportar_clips_json.gd | Exporta animaciones de vuestro .glb/.tscn a futbol5_clip_v1 |
| tests | check_scripts.gd, run_tests.gd, test_exportador_glb.gd | Compilación, 22 pruebas del núcleo, prueba del exportador |
| data | config/, catalog/catalogo.json, animations/imported, animations/metadata | Generados por el convertidor |

## Flujo de un toque de conducción
`DribbleAction.request_touch` → `ContactPlanner.plan` (clips CONTROL × frames de inicio; balón previsto en i+tEv−1; coste = corrección² + dirección² + velocidad² + altura² + pie malo + azar) → `Player.start_action` → `ContactExecutor.tick` (raíz del clip girada + corrección limitada; giro ≤ 2,11°/tick; en el frame del evento fija la fase exacta y valida con tolerancia 1/16 yd) → `contact_ok` → `DribbleAction._on_contact` → `TrajectorySolver.solve_ground` hacia el punto del siguiente toque → `Ball.register_contact`.

## Escena mínima para probar en el editor
Nodo raíz `Node3D` con `MatchSim`; hijos `Ball` (con MeshInstance3D esfera r=0.105) y N `Player` (cada uno con vuestro modelo: `Skeleton3D` + `AnimationPlayer` como hijos directos o ajustando `PlayerAnimator.anim_player`). `MatchSim` carga `res://data/catalog/catalogo.json`.
