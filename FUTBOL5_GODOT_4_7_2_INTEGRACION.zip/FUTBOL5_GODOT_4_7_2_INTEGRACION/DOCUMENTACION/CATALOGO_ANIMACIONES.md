# CATÁLOGO DE ANIMACIONES

## Estado del catálogo incluido

- **Clips sintéticos de prueba: 38**, más 29 espejos al convertir (67 recursos resultantes), ubicados en `ANIMACIONES_PROPIAS/EJEMPLOS_SINTETICOS/`. Utilizan el prefijo `EJ_` y la etiqueta `SINTETICO`. Sirven para probar el formato, el catálogo y el pipeline; su geometría es simple.
- El catálogo que acompaña a esta versión se generó a partir de los clips de ejemplo disponibles en el paquete. Se puede ampliar regenerándolo después de incorporar otros clips.

## Cómo catalogar un conjunto de animaciones

```bash
python3 HERRAMIENTAS/catalogar.py ANIMACIONES_PROPIAS/MIS_CLIPS CATALOGO/MIS_CLIPS
```

El comando genera `catalogo_completo.csv/json` con nombre exacto, archivo, SHA-256, categoría, sistema, frames, FPS, duración, pie, contacto, fotograma y parte de contacto, velocidad de raíz, giro, etiquetas y estado.

También genera:
- `categorias/`
- `sistemas/`
- `espejos/pares_espejo.csv`
- `compatibilidad.csv`

Los clips con errores de validación quedan identificados en el catálogo junto con el motivo, para facilitar su revisión.

## Categorías y sistemas del juego

| Categoría | Sistema | Lo utiliza |
|---|---|---|
| LOCO, STAND, TURN, SIDESTEP | locomoción / giro / frenado | `locomotion.gd` |
| CONTROL | conducción, control, recepción | `dribble_action.gd`, `receive_action.gd` |
| KICK, KICKSETPIECE | pase, centro, tiro, balón parado | `kick_action.gd` |
| TACKLE, TACKLESLIDE | entrada | `tackle_action.gd` |
| FALL, GETUP, STUMBLE | caída / recuperación | `player.gd` |
| GKSAVE, GKTHROW, GKKICK | portero | `gk_ai.gd` |
| THROW, NIS, OTHER | saque de banda, escenas y otros | sistema por integrar |
